# UEP Oracle Layer v0.1 — Production Hardening & Architectural Milestone

**Status:** APPROVED FOR INTEGRATION (Milestones: ORACLE-01 & ORACLE-02 Preparation)  
**Target:** Universal Economic Protocol (UEP Core Protocol)  
**Scope:** Verifiable economic evidence layer for SVC, IoT/M2M, AMM, Paymaster, and Dispute Engine.

---

## 1. Definitive Architecture & Trust Boundaries

```text
                  EXTERNAL WORLD
                        │
                  Oracle / Device
                        │
                        ▼
                   ATTESTATION
                        │
                        ▼
               ┌─────────────────┐
               │   Oracle Core   │
               │                 │
               │  Verify         │
               │  Anti-replay    │
               │  Aggregate      │
               └────────┬────────┘
                        │
                    AGGREGATED
                        │
                        ▼
              Economic / Risk Policy
                        │
               ┌────────┴────────┐
               │                 │
            ACCEPTED          REJECTED
               │
               ▼
     Settlement Authorization (Single-Use Verifiable Voucher)
               │
               ▼
        Settlement Engine
               │
               ▼
           UEP Ledger (SMT Root, Commitments, Nullifiers)
```

### Invariantes No Negociables
1. **Unidireccionalidad Absoluta (Sin flechas hacia atrás):**
   - El **Oracle Core** nunca modifica el ledger ni crea notas.
   - La **Economic Policy** nunca modifica el ledger.
   - **Únicamente el Settlement Engine** posee la autoridad para ejecutar la transición contable tras consumir un voucher válido de `SettlementAuthorization`.
2. **`AGGREGATED !== ECONOMICALLY_ACCEPTED`:**
   - La existencia de una cotización agregada de $N$ fuentes honestas certifica que las fuentes atestaron una observación válida.
   - No confiere derecho de pago sin la evaluación explícita de la política económica del consumidor (SLA, márgenes de volatilidad o tarifas).
3. **Resistencia Sybil sin Staking Prematuro:**
   $$\text{Mediana Ponderada} + \text{Directorio de Registro Controlado} = \text{Resistencia Sybil}$$
   Los pesos representan autoridad administrativa de auditoría, **no** poder de voto por staking de tokens ni slashing.

---

## 2. Los 4 Hardening Principales Implementados

### 2.1 Aislamiento contra el Ledger Real (Test 26)
Cuando una política rechaza una cotización o se intenta liquidar sin autorización previa, se verifica mediante instantáneas criptográficas del ledger (`LedgerStateSnapshot`) que:
- **SMT Root:** 100% inalterado.
- **Conjunto de Notas:** 100% inalterado.
- **Árbol de Nullifiers:** 100% inalterado.
- **Balances Totales:** 100% inalterados.

### 2.2 Concurrencia y Defensa contra Doble Liquidación (Tests 27 y 28)
- **Feeds Concurrentes:** Dos procesos emitiendo simultáneamente la misma secuencia 42 en condiciones de carrera (`Promise.all`) resultan en **exactamente uno aceptado** y el segundo rechazado de forma determinista con `REPLAY_ATTACK`.
- **Doble Settlement:** Dos llamadas concurrentes al Settlement Engine con el mismo voucher resultan en **exactamente una liquidación exitosa**, y la segunda falla con `ALREADY_SETTLED`.

### 2.3 Formalización del `contextId` (Test 29)
Tipado y validación estricta de contextos para evitar colisiones:
- **SVC:** `contractId` o `svc:<contractId>`
- **IoT:** `iot:<service>:<meterId>`
- **Dispute:** `dispute:<disputeId>:<contractId>`
- **Market:** `market:<baseAsset>:<quoteAsset>`

### 2.4 Separación de `EconomicDecision` y `SettlementAuthorization` (Test 30)
Una decisión `ACCEPTED` genera un voucher `SettlementAuthorization` firmado con `nonce`, `policyHash` y tiempo de expiración. El Settlement Engine consume el voucher una única vez.

---

## 3. Matriz Completa de Pruebas (30 Tests Automatizados)

1. Multi-source aggregation & promotion to AGGREGATED
2. Pair-specific deviation policies (e.g. Energy 15% vs FX 5%)
3. Ed25519 canonical binary payload signatures
4. Monotonic sequence anti-replay defense
5. Administrative lifecycle status (ACTIVE, SUSPENDED, REVOKED)
6. Emergency pause per pair isolated from ledger
7. Poseidon BN254 quote evidence hash commitment
8. Market/Risk Policy: TwapTracker rolling TWAP
9. Market/Risk Policy: verifyAmmSpotSkew AMM circuit breaker
10. **Oracle -> SVC integration (Contract HOLD -> Attestation -> Settlement)**
11. **Oracle -> IoT integration (Measurement -> Attestation -> Tariff -> Settlement)**
12. **Oracle -> Dispute integration (Claim -> Poseidon Verification -> Award)**
13. Duplicate sequence rejection from same source
14. Cross-pair replay defense
15. Cross-contract replay defense
16. Cross-request replay defense
17. Suspended oracle exclusion from quorum
18. Revoked oracle complete exclusion
19. Pair pause does not alter UEP ledger state
20. **CRITICAL INVARIANT: Aggregation cannot trigger settlement**
21. Malformed canonical encoding rejection
22. Integer overflow & uint64 bounds enforcement
23. Zero / negative price rejection (PRICE_OUT_OF_BOUNDS)
24. Deterministic pair-specific policy precedence
25. Deterministic bit-by-bit aggregation and Poseidon hash
26. **HARDENING: Rejected policy leaves SMT root and ledger state 100% unchanged**
27. **HARDENING: Concurrent duplicate sequences race condition accepts exactly ONE**
28. **HARDENING: Concurrent double-settlement attempts allow exactly ONE settlement**
29. **HARDENING: Formal context binding validation (SVC, IoT, Dispute, Market)**
30. **HARDENING: EconomicDecision -> SettlementAuthorization voucher pipeline**
