# UEP Oracle Integration Guide — Milestone ORACLE-01

Developer guide for integrating **UEP Oracle Layer v0.1** into economic consumers:
1. **SVC (Service Value Contracts)**
2. **IoT & M2M Telemetry**
3. **Dispute Resolution Engine**
4. **AMM Constant-Product Pools**
5. **Marketplace Paymasters**

---

## 1. Case 1: SVC (Service Value Contract) Integration

```typescript
import { OracleAggregator } from "./src/oracle/index.ts";
import { evaluateSvcContractSettlement, type SvcContractHold } from "./src/oracle/risk-policy.ts";

// 1. Contract escrow created with active HOLD
const contract: SvcContractHold = {
  contractId: "svc-order-9001",
  payerAddress: "addr-alice",
  providerAddress: "addr-bob",
  holdAmount: 250_000_000n, // 250 tEUR
  assetId: "uep-test/teur",
  slaMinDeliveryE6: 95_000n, // Minimum 95k throughput SLA
  isHoldActive: true,
  settled: false,
};

// 2. Oracle aggregates evidence from authorized providers
const oracleResult = aggregator.read("uep-test/tcompute", "uep-test/teur");
if (!oracleResult.ok) {
  throw new Error(`Oracle unavailable: ${oracleResult.code}`);
}

// 3. Economic Policy evaluates evidence against contract SLA
const evaluation = evaluateSvcContractSettlement(contract, oracleResult.quote);

if (evaluation.decision === "ACCEPTED" && evaluation.paymentAuthorized) {
  // 4. Ledger settlement executed ONLY upon explicit ACCEPTED policy verdict
  ledger.releaseHold(contract.contractId, contract.providerAddress, evaluation.payableAmount!);
} else {
  console.warn("Settlement rejected by policy:", evaluation.reason);
}
```

---

## 2. Case 2: IoT Telemetry Metering Settlement

```typescript
import { evaluateIotMeterSettlement, type IotTariffPolicy } from "./src/oracle/risk-policy.ts";

const tariff: IotTariffPolicy = {
  meterAssetId: "uep-test/tenergy",
  settlementAssetId: "uep-test/teur",
  rateE6: 120_000n, // 0.12 tEUR per kWh
  maxAllowedSpikePpm: 50_000n,
};

// Oracle provides verified energy price evidence
const evidence = aggregator.read("uep-test/tenergy", "uep-test/teur").quote;

// Device reports 1,500 kWh consumed
const meterUnits = 1_500n;
const evaluation = evaluateIotMeterSettlement(meterUnits, evidence, tariff);

if (evaluation.decision === "ACCEPTED") {
  ledger.transfer(deviceOwner, utilityProvider, evaluation.settlementDue!, "uep-test/teur");
}
```

---

## 3. Case 3: Dispute Resolution Engine

```typescript
import { evaluateDisputeResolution, type DisputeClaim } from "./src/oracle/risk-policy.ts";
import { computeQuotePoseidonHash } from "./src/oracle/canonical.ts";

// Verifiable Poseidon BN254 evidence commitment
const evidenceHash = computeQuotePoseidonHash(signedAttestation);

const claim: DisputeClaim = {
  disputeId: "disp-101",
  contractId: "svc-order-9001",
  claimantAddress: "addr-alice",
  respondentAddress: "addr-bob",
  disputedAmount: 250_000_000n,
  expectedPoseidonHash: evidenceHash,
};

const resolution = evaluateDisputeResolution(claim, aggregatedEvidence, evidenceHash);

if (resolution.decision === "ACCEPTED") {
  ledger.awardDispute(claim.disputeId, resolution.awardRecipient!, resolution.awardAmount!);
}
```

---

## 4. Invariant Checklist for Integrators

- [x] Spends and transfers **never** query live oracles in consensus.
- [x] Oracle Layer produces `AGGREGATED` evidence; it **never** triggers ledger transfers.
- [x] Economic Policy determines `ACCEPTED` or `REJECTED_BY_POLICY`.
- [x] Replay protection is enforced across sequences, pairs, and contract contexts.
