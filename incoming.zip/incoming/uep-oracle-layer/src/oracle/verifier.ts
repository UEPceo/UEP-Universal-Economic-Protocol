/**
 * Universal Economic Protocol (UEP) — Oracle Cryptographic Verifier
 * Status: APPROVED ARCHITECTURE
 * 
 * Verifies Ed25519 signatures, enforces anti-replay via monotonic sequence numbers,
 * checks freshness / future clock drift, and verifies source administrative status.
 * 
 * Transition: ATTESTED -> VERIFIED
 */

import type { OraclePolicy, OracleQuote, SignedOracleQuote } from "./types.ts";
import { canonicalQuotePayload, assertCanonicalAssetPair } from "./canonical.ts";
import { OracleRegistry } from "./registry.ts";

export class OracleVerifier {
  private registry: OracleRegistry;
  private lastSequences = new Map<string, bigint>();

  constructor(registry: OracleRegistry) {
    this.registry = registry;
  }

  private seqKey(source: string, base: string, quote: string): string {
    return `${source}:${base}:${quote}`;
  }

  clearSequenceCache(): void {
    this.lastSequences.clear();
  }

  /**
   * Verifies an incoming quote against policy, registry authorization, anti-replay, and Ed25519 signature.
   */
  async verifyQuote(
    quote: OracleQuote | SignedOracleQuote,
    policy: OraclePolicy,
    nowMs: number = Date.now()
  ): Promise<{ ok: true; verifiedQuote: OracleQuote | SignedOracleQuote } | { ok: false; code: string; message: string }> {
    // 1. Asset pair syntax validation
    try {
      assertCanonicalAssetPair(quote.baseAssetId, quote.quoteAssetId);
    } catch (err: any) {
      return { ok: false, code: "PAIR_UNKNOWN", message: err.message };
    }

    // 2. Check if oracle system or pair is paused (Risk policy check)
    if (this.registry.isPairPaused(quote.baseAssetId, quote.quoteAssetId)) {
      return { ok: false, code: "PAIR_PAUSED", message: "Oracle feed for this pair is paused." };
    }

    // 3. Price bounds check
    if (quote.priceE6 <= 0n) {
      return { ok: false, code: "PRICE_OUT_OF_BOUNDS", message: "Price must be strictly positive." };
    }

    // 4. Source Registration & Administrative Lifecycle Check
    const regSource = this.registry.getSource(quote.source);
    if (regSource) {
      if (regSource.status === "SUSPENDED") {
        return {
          ok: false,
          code: "SOURCE_SUSPENDED",
          message: `Source '${quote.source}' is administratively SUSPENDED.`,
        };
      }
      if (regSource.status === "REVOKED") {
        return {
          ok: false,
          code: "UNAUTHORIZED_SOURCE",
          message: `Source '${quote.source}' authorization has been REVOKED.`,
        };
      }
    } else if (policy.requireSignatures) {
      return {
        ok: false,
        code: "UNAUTHORIZED_SOURCE",
        message: `Source '${quote.source}' is not registered in oracle registry.`,
      };
    }

    // Retrieve pair policy if configured, otherwise use default
    const pairPolicy = this.registry.getPairPolicy(quote.baseAssetId, quote.quoteAssetId);
    const maxStalenessMs = pairPolicy?.maxStalenessMs ?? policy.defaultMaxStalenessMs;

    // 5. Timestamp check (freshness + future drift)
    if (nowMs - quote.observedAtMs > maxStalenessMs) {
      return {
        ok: false,
        code: "STALE",
        message: `Quote observed ${nowMs - quote.observedAtMs}ms ago exceeds allowed staleness ${maxStalenessMs}ms.`,
      };
    }
    if (quote.observedAtMs - nowMs > policy.maxFutureDriftMs) {
      return {
        ok: false,
        code: "INVALID_TIMESTAMP",
        message: `Quote timestamp is in future by ${quote.observedAtMs - nowMs}ms (drift limit: ${policy.maxFutureDriftMs}ms).`,
      };
    }

    // 6. Anti-Replay: Sequence number must be strictly monotonic per (source, pair)
    const sk = this.seqKey(quote.source, quote.baseAssetId, quote.quoteAssetId);
    const lastSeq = this.lastSequences.get(sk);
    if (lastSeq !== undefined && quote.sequence <= lastSeq) {
      return {
        ok: false,
        code: "REPLAY_ATTACK",
        message: `Duplicate or backwards sequence ${quote.sequence} <= ${lastSeq} for source ${quote.source}.`,
      };
    }

    // 7. Cryptographic Signature Verification
    if (policy.requireSignatures) {
      const signedQuote = quote as SignedOracleQuote;
      if (!signedQuote.signature || !signedQuote.signerPublicKeyHex) {
        return {
          ok: false,
          code: "INVALID_SIGNATURE",
          message: "Signed quote missing signature or signer public key.",
        };
      }

      // Public key must match registered key
      if (regSource) {
        const expectedKey = regSource.publicKeyHex.toLowerCase();
        const actualKey = signedQuote.signerPublicKeyHex.toLowerCase();
        if (!expectedKey.endsWith(actualKey) && !actualKey.endsWith(expectedKey)) {
          return {
            ok: false,
            code: "UNAUTHORIZED_SOURCE",
            message: `Signer public key does not match registered key for source '${quote.source}'.`,
          };
        }
      }

      // Verify Ed25519 signature
      const validSig = await this.verifyEd25519Signature(signedQuote);
      if (!validSig) {
        return {
          ok: false,
          code: "INVALID_SIGNATURE",
          message: `Cryptographic signature verification failed for source '${quote.source}'.`,
        };
      }
    }

    // Update sequence number upon successful validation
    this.lastSequences.set(sk, quote.sequence);

    // Promote lifecycle stage to VERIFIED
    const verifiedQuote: OracleQuote | SignedOracleQuote = {
      ...quote,
      stage: "VERIFIED",
    };

    return { ok: true, verifiedQuote };
  }

  async verifyEd25519Signature(quote: SignedOracleQuote): Promise<boolean> {
    try {
      const payload = canonicalQuotePayload(quote);
      const sigBytes = hexToBytes(quote.signature);
      const pubKeyBytes = hexToBytes(quote.signerPublicKeyHex);

      if (typeof window === "undefined" && typeof process !== "undefined" && process.versions?.node) {
        try {
          const nodeCrypto = await (Function('return import("node:crypto")')());
          const derHex = quote.signerPublicKeyHex.length === 64
            ? "302a300506032b6570032100" + quote.signerPublicKeyHex
            : quote.signerPublicKeyHex;
          const keyObj = nodeCrypto.createPublicKey({
            key: Buffer.from(derHex, "hex"),
            type: "spki",
            format: "der",
          });
          return nodeCrypto.verify(null, payload, keyObj, Buffer.from(sigBytes));
        } catch {
          // fallback to web crypto
        }
      }

      if (typeof crypto !== "undefined" && crypto.subtle) {
        const rawKey = pubKeyBytes.length > 32 ? pubKeyBytes.subarray(pubKeyBytes.length - 32) : pubKeyBytes;
        const cryptoKey = await crypto.subtle.importKey(
          "raw",
          rawKey as any,
          { name: "Ed25519" },
          false,
          ["verify"]
        );
        return await crypto.subtle.verify("Ed25519", cryptoKey, sigBytes as any, payload as any);
      }

      return false;
    } catch {
      return false;
    }
  }
}

function hexToBytes(hex: string): Uint8Array {
  const clean = hex.trim().replace(/^0x/i, "");
  const bytes = new Uint8Array(clean.length / 2);
  for (let i = 0; i < clean.length; i += 2) {
    bytes[i / 2] = parseInt(clean.substring(i, i + 2), 16);
  }
  return bytes;
}
