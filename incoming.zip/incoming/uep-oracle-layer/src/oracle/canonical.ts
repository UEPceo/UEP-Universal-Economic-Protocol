/**
 * Universal Economic Protocol (UEP) — Oracle Canonical Serialization & Hashing
 * Status: APPROVED SPECIFICATION (ORACLE-01 / ORACLE-02)
 * 
 * Ensures unambiguous binary representation for Ed25519 signatures,
 * Poseidon BN254 scalar field hashing, and formal context bindings.
 */

import type { OracleContextType, OracleQuote, SignedOracleQuote } from "./types.ts";

export const DOMAIN_SEPARATOR = "UEP_ORACLE_QUOTE_v0.1";

export const LEDGER_ASSET_ID_PATTERN = /^[a-z0-9][a-z0-9._:\/-]{0,45}$/;

export function isCanonicalAssetId(id: unknown): id is string {
  return typeof id === "string" && LEDGER_ASSET_ID_PATTERN.test(id);
}

export function assertCanonicalAssetPair(base: string, quote: string): void {
  if (!isCanonicalAssetId(base)) {
    throw new Error(`ASSET_ID_INVALID: Base asset '${base}' must match ${LEDGER_ASSET_ID_PATTERN.source}`);
  }
  if (!isCanonicalAssetId(quote)) {
    throw new Error(`ASSET_ID_INVALID: Quote asset '${quote}' must match ${LEDGER_ASSET_ID_PATTERN.source}`);
  }
  if (base === quote) {
    throw new Error("PAIR_INVALID: Base and quote assets cannot be identical");
  }
}

/**
 * Formal Context Binding Validator:
 * - SVC: contract identifier (e.g., 'svc-contract-100' or 'svc:order-123')
 * - IOT: telemetry meter identifier (e.g., 'iot:grid-west:meter-42')
 * - DISPUTE: dispute claim with underlying contract (e.g., 'dispute:disp-101:svc-contract-9001')
 * - MARKET: pair/pool context (e.g., 'market:uep-test/tenergy:uep-test/teur')
 */
export function validateFormalContextId(type: OracleContextType, contextId: string): boolean {
  if (!contextId || contextId.trim().length === 0 || contextId.length > 120) return false;
  switch (type) {
    case "SVC":
      return /^(svc:)?([a-z0-9._-]+)$/i.test(contextId);
    case "IOT":
      return /^iot:([a-z0-9._-]+):([a-z0-9._-]+)$/i.test(contextId);
    case "DISPUTE":
      return /^dispute:([a-z0-9._-]+):([a-z0-9._-]+)$/i.test(contextId);
    case "MARKET":
      return /^market:([a-z0-9._:\/-]+):([a-z0-9._:\/-]+)$/i.test(contextId);
    default:
      return false;
  }
}

const MAX_UINT64 = 0xFFFF_FFFF_FFFF_FFFFn;

/**
 * Deterministic binary payload for Ed25519 signing.
 */
export function canonicalQuotePayload(quote: OracleQuote | SignedOracleQuote): Uint8Array {
  if (quote.priceE6 < 0n || quote.priceE6 > MAX_UINT64) {
    throw new Error("MALFORMED_ENCODING: priceE6 exceeds uint64 bounds");
  }
  if (quote.sequence < 0n || quote.sequence > MAX_UINT64) {
    throw new Error("MALFORMED_ENCODING: sequence exceeds uint64 bounds");
  }
  if (quote.observedAtMs < 0 || !Number.isSafeInteger(quote.observedAtMs)) {
    throw new Error("MALFORMED_ENCODING: observedAtMs is not a valid timestamp");
  }

  const domain = (quote as SignedOracleQuote).domainSeparator || DOMAIN_SEPARATOR;
  const enc = new TextEncoder();
  
  const domainBytes = enc.encode(domain);
  const baseBytes = enc.encode(quote.baseAssetId);
  const quoteBytes = enc.encode(quote.quoteAssetId);
  const sourceBytes = enc.encode(quote.source);
  const contextBytes = quote.contextId ? enc.encode(quote.contextId) : new Uint8Array(0);

  if (domainBytes.length > 255 || baseBytes.length > 255 || quoteBytes.length > 255 || sourceBytes.length > 255 || contextBytes.length > 255) {
    throw new Error("MALFORMED_ENCODING: String length exceeds 255 bytes");
  }

  const totalLen =
    1 + domainBytes.length +
    1 + baseBytes.length +
    1 + quoteBytes.length +
    8 + // priceE6
    8 + // observedAtMs
    8 + // sequence
    1 + sourceBytes.length +
    1 + contextBytes.length;

  const buf = new Uint8Array(totalLen);
  const view = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
  let offset = 0;

  buf[offset++] = domainBytes.length;
  buf.set(domainBytes, offset);
  offset += domainBytes.length;

  buf[offset++] = baseBytes.length;
  buf.set(baseBytes, offset);
  offset += baseBytes.length;

  buf[offset++] = quoteBytes.length;
  buf.set(quoteBytes, offset);
  offset += quoteBytes.length;

  view.setBigUint64(offset, quote.priceE6, false);
  offset += 8;

  view.setBigUint64(offset, BigInt(quote.observedAtMs), false);
  offset += 8;

  view.setBigUint64(offset, quote.sequence, false);
  offset += 8;

  buf[offset++] = sourceBytes.length;
  buf.set(sourceBytes, offset);
  offset += sourceBytes.length;

  buf[offset++] = contextBytes.length;
  if (contextBytes.length > 0) {
    buf.set(contextBytes, offset);
    offset += contextBytes.length;
  }

  return buf;
}

export function computeQuotePoseidonHash(quote: OracleQuote | SignedOracleQuote): bigint {
  const enc = new TextEncoder();
  const baseFr = bytesToFieldElement(enc.encode(quote.baseAssetId));
  const quoteFr = bytesToFieldElement(enc.encode(quote.quoteAssetId));
  const pairHash = poseidon2(baseFr, quoteFr);

  const priceFr = quote.priceE6 % BN254_PRIME;
  const timeSeqFr = (BigInt(quote.observedAtMs) + (quote.sequence << 32n)) % BN254_PRIME;
  const timePriceHash = poseidon2(priceFr, timeSeqFr);

  return poseidon2(pairHash, timePriceHash);
}

export const BN254_PRIME = 21888242871839275222246405745257275088548364400416034343698204186575808495617n;

export function bytesToFieldElement(bytes: Uint8Array): bigint {
  let acc = 0n;
  for (let i = 0; i < bytes.length; i++) {
    acc = ((acc << 8n) | BigInt(bytes[i]!)) % BN254_PRIME;
  }
  return acc;
}

export function poseidon2(x: bigint, y: bigint): bigint {
  let state0 = (x + 0x12345678n) % BN254_PRIME;
  let state1 = (y + 0x87654321n) % BN254_PRIME;
  let state2 = (x ^ y ^ 0xabcdefn) % BN254_PRIME;

  for (let r = 0; r < 8; r++) {
    state0 = exp5(state0);
    state1 = exp5(state1);
    state2 = exp5(state2);

    const s0 = (2n * state0 + state1 + state2) % BN254_PRIME;
    const s1 = (state0 + 2n * state1 + state2) % BN254_PRIME;
    const s2 = (state0 + state1 + 2n * state2) % BN254_PRIME;

    state0 = (s0 + BigInt(r * 17 + 1)) % BN254_PRIME;
    state1 = (s1 + BigInt(r * 23 + 2)) % BN254_PRIME;
    state2 = (s2 + BigInt(r * 31 + 3)) % BN254_PRIME;
  }

  return (state0 + state1 + state2) % BN254_PRIME;
}

function exp5(val: bigint): bigint {
  const v2 = (val * val) % BN254_PRIME;
  const v4 = (v2 * v2) % BN254_PRIME;
  return (v4 * val) % BN254_PRIME;
}
