/**
 * Universal Economic Protocol (UEP) — Oracle Registry
 * Status: APPROVED ARCHITECTURE
 * 
 * Tracks authorized oracle feeds, public keys, registry weights,
 * administrative lifecycle (ACTIVE/SUSPENDED/REVOKED), and pair-specific risk policies.
 * 
 * Principle: Registry weight is an administrative trust parameter, NOT economic token stake.
 */

import type { OraclePairPolicy, OracleSourceRegistration, OracleSourceStatus } from "./types.ts";
import { assertCanonicalAssetPair } from "./canonical.ts";

export class OracleRegistry {
  private sources = new Map<string, OracleSourceRegistration>();
  private pairPolicies = new Map<string, OraclePairPolicy>();
  private globalPaused = false;

  constructor() {}

  setGlobalPaused(paused: boolean): void {
    this.globalPaused = paused;
  }

  isGlobalPaused(): boolean {
    return this.globalPaused;
  }

  // --- Source Registration & Administration ---

  registerSource(source: OracleSourceRegistration): void {
    if (!source.sourceId || source.sourceId.trim().length === 0) {
      throw new Error("ORACLE_REGISTRY: Source ID cannot be empty");
    }
    if (!source.publicKeyHex || source.publicKeyHex.trim().length < 64) {
      throw new Error("ORACLE_REGISTRY: Invalid public key hex length");
    }
    this.sources.set(source.sourceId, {
      ...source,
      weight: Math.max(1, Math.min(100, source.weight)),
      status: source.status || "ACTIVE",
      registeredAtMs: source.registeredAtMs || Date.now(),
    });
  }

  getSource(sourceId: string): OracleSourceRegistration | undefined {
    return this.sources.get(sourceId);
  }

  getAllSources(): OracleSourceRegistration[] {
    return Array.from(this.sources.values());
  }

  setSourceStatus(sourceId: string, status: OracleSourceStatus): void {
    const src = this.sources.get(sourceId);
    if (!src) return;
    src.status = status;
  }

  // --- Pair-Specific Policies (Custom Staleness, Deviation, Quorum) ---

  private pairKey(base: string, quote: string): string {
    return `${base}|${quote}`;
  }

  setPairPolicy(policy: OraclePairPolicy): void {
    assertCanonicalAssetPair(policy.baseAssetId, policy.quoteAssetId);
    this.pairPolicies.set(this.pairKey(policy.baseAssetId, policy.quoteAssetId), { ...policy });
  }

  getPairPolicy(base: string, quote: string): OraclePairPolicy | undefined {
    return this.pairPolicies.get(this.pairKey(base, quote));
  }

  /**
   * Emergency Pause per Pair:
   * Blocks market/economic modules relying on this pair while the UEP ledger continues normally.
   */
  setPairPaused(base: string, quote: string, paused: boolean): void {
    const p = this.pairPolicies.get(this.pairKey(base, quote));
    if (p) {
      p.paused = paused;
    } else {
      this.setPairPolicy({
        baseAssetId: base,
        quoteAssetId: quote,
        maxStalenessMs: 60_000,
        maxDeviationPpm: 50_000n,
        minSources: 1,
        paused,
      });
    }
  }

  isPairPaused(base: string, quote: string): boolean {
    if (this.globalPaused) return true;
    const p = this.pairPolicies.get(this.pairKey(base, quote));
    return p?.paused ?? false;
  }
}
