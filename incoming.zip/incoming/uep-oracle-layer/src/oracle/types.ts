/**
 * Universal Economic Protocol (UEP) — Oracle Layer v0.1
 * Milestone: ORACLE-01 / ORACLE-02 Production Hardening
 * 
 * Scope: Verifiable economic evidence layer for UEP.
 * Core Responsibility: Register -> Authenticate -> Verify -> Anti-Replay -> Aggregate.
 * 
 * DEFINITIVE PIPELINE:
 * EXTERNAL WORLD (Oracle / Device)
 *      │
 *   ATTESTATION
 *      │
 *   Oracle Core (Verify -> Anti-Replay -> Aggregate)
 *      │
 *   AGGREGATED
 *      │
 *   Economic/Risk Policy
 *      │
 *   ACCEPTED / REJECTED_BY_POLICY
 *      │
 *   Settlement Authorization (Verifiable, single-use voucher)
 *      │
 *   Settlement Engine
 *      │
 *   UEP Ledger (SMT root, note commitments, nullifiers, balances)
 * 
 * Invariants:
 * 1. Oracle Core never modifies ledger.
 * 2. Economic Policy never modifies ledger.
 * 3. Only Settlement Engine executes transitions using single-use SettlementAuthorization.
 */

export const PRICE_SCALE = 1_000_000n; // 1e6 fixed point representation
export const PPM_SCALE = 1_000_000n;   // Parts per million (1_000_000 = 100%, 50_000 = 5%)

export type EvidenceStage = "OBSERVED" | "ATTESTED" | "VERIFIED" | "AGGREGATED";

export type EconomicDecision = "ACCEPTED" | "REJECTED_BY_POLICY";

/**
 * Formal Context Binding:
 * - SVC: contractId
 * - IoT: service/request context (e.g., 'iot:grid-west:meter-42')
 * - Dispute: disputeId + underlying contract (e.g., 'dispute:disp-101:svc-contract-9001')
 * - Market: market/pair context (e.g., 'market:uep-test/tenergy:uep-test/teur')
 */
export type OracleContextType = "SVC" | "IOT" | "DISPUTE" | "MARKET";

export interface OracleContextBinding {
  type: OracleContextType;
  contextId: string;
}

export interface EconomicEvaluation {
  decision: EconomicDecision;
  reason?: string;
  aggregatedQuote: AggregatedQuote;
  evaluatedAtMs: number;
}

/**
 * Verifiable Single-Use Voucher issued by Economic Policy:
 * Consumed exclusively by the Settlement Engine.
 */
export interface SettlementAuthorization {
  authorized: true;
  decisionId: string;
  contextId: string;
  policyHash: string;
  authorizedAmount: bigint;
  recipientAddress: string;
  assetId: string;
  issuedAtMs: number;
  expiresAtMs: number;
  nonce: string;
}

export interface LedgerStateSnapshot {
  smtRootHex: string;
  noteCount: number;
  nullifierCount: number;
  totalBalance: bigint;
}

export type OracleSourceStatus = "ACTIVE" | "SUSPENDED" | "REVOKED";

export type OracleErrorCode =
  | "STALE"
  | "DEVIATION"
  | "NO_SOURCES"
  | "PAIR_UNKNOWN"
  | "INVALID_SIGNATURE"
  | "UNAUTHORIZED_SOURCE"
  | "SOURCE_SUSPENDED"
  | "REPLAY_ATTACK"
  | "INVALID_TIMESTAMP"
  | "PRICE_OUT_OF_BOUNDS"
  | "CANONICAL_HASH_MISMATCH"
  | "PAIR_PAUSED"
  | "MALFORMED_ENCODING"
  | "CROSS_CONTEXT_REPLAY"
  | "INVALID_CONTEXT_FORMAT"
  | "ALREADY_SETTLED";

export interface OracleQuote {
  stage: EvidenceStage;
  baseAssetId: string;
  quoteAssetId: string;
  priceE6: bigint;
  source: string;
  sequence: bigint;
  observedAtMs: number;
  contextId?: string;
  attestation?: string;
}

export interface SignedOracleQuote extends OracleQuote {
  signature: string;
  signerPublicKeyHex: string;
  domainSeparator?: string;
  quoteHash?: string;
}

export interface AggregatedQuote {
  stage: "AGGREGATED";
  baseAssetId: string;
  quoteAssetId: string;
  priceE6: bigint;
  sourcesUsed: number;
  minPriceE6: bigint;
  maxPriceE6: bigint;
  observedAtMs: number;
  aggregatedAtMs: number;
  contextId?: string;
  sources: Array<{
    source: string;
    priceE6: bigint;
    observedAtMs: number;
    weight: number;
  }>;
}

export type OracleReject =
  | { ok: false; code: OracleErrorCode; message: string }
  | { ok: true; quote: AggregatedQuote };

export interface OraclePairPolicy {
  baseAssetId: string;
  quoteAssetId: string;
  maxStalenessMs: number;
  maxDeviationPpm: bigint;
  minSources: number;
  paused?: boolean;
}

export interface OraclePolicy {
  defaultMaxStalenessMs: number;
  maxFutureDriftMs: number;
  defaultMaxDeviationPpm: bigint;
  defaultMinSources: number;
  requireSignatures: boolean;
  useWeightedMedian: boolean;
}

export const DEFAULT_ORACLE_POLICY: OraclePolicy = {
  defaultMaxStalenessMs: 60_000,
  maxFutureDriftMs: 5_000,
  defaultMaxDeviationPpm: 50_000n,
  defaultMinSources: 2,
  requireSignatures: true,
  useWeightedMedian: true,
};

export interface OracleSourceRegistration {
  sourceId: string;
  displayName: string;
  publicKeyHex: string;
  weight: number;
  status: OracleSourceStatus;
  reputationMetadata?: {
    uptimeScore: number;
    totalReports: number;
    lastAuditTimestampMs?: number;
  };
  registeredAtMs: number;
  lastSeenMs?: number;
}
