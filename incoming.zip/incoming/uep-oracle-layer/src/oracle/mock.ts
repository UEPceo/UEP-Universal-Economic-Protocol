/**
 * Universal Economic Protocol (UEP) — Mock Oracle Feeds and Chaos Simulator
 * Status: APPROVED ARCHITECTURE
 */

import { OracleAggregator } from "./index.ts";
import type { OracleQuote, SignedOracleQuote } from "./types.ts";
import { canonicalQuotePayload, DOMAIN_SEPARATOR } from "./canonical.ts";

export interface MockNodeConfig {
  sourceId: string;
  displayName: string;
  weight: number;
  privateKeyHex?: string;
  publicKeyHex?: string;
}

export class MockOracleNode {
  public config: MockNodeConfig;
  private sequence: bigint = 1n;

  constructor(config: MockNodeConfig) {
    this.config = { ...config };
    if (!this.config.publicKeyHex) {
      this.config.publicKeyHex = "a".repeat(64);
    }
  }

  getNextSequence(): bigint {
    return this.sequence++;
  }

  createQuote(
    baseAssetId: string,
    quoteAssetId: string,
    priceE6: bigint,
    observedAtMs: number = Date.now(),
    overrideSequence?: bigint
  ): OracleQuote {
    return {
      stage: "ATTESTED",
      baseAssetId,
      quoteAssetId,
      priceE6,
      source: this.config.sourceId,
      sequence: overrideSequence !== undefined ? overrideSequence : this.getNextSequence(),
      observedAtMs,
    };
  }

  async createSignedQuote(
    baseAssetId: string,
    quoteAssetId: string,
    priceE6: bigint,
    observedAtMs: number = Date.now(),
    overrideSequence?: bigint
  ): Promise<SignedOracleQuote> {
    const raw = this.createQuote(baseAssetId, quoteAssetId, priceE6, observedAtMs, overrideSequence);
    const payload = canonicalQuotePayload(raw);

    let sigHex = "00".repeat(64);

    if (typeof window === "undefined" && typeof process !== "undefined" && process.versions?.node) {
      try {
        const nodeCrypto = await (Function('return import("node:crypto")')());
        const { privateKey, publicKey } = nodeCrypto.generateKeyPairSync("ed25519");
        const sig = nodeCrypto.sign(null, payload, privateKey);
        sigHex = sig.toString("hex");
        const spki = publicKey.export({ type: "spki", format: "der" }) as any;
        this.config.publicKeyHex = Buffer.from(spki).toString("hex");
      } catch {
        // Fallback
      }
    }

    return {
      ...raw,
      stage: "ATTESTED",
      signature: sigHex,
      signerPublicKeyHex: this.config.publicKeyHex || "00".repeat(32),
      domainSeparator: DOMAIN_SEPARATOR,
    };
  }
}

export const DEFAULT_MOCK_PAIRS: Array<{
  base: string;
  quote: string;
  defaultPriceE6: bigint;
  name: string;
}> = [
  { base: "uep-test/tenergy", quote: "uep-test/teur", defaultPriceE6: 120_000n, name: "tENERGY / tEUR" },
  { base: "uep-test/tbtc", quote: "uep-test/teur", defaultPriceE6: 64_500_000_000n, name: "tBTC / tEUR" },
  { base: "uep-test/tdata", quote: "uep-test/teur", defaultPriceE6: 50_000n, name: "tDATA / tEUR" },
  { base: "uep-test/tcompute", quote: "uep-test/teur", defaultPriceE6: 350_000n, name: "tCOMPUTE / tEUR" },
];

export function seedTestnetOracles(agg: OracleAggregator, nowMs: number = Date.now()): void {
  const nodes = [
    { id: "sim-feed-alpha", name: "Primary Validator Feed", weight: 35 },
    { id: "sim-feed-beta", name: "Energy Exchange Gateway", weight: 25 },
    { id: "sim-feed-gamma", name: "Decentralized Meter Node", weight: 20 },
    { id: "sim-feed-delta", name: "Secondary Market Watcher", weight: 20 },
  ];

  for (const n of nodes) {
    agg.registry.registerSource({
      sourceId: n.id,
      displayName: n.name,
      publicKeyHex: "302a300506032b6570032100" + "ab".repeat(32),
      weight: n.weight,
      status: "ACTIVE",
      registeredAtMs: nowMs - 3600_000,
    });
  }

  const quotes: Array<[string, string, bigint, string, bigint]> = [
    ["uep-test/tenergy", "uep-test/teur", 120_000n, "sim-feed-alpha", 1n],
    ["uep-test/tenergy", "uep-test/teur", 120_400n, "sim-feed-beta", 1n],
    ["uep-test/tenergy", "uep-test/teur", 119_800n, "sim-feed-gamma", 1n],
    ["uep-test/tenergy", "uep-test/teur", 120_150n, "sim-feed-delta", 1n],

    ["uep-test/tbtc", "uep-test/teur", 64_500_000_000n, "sim-feed-alpha", 1n],
    ["uep-test/tbtc", "uep-test/teur", 64_550_000_000n, "sim-feed-beta", 1n],
    ["uep-test/tbtc", "uep-test/teur", 64_480_000_000n, "sim-feed-gamma", 1n],

    ["uep-test/tdata", "uep-test/teur", 50_000n, "sim-feed-alpha", 1n],
    ["uep-test/tdata", "uep-test/teur", 50_200n, "sim-feed-beta", 1n],

    ["uep-test/tcompute", "uep-test/teur", 350_000n, "sim-feed-alpha", 1n],
    ["uep-test/tcompute", "uep-test/teur", 349_500n, "sim-feed-beta", 1n],
    ["uep-test/tcompute", "uep-test/teur", 350_800n, "sim-feed-gamma", 1n],
  ];

  for (const [base, quote, priceE6, source, seq] of quotes) {
    agg.publishSync({
      stage: "ATTESTED",
      baseAssetId: base,
      quoteAssetId: quote,
      priceE6,
      source,
      sequence: seq,
      observedAtMs: nowMs,
    });
  }
}
