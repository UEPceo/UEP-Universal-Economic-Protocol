/**
 * Universal Economic Protocol (UEP) — Oracle Core Layer v0.1
 * 
 * Core Responsibility:
 * Register -> Authenticate -> Verify -> Anti-Replay -> Aggregate -> Produce Verifiable Economic Evidence.
 * 
 * Invariants:
 * - Pure evidence aggregator, completely agnostic of AMM, Paymaster, and Staking.
 * - Sybil resistance = Weighted median + Controlled Oracle Registry.
 * - Consumed by SVC, IoT, AMM, Paymaster, and Dispute Engine.
 */

import { DEFAULT_ORACLE_POLICY, PPM_SCALE } from "./types.ts";
import type {
  AggregatedQuote,
  OracleErrorCode,
  OraclePairPolicy,
  OraclePolicy,
  OracleQuote,
  OracleReject,
  SignedOracleQuote,
} from "./types.ts";
import { OracleRegistry } from "./registry.ts";
import { OracleVerifier } from "./verifier.ts";

export * from "./types.ts";
export * from "./canonical.ts";
export * from "./registry.ts";
export * from "./verifier.ts";

export class OracleAggregator {
  public policy: OraclePolicy;
  public registry: OracleRegistry;
  public verifier: OracleVerifier;

  /** Active verified quotes indexed by `${base}|${quote}` -> latest quotes per source */
  private feeds = new Map<string, (OracleQuote | SignedOracleQuote)[]>();

  constructor(policy: Partial<OraclePolicy> = {}, registry?: OracleRegistry) {
    this.policy = { ...DEFAULT_ORACLE_POLICY, ...policy };
    this.registry = registry ?? new OracleRegistry();
    this.verifier = new OracleVerifier(this.registry);
  }

  private key(base: string, quote: string): string {
    return `${base}|${quote}`;
  }

  /**
   * Publishes a new quote from a source, executing cryptographic and semantic verification.
   * On success, promotes quote to stage 'VERIFIED' and stores in the active feed.
   */
  async publish(
    quote: OracleQuote | SignedOracleQuote,
    nowMs: number = Date.now()
  ): Promise<{ ok: boolean; code?: string; message?: string }> {
    const check = await this.verifier.verifyQuote(quote, this.policy, nowMs);
    if (!check.ok) {
      return check;
    }

    const verifiedQuote = check.verifiedQuote;
    const k = this.key(quote.baseAssetId, quote.quoteAssetId);
    const list = this.feeds.get(k) ?? [];
    const next = list.filter((q) => q.source !== quote.source);
    next.push(verifiedQuote);
    this.feeds.set(k, next);

    const regSource = this.registry.getSource(quote.source);
    if (regSource) {
      regSource.lastSeenMs = nowMs;
    }

    return { ok: true };
  }

  /**
   * Synchronous publish for testnet / simulation where signatures are verified upfront.
   */
  publishSync(quote: OracleQuote): void {
    const k = this.key(quote.baseAssetId, quote.quoteAssetId);
    const list = this.feeds.get(k) ?? [];
    const next = list.filter((q) => q.source !== quote.source);
    next.push({
      ...quote,
      stage: "VERIFIED",
    });
    this.feeds.set(k, next);
  }

  clear(): void {
    this.feeds.clear();
    this.verifier.clearSequenceCache();
  }

  /**
   * Aggregates active verified quotes for an asset pair into consolidated economic evidence.
   * Uses pair-specific policies (custom deviation PPM, custom staleness, min quorum).
   */
  read(baseAssetId: string, quoteAssetId: string, nowMs: number = Date.now()): OracleReject {
    if (this.registry.isPairPaused(baseAssetId, quoteAssetId)) {
      return {
        ok: false,
        code: "PAIR_PAUSED",
        message: `Oracle feed for ${baseAssetId}/${quoteAssetId} is paused by risk policy.`,
      };
    }

    const pairPolicy = this.registry.getPairPolicy(baseAssetId, quoteAssetId);
    const maxStalenessMs = pairPolicy?.maxStalenessMs ?? this.policy.defaultMaxStalenessMs;
    const minSources = pairPolicy?.minSources ?? this.policy.defaultMinSources;
    const maxDevPpm = pairPolicy?.maxDeviationPpm ?? this.policy.defaultMaxDeviationPpm;

    const list = this.feeds.get(this.key(baseAssetId, quoteAssetId)) ?? [];
    if (list.length === 0) {
      return {
        ok: false,
        code: "PAIR_UNKNOWN",
        message: `No active oracle sources published for pair '${baseAssetId}/${quoteAssetId}'.`,
      };
    }

    // Filter fresh quotes
    const fresh = list.filter((q) => nowMs - q.observedAtMs <= maxStalenessMs);
    if (fresh.length === 0) {
      return {
        ok: false,
        code: "STALE",
        message: `All oracle quotes for '${baseAssetId}/${quoteAssetId}' are stale (older than ${maxStalenessMs}ms).`,
      };
    }

    if (fresh.length < minSources) {
      return {
        ok: false,
        code: "NO_SOURCES",
        message: `Insufficient independent sources: requires ≥ ${minSources}, but only ${fresh.length} fresh source(s) available.`,
      };
    }

    // Sort quotes by price
    const sorted = [...fresh].sort((a, b) => (a.priceE6 < b.priceE6 ? -1 : a.priceE6 > b.priceE6 ? 1 : 0));
    const minPrice = sorted[0]!.priceE6;
    const maxPrice = sorted[sorted.length - 1]!.priceE6;

    // Pair-specific relative deviation check: (max - min) / min
    if (minPrice > 0n) {
      const devPpm = ((maxPrice - minPrice) * PPM_SCALE) / minPrice;
      if (devPpm > maxDevPpm) {
        return {
          ok: false,
          code: "DEVIATION",
          message: `Source deviation ${devPpm} PPM exceeds pair policy limit ${maxDevPpm} PPM (${Number(maxDevPpm) / 10_000}%).`,
        };
      }
    }

    // Compute consolidated median price (weighted by registry weight if enabled)
    let consolidatedPrice: bigint;
    if (this.policy.useWeightedMedian) {
      consolidatedPrice = this.computeWeightedMedian(sorted);
    } else {
      consolidatedPrice = sorted[Math.floor(sorted.length / 2)]!.priceE6;
    }

    const observedAtMs = Math.min(...fresh.map((q) => q.observedAtMs));
    const sharedContextId = fresh.every((q) => q.contextId === fresh[0]?.contextId) ? fresh[0]?.contextId : undefined;

    const sourceBreakdown = fresh.map((q) => {
      const reg = this.registry.getSource(q.source);
      return {
        source: q.source,
        priceE6: q.priceE6,
        observedAtMs: q.observedAtMs,
        weight: reg && reg.status === "ACTIVE" ? reg.weight : 1,
      };
    });

    return {
      ok: true,
      quote: {
        stage: "AGGREGATED",
        baseAssetId,
        quoteAssetId,
        priceE6: consolidatedPrice,
        sourcesUsed: fresh.length,
        minPriceE6: minPrice,
        maxPriceE6: maxPrice,
        observedAtMs,
        aggregatedAtMs: nowMs,
        contextId: sharedContextId,
        sources: sourceBreakdown,
      },
    };
  }

  /**
   * Registry-Weighted Median Calculation.
   * Ensures Sybil resistance in conjunction with the controlled Oracle Registry.
   */
  private computeWeightedMedian(sortedQuotes: (OracleQuote | SignedOracleQuote)[]): bigint {
    const items = sortedQuotes.map((q) => {
      const reg = this.registry.getSource(q.source);
      const weight = reg && reg.status === "ACTIVE" ? Math.max(1, reg.weight) : 1;
      return { priceE6: q.priceE6, weight };
    });

    const totalWeight = items.reduce((acc, curr) => acc + curr.weight, 0);
    const halfWeight = totalWeight / 2;

    let accumulated = 0;
    for (const item of items) {
      accumulated += item.weight;
      if (accumulated >= halfWeight) {
        return item.priceE6;
      }
    }

    return items[Math.floor(items.length / 2)]!.priceE6;
  }
}
