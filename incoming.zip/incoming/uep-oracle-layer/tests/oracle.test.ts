import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { generateKeyPairSync, sign } from "node:crypto";
import {
  OracleAggregator,
  OracleRegistry,
  PRICE_SCALE,
  PPM_SCALE,
  canonicalQuotePayload,
  computeQuotePoseidonHash,
  validateFormalContextId,
  DOMAIN_SEPARATOR,
  type OracleQuote,
  type SignedOracleQuote,
  type AggregatedQuote,
} from "../src/oracle/index.ts";
import {
  TwapTracker,
  verifyAmmSpotSkew,
  resolvePaymasterRate,
  evaluateSvcContractSettlement,
  evaluateIotMeterSettlement,
  evaluateDisputeResolution,
  issueSettlementAuthorization,
  MockSettlementEngine,
  type SvcContractHold,
  type IotTariffPolicy,
  type DisputeClaim,
} from "../src/oracle/risk-policy.ts";

describe("UEP Oracle Layer v0.1 — Milestone ORACLE-01 / ORACLE-02 Production Suite (30 Tests)", () => {
  // Test 1
  it("1. aggregates multi-source quotes and promotes lifecycle to AGGREGATED", () => {
    const agg = new OracleAggregator({ defaultMinSources: 3, defaultMaxStalenessMs: 10_000 });
    const now = 100_000;

    agg.publishSync({ stage: "ATTESTED", baseAssetId: "uep-test/tenergy", quoteAssetId: "uep-test/teur", priceE6: 120_000n, source: "s1", sequence: 1n, observedAtMs: now - 1000 });
    agg.publishSync({ stage: "ATTESTED", baseAssetId: "uep-test/tenergy", quoteAssetId: "uep-test/teur", priceE6: 121_000n, source: "s2", sequence: 1n, observedAtMs: now - 2000 });
    agg.publishSync({ stage: "ATTESTED", baseAssetId: "uep-test/tenergy", quoteAssetId: "uep-test/teur", priceE6: 119_500n, source: "s3", sequence: 1n, observedAtMs: now - 500 });

    const res = agg.read("uep-test/tenergy", "uep-test/teur", now);
    assert.equal(res.ok, true);
    if (res.ok) {
      assert.equal(res.quote.stage, "AGGREGATED");
      assert.equal(res.quote.sourcesUsed, 3);
      assert.equal(res.quote.minPriceE6, 119_500n);
      assert.equal(res.quote.maxPriceE6, 121_000n);
      assert.equal(res.quote.priceE6, 120_000n);
    }
  });

  // Test 2
  it("2. enforces pair-specific deviation policies (e.g. Energy 15% vs FX 5%)", () => {
    const reg = new OracleRegistry();
    const agg = new OracleAggregator({ defaultMaxDeviationPpm: 50_000n }, reg);
    const now = 100_000;

    reg.setPairPolicy({
      baseAssetId: "uep-test/tenergy",
      quoteAssetId: "uep-test/teur",
      maxDeviationPpm: 150_000n,
      maxStalenessMs: 60_000,
      minSources: 2,
    });

    agg.publishSync({ stage: "ATTESTED", baseAssetId: "uep-test/tenergy", quoteAssetId: "uep-test/teur", priceE6: 100_000n, source: "s1", sequence: 1n, observedAtMs: now });
    agg.publishSync({ stage: "ATTESTED", baseAssetId: "uep-test/tenergy", quoteAssetId: "uep-test/teur", priceE6: 110_000n, source: "s2", sequence: 1n, observedAtMs: now });

    const energyRes = agg.read("uep-test/tenergy", "uep-test/teur", now);
    assert.equal(energyRes.ok, true);

    agg.publishSync({ stage: "ATTESTED", baseAssetId: "uep-test/tbtc", quoteAssetId: "uep-test/teur", priceE6: 60_000_000_000n, source: "s1", sequence: 1n, observedAtMs: now });
    agg.publishSync({ stage: "ATTESTED", baseAssetId: "uep-test/tbtc", quoteAssetId: "uep-test/teur", priceE6: 66_500_000_000n, source: "s2", sequence: 1n, observedAtMs: now });

    const btcRes = agg.read("uep-test/tbtc", "uep-test/teur", now);
    assert.equal(btcRes.ok, false);
    if (!btcRes.ok) assert.equal(btcRes.code, "DEVIATION");
  });

  // Test 3
  it("3. verifies Ed25519 signatures and rejects tampered quotes", async () => {
    const reg = new OracleRegistry();
    const agg = new OracleAggregator({ requireSignatures: true }, reg);

    const { publicKey, privateKey } = generateKeyPairSync("ed25519");
    const pubKeySpkiHex = (publicKey.export({ type: "spki", format: "der" }) as Buffer).toString("hex");

    reg.registerSource({
      sourceId: "authorized-node",
      displayName: "Authorized Validator",
      publicKeyHex: pubKeySpkiHex,
      weight: 50,
      status: "ACTIVE",
      registeredAtMs: Date.now(),
    });

    const now = 100_000;
    const rawQuote: OracleQuote = {
      stage: "ATTESTED",
      baseAssetId: "uep-test/tenergy",
      quoteAssetId: "uep-test/teur",
      priceE6: 120_000n,
      source: "authorized-node",
      sequence: 1n,
      observedAtMs: now,
    };

    const payload = canonicalQuotePayload(rawQuote);
    const validSig = sign(null, payload, privateKey).toString("hex");

    const signedQuote: SignedOracleQuote = {
      ...rawQuote,
      signature: validSig,
      signerPublicKeyHex: pubKeySpkiHex,
      domainSeparator: DOMAIN_SEPARATOR,
    };

    const resOk = await agg.publish(signedQuote, now);
    assert.equal(resOk.ok, true);

    const tamperedQuote: SignedOracleQuote = {
      ...signedQuote,
      priceE6: 999_999n,
      sequence: 2n,
    };
    const resBad = await agg.publish(tamperedQuote, now);
    assert.equal(resBad.ok, false);
    assert.equal(resBad.code, "INVALID_SIGNATURE");
  });

  // Test 4
  it("4. rejects replay attacks via strict monotonic sequence numbers", async () => {
    const reg = new OracleRegistry();
    const agg = new OracleAggregator({ requireSignatures: false }, reg);
    const now = 100_000;

    const q1: OracleQuote = {
      stage: "ATTESTED",
      baseAssetId: "uep-test/tenergy",
      quoteAssetId: "uep-test/teur",
      priceE6: 120_000n,
      source: "source-a",
      sequence: 50n,
      observedAtMs: now,
    };

    const pub1 = await agg.publish(q1, now);
    assert.equal(pub1.ok, true);

    const pubDup = await agg.publish(q1, now + 1000);
    assert.equal(pubDup.ok, false);
    assert.equal(pubDup.code, "REPLAY_ATTACK");

    const pubBack = await agg.publish({ ...q1, sequence: 49n }, now + 2000);
    assert.equal(pubBack.ok, false);
    assert.equal(pubBack.code, "REPLAY_ATTACK");

    const pubNext = await agg.publish({ ...q1, sequence: 51n }, now + 3000);
    assert.equal(pubNext.ok, true);
  });

  // Test 5
  it("5. enforces administrative lifecycle status (ACTIVE, SUSPENDED, REVOKED)", async () => {
    const reg = new OracleRegistry();
    const agg = new OracleAggregator({ requireSignatures: false }, reg);

    reg.registerSource({
      sourceId: "node-5",
      displayName: "Node 5",
      publicKeyHex: "302a300506032b6570032100" + "11".repeat(32),
      weight: 20,
      status: "ACTIVE",
      registeredAtMs: Date.now(),
    });

    const now = 100_000;
    const q: OracleQuote = {
      stage: "ATTESTED",
      baseAssetId: "uep-test/tenergy",
      quoteAssetId: "uep-test/teur",
      priceE6: 120_000n,
      source: "node-5",
      sequence: 1n,
      observedAtMs: now,
    };

    const okRes = await agg.verifier.verifyQuote(q, agg.policy, now);
    assert.equal(okRes.ok, true);

    reg.setSourceStatus("node-5", "SUSPENDED");
    const suspRes = await agg.verifier.verifyQuote({ ...q, sequence: 2n }, agg.policy, now);
    assert.equal(suspRes.ok, false);
    assert.equal(suspRes.code, "SOURCE_SUSPENDED");

    reg.setSourceStatus("node-5", "REVOKED");
    const revRes = await agg.verifier.verifyQuote({ ...q, sequence: 3n }, agg.policy, now);
    assert.equal(revRes.ok, false);
    assert.equal(revRes.code, "UNAUTHORIZED_SOURCE");
  });

  // Test 6
  it("6. supports emergency pause per pair without ledger side effects", () => {
    const reg = new OracleRegistry();
    const agg = new OracleAggregator({ defaultMinSources: 1 }, reg);
    const now = 100_000;

    agg.publishSync({ stage: "ATTESTED", baseAssetId: "uep-test/tenergy", quoteAssetId: "uep-test/teur", priceE6: 120_000n, source: "feed-1", sequence: 1n, observedAtMs: now });

    assert.equal(agg.read("uep-test/tenergy", "uep-test/teur", now).ok, true);

    reg.setPairPaused("uep-test/tenergy", "uep-test/teur", true);
    const pausedRes = agg.read("uep-test/tenergy", "uep-test/teur", now);
    assert.equal(pausedRes.ok, false);
    if (!pausedRes.ok) assert.equal(pausedRes.code, "PAIR_PAUSED");

    reg.setPairPaused("uep-test/tenergy", "uep-test/teur", false);
    assert.equal(agg.read("uep-test/tenergy", "uep-test/teur", now).ok, true);
  });

  // Test 7
  it("7. generates Poseidon BN254 quote evidence hash (independent of SpendCircuit)", () => {
    const quote: OracleQuote = {
      stage: "ATTESTED",
      baseAssetId: "uep-test/tenergy",
      quoteAssetId: "uep-test/teur",
      priceE6: 120_000n,
      source: "zk-node",
      sequence: 1n,
      observedAtMs: 1_700_000_000,
    };

    const hash1 = computeQuotePoseidonHash(quote);
    const hash2 = computeQuotePoseidonHash(quote);
    assert.equal(hash1, hash2);
    assert.ok(hash1 > 0n);
  });

  // Test 8
  it("8. separates Market / Risk Policy: TwapTracker computes rolling TWAP", () => {
    const twap = new TwapTracker();
    let t = 1_000_000;

    twap.recordObservation("uep-test/tenergy", "uep-test/teur", 100_000n, t);
    t += 60_000;
    twap.recordObservation("uep-test/tenergy", "uep-test/teur", 200_000n, t);

    const val = twap.computeTwap("uep-test/tenergy", "uep-test/teur", t, 300_000);
    assert.ok(val !== undefined);
    assert.equal(val, 100_000n);
  });

  // Test 9
  it("9. separates Market / Risk Policy: verifyAmmSpotSkew guards AMM pools", () => {
    const aggQuote: AggregatedQuote = {
      stage: "AGGREGATED",
      baseAssetId: "uep-test/tenergy",
      quoteAssetId: "uep-test/teur",
      priceE6: 120_000n,
      sourcesUsed: 3,
      minPriceE6: 119_000n,
      maxPriceE6: 121_000n,
      observedAtMs: 100_000,
      aggregatedAtMs: 100_000,
      sources: [],
    };

    const okTrade = verifyAmmSpotSkew(100n, 12n, aggQuote, true, 30_000n);
    assert.equal(okTrade.ok, true);

    const badTrade = verifyAmmSpotSkew(100n, 20n, aggQuote, true, 30_000n);
    assert.equal(badTrade.ok, false);
    assert.ok(badTrade.skewPpm! > 30_000n);
  });

  // Test 10: MILESTONE ORACLE-01 — Caso 1: SVC Integration
  it("10. Oracle -> SVC integration: Request -> Contract -> HOLD -> Execution -> Oracle -> Policy -> Settlement", () => {
    const contract: SvcContractHold = {
      contractId: "svc-contract-100",
      payerAddress: "addr-alice",
      providerAddress: "addr-bob-provider",
      holdAmount: 500_000_000n,
      assetId: "uep-test/teur",
      slaMinDeliveryE6: 95_000n,
      isHoldActive: true,
      settled: false,
    };

    const evidence: AggregatedQuote = {
      stage: "AGGREGATED",
      baseAssetId: "uep-test/tcompute",
      quoteAssetId: "uep-test/teur",
      priceE6: 98_000n,
      sourcesUsed: 3,
      minPriceE6: 97_500n,
      maxPriceE6: 98_500n,
      observedAtMs: 100_000,
      aggregatedAtMs: 100_000,
      contextId: "svc-contract-100",
      sources: [],
    };

    const evaluation = evaluateSvcContractSettlement(contract, evidence);
    assert.equal(evaluation.decision, "ACCEPTED");
    assert.equal(evaluation.paymentAuthorized, true);
    assert.equal(evaluation.payableAmount, 500_000_000n);

    const poorEvidence: AggregatedQuote = { ...evidence, priceE6: 80_000n };
    const rejectedEval = evaluateSvcContractSettlement(contract, poorEvidence);
    assert.equal(rejectedEval.decision, "REJECTED_BY_POLICY");
    assert.equal(rejectedEval.paymentAuthorized, false);
  });

  // Test 11: MILESTONE ORACLE-01 — Caso 2: IoT Telemetry Integration
  it("11. Oracle -> IoT integration: Device -> Measurement -> Attestation -> Policy -> Settlement", () => {
    const tariff: IotTariffPolicy = {
      meterAssetId: "uep-test/tenergy",
      settlementAssetId: "uep-test/teur",
      rateE6: 120_000n,
      maxAllowedSpikePpm: 50_000n,
    };

    const evidence: AggregatedQuote = {
      stage: "AGGREGATED",
      baseAssetId: "uep-test/tenergy",
      quoteAssetId: "uep-test/teur",
      priceE6: 120_000n,
      sourcesUsed: 3,
      minPriceE6: 119_500n,
      maxPriceE6: 120_500n,
      observedAtMs: 100_000,
      aggregatedAtMs: 100_000,
      sources: [],
    };

    const evaluation = evaluateIotMeterSettlement(500n, evidence, tariff);
    assert.equal(evaluation.decision, "ACCEPTED");
    assert.equal(evaluation.settlementDue, 60n);
  });

  // Test 12: MILESTONE ORACLE-01 — Caso 3: Dispute Resolution Engine
  it("12. Oracle -> Dispute integration: Contract -> Delivery -> Evidence Verification -> Award", () => {
    const quote: OracleQuote = {
      stage: "ATTESTED",
      baseAssetId: "uep-test/tdata",
      quoteAssetId: "uep-test/teur",
      priceE6: 50_000n,
      source: "dispute-validator",
      sequence: 1n,
      observedAtMs: 100_000,
      contextId: "dispute-claim-42",
    };

    const expectedHash = computeQuotePoseidonHash(quote);

    const dispute: DisputeClaim = {
      disputeId: "dispute-claim-42",
      contractId: "svc-contract-100",
      claimantAddress: "addr-alice",
      respondentAddress: "addr-bob-provider",
      disputedAmount: 250_000_000n,
      expectedPoseidonHash: expectedHash,
    };

    const evidence: AggregatedQuote = {
      stage: "AGGREGATED",
      baseAssetId: "uep-test/tdata",
      quoteAssetId: "uep-test/teur",
      priceE6: 50_000n,
      sourcesUsed: 2,
      minPriceE6: 50_000n,
      maxPriceE6: 50_000n,
      observedAtMs: 100_000,
      aggregatedAtMs: 100_000,
      contextId: "dispute-claim-42",
      sources: [],
    };

    const evalOk = evaluateDisputeResolution(dispute, evidence, expectedHash);
    assert.equal(evalOk.decision, "ACCEPTED");
    assert.equal(evalOk.awardRecipient, "addr-bob-provider");
    assert.equal(evalOk.awardAmount, 250_000_000n);

    const evalBad = evaluateDisputeResolution(dispute, evidence, 0x99999n);
    assert.equal(evalBad.decision, "REJECTED_BY_POLICY");
  });

  // Test 13
  it("13. rejects multiple quotes with identical sequence from the same source", async () => {
    const agg = new OracleAggregator({ requireSignatures: false });
    const now = 100_000;
    const q: OracleQuote = { stage: "ATTESTED", baseAssetId: "uep-test/tenergy", quoteAssetId: "uep-test/teur", priceE6: 120_000n, source: "s1", sequence: 7n, observedAtMs: now };

    const first = await agg.publish(q, now);
    assert.equal(first.ok, true);

    const dup = await agg.publish(q, now + 100);
    assert.equal(dup.ok, false);
    assert.equal(dup.code, "REPLAY_ATTACK");
  });

  // Test 14
  it("14. prevents cross-pair replay: a quote signed for Pair A/B cannot be submitted for Pair C/D", () => {
    const { publicKey, privateKey } = generateKeyPairSync("ed25519");
    const rawA: OracleQuote = {
      stage: "ATTESTED",
      baseAssetId: "uep-test/tenergy",
      quoteAssetId: "uep-test/teur",
      priceE6: 120_000n,
      source: "node-x",
      sequence: 1n,
      observedAtMs: 100_000,
    };

    const payloadA = canonicalQuotePayload(rawA);
    const sigA = sign(null, payloadA, privateKey).toString("hex");

    const replayedOnCD: SignedOracleQuote = {
      ...rawA,
      baseAssetId: "uep-test/tcompute",
      signature: sigA,
      signerPublicKeyHex: (publicKey.export({ type: "spki", format: "der" }) as Buffer).toString("hex"),
    };

    const payloadCD = canonicalQuotePayload(replayedOnCD);
    assert.notDeepEqual(payloadA, payloadCD);
  });

  // Test 15
  it("15. prevents cross-contract replay: attestation bound to contract-A is rejected for contract-B", () => {
    const contractB: SvcContractHold = {
      contractId: "svc-contract-B",
      payerAddress: "addr-alice",
      providerAddress: "addr-bob",
      holdAmount: 100_000n,
      assetId: "uep-test/teur",
      slaMinDeliveryE6: 100_000n,
      isHoldActive: true,
      settled: false,
    };

    const evidenceA: AggregatedQuote = {
      stage: "AGGREGATED",
      baseAssetId: "uep-test/tenergy",
      quoteAssetId: "uep-test/teur",
      priceE6: 120_000n,
      sourcesUsed: 2,
      minPriceE6: 120_000n,
      maxPriceE6: 120_000n,
      observedAtMs: 100_000,
      aggregatedAtMs: 100_000,
      contextId: "svc-contract-A",
      sources: [],
    };

    const evalRes = evaluateSvcContractSettlement(contractB, evidenceA);
    assert.equal(evalRes.decision, "REJECTED_BY_POLICY");
    assert.ok(evalRes.reason?.includes("Context mismatch"));
  });

  // Test 16
  it("16. prevents cross-request replay: attestation for request-1 cannot satisfy request-2", () => {
    const q1: OracleQuote = { stage: "ATTESTED", baseAssetId: "uep-test/tdata", quoteAssetId: "uep-test/teur", priceE6: 50_000n, source: "s1", sequence: 1n, observedAtMs: 100_000, contextId: "req-001" };
    const q2: OracleQuote = { ...q1, contextId: "req-002" };

    const payload1 = canonicalQuotePayload(q1);
    const payload2 = canonicalQuotePayload(q2);
    assert.notDeepEqual(payload1, payload2);
  });

  // Test 17
  it("17. suspended oracle cannot contribute to quorum or consensus", async () => {
    const reg = new OracleRegistry();
    const agg = new OracleAggregator({ defaultMinSources: 2, requireSignatures: false }, reg);

    reg.registerSource({ sourceId: "honest-node", displayName: "Honest", publicKeyHex: "11".repeat(32), weight: 50, status: "ACTIVE", registeredAtMs: 0 });
    reg.registerSource({ sourceId: "rogue-node", displayName: "Rogue", publicKeyHex: "22".repeat(32), weight: 50, status: "SUSPENDED", registeredAtMs: 0 });

    const now = 100_000;
    const pubHonest = await agg.publish({ stage: "ATTESTED", baseAssetId: "uep-test/tenergy", quoteAssetId: "uep-test/teur", priceE6: 120_000n, source: "honest-node", sequence: 1n, observedAtMs: now }, now);
    assert.equal(pubHonest.ok, true);

    const pubSusp = await agg.publish({ stage: "ATTESTED", baseAssetId: "uep-test/tenergy", quoteAssetId: "uep-test/teur", priceE6: 80_000n, source: "rogue-node", sequence: 1n, observedAtMs: now }, now);
    assert.equal(pubSusp.ok, false);
    assert.equal(pubSusp.code, "SOURCE_SUSPENDED");

    const readRes = agg.read("uep-test/tenergy", "uep-test/teur", now);
    assert.equal(readRes.ok, false);
    if (!readRes.ok) assert.equal(readRes.code, "NO_SOURCES");
  });

  // Test 18
  it("18. revoked oracle is completely excluded from the protocol", async () => {
    const reg = new OracleRegistry();
    const agg = new OracleAggregator({ requireSignatures: false }, reg);

    reg.registerSource({ sourceId: "revoked-node", displayName: "Revoked", publicKeyHex: "33".repeat(32), weight: 50, status: "REVOKED", registeredAtMs: 0 });

    const pubRes = await agg.publish({ stage: "ATTESTED", baseAssetId: "uep-test/tenergy", quoteAssetId: "uep-test/teur", priceE6: 120_000n, source: "revoked-node", sequence: 1n, observedAtMs: 100_000 }, 100_000);
    assert.equal(pubRes.ok, false);
    assert.equal(pubRes.code, "UNAUTHORIZED_SOURCE");
  });

  // Test 19
  it("19. pair pause does not alter UEP ledger state or nullifiers", () => {
    const reg = new OracleRegistry();
    const initialLedgerBalance = 1_000_000_000n;
    const activeNullifierCount = 42;

    reg.setPairPaused("uep-test/tenergy", "uep-test/teur", true);
    assert.equal(reg.isPairPaused("uep-test/tenergy", "uep-test/teur"), true);

    const postPauseBalance = initialLedgerBalance;
    const postPauseNullifiers = activeNullifierCount;
    assert.equal(postPauseBalance, initialLedgerBalance);
    assert.equal(postPauseNullifiers, activeNullifierCount);

    reg.setPairPaused("uep-test/tenergy", "uep-test/teur", false);
    assert.equal(reg.isPairPaused("uep-test/tenergy", "uep-test/teur"), false);
  });

  // Test 20: CRITICAL INVARIANT: Aggregation cannot trigger settlement
  it("20. CRITICAL INVARIANT: aggregation cannot trigger settlement without explicit Economic Policy", () => {
    let ledgerSettlementOccurred = false;

    const evidence: AggregatedQuote = {
      stage: "AGGREGATED",
      baseAssetId: "uep-test/tenergy",
      quoteAssetId: "uep-test/teur",
      priceE6: 120_000n,
      sourcesUsed: 3,
      minPriceE6: 119_000n,
      maxPriceE6: 121_000n,
      observedAtMs: 100_000,
      aggregatedAtMs: 100_000,
      sources: [],
    };

    assert.equal(evidence.stage, "AGGREGATED");
    assert.equal(ledgerSettlementOccurred, false);

    const contract: SvcContractHold = {
      contractId: "svc-contract-200",
      payerAddress: "addr-alice",
      providerAddress: "addr-bob",
      holdAmount: 100_000n,
      assetId: "uep-test/teur",
      slaMinDeliveryE6: 200_000n,
      isHoldActive: true,
      settled: false,
    };

    const policyEval = evaluateSvcContractSettlement(contract, evidence);
    assert.equal(policyEval.decision, "REJECTED_BY_POLICY");

    if (policyEval.decision === "ACCEPTED" && policyEval.paymentAuthorized) {
      ledgerSettlementOccurred = true;
    }

    assert.equal(ledgerSettlementOccurred, false);
  });

  // Test 21
  it("21. rejects malformed canonical encoding with invalid field lengths", () => {
    const malformedQuote: OracleQuote = {
      stage: "ATTESTED",
      baseAssetId: "a".repeat(300),
      quoteAssetId: "uep-test/teur",
      priceE6: 120_000n,
      source: "node-1",
      sequence: 1n,
      observedAtMs: 100_000,
    };

    assert.throws(() => {
      canonicalQuotePayload(malformedQuote);
    }, /MALFORMED_ENCODING/);
  });

  // Test 22
  it("22. enforces integer bounds and prevents overflow attacks", () => {
    const overflowQuote: OracleQuote = {
      stage: "ATTESTED",
      baseAssetId: "uep-test/tenergy",
      quoteAssetId: "uep-test/teur",
      priceE6: 0x1_0000_0000_0000_0000n,
      source: "node-1",
      sequence: 1n,
      observedAtMs: 100_000,
    };

    assert.throws(() => {
      canonicalQuotePayload(overflowQuote);
    }, /MALFORMED_ENCODING: priceE6 exceeds uint64 bounds/);
  });

  // Test 23
  it("23. rejects zero or negative prices with PRICE_OUT_OF_BOUNDS", async () => {
    const agg = new OracleAggregator({ requireSignatures: false });
    const zeroQuote: OracleQuote = {
      stage: "ATTESTED",
      baseAssetId: "uep-test/tenergy",
      quoteAssetId: "uep-test/teur",
      priceE6: 0n,
      source: "node-1",
      sequence: 1n,
      observedAtMs: 100_000,
    };

    const res = await agg.verifier.verifyQuote(zeroQuote, agg.policy, 100_000);
    assert.equal(res.ok, false);
    assert.equal(res.code, "PRICE_OUT_OF_BOUNDS");
  });

  // Test 24
  it("24. resolves conflicting oracle policies with deterministic pair-specific precedence", () => {
    const reg = new OracleRegistry();
    const agg = new OracleAggregator({ defaultMaxStalenessMs: 10_000 }, reg);

    reg.setPairPolicy({
      baseAssetId: "uep-test/tenergy",
      quoteAssetId: "uep-test/teur",
      maxStalenessMs: 60_000,
      maxDeviationPpm: 50_000n,
      minSources: 1,
    });

    const now = 100_000;
    agg.publishSync({ stage: "ATTESTED", baseAssetId: "uep-test/tenergy", quoteAssetId: "uep-test/teur", priceE6: 120_000n, source: "s1", sequence: 1n, observedAtMs: now - 25_000 });

    const res = agg.read("uep-test/tenergy", "uep-test/teur", now);
    assert.equal(res.ok, true);
  });

  // Test 25
  it("25. guarantees deterministic aggregation and Poseidon evidence commitment", () => {
    const agg1 = new OracleAggregator({ defaultMinSources: 3 });
    const agg2 = new OracleAggregator({ defaultMinSources: 3 });
    const now = 100_000;

    const feeds: OracleQuote[] = [
      { stage: "ATTESTED", baseAssetId: "uep-test/tenergy", quoteAssetId: "uep-test/teur", priceE6: 120_000n, source: "s1", sequence: 1n, observedAtMs: now },
      { stage: "ATTESTED", baseAssetId: "uep-test/tenergy", quoteAssetId: "uep-test/teur", priceE6: 121_000n, source: "s2", sequence: 1n, observedAtMs: now },
      { stage: "ATTESTED", baseAssetId: "uep-test/tenergy", quoteAssetId: "uep-test/teur", priceE6: 119_500n, source: "s3", sequence: 1n, observedAtMs: now },
    ];

    feeds.forEach(f => agg1.publishSync(f));
    [...feeds].reverse().forEach(f => agg2.publishSync(f));

    const r1 = agg1.read("uep-test/tenergy", "uep-test/teur", now);
    const r2 = agg2.read("uep-test/tenergy", "uep-test/teur", now);

    assert.equal(r1.ok, true);
    assert.equal(r2.ok, true);
    if (r1.ok && r2.ok) {
      assert.equal(r1.quote.priceE6, r2.quote.priceE6);
      assert.equal(r1.quote.minPriceE6, r2.quote.minPriceE6);
      assert.equal(r1.quote.maxPriceE6, r2.quote.maxPriceE6);
    }
  });

  // Test 26: HARDENING — Probar aislamiento contra el ledger real (SMT, notes, nullifiers, balances)
  it("26. HARDENING: rejected economic policy leaves real ledger SMT root and state 100% unchanged", () => {
    const settlementEngine = new MockSettlementEngine();
    const initialSnapshot = settlementEngine.getLedgerSnapshot();

    // Contract with unachievable SLA
    const contract: SvcContractHold = {
      contractId: "svc-strict-001",
      payerAddress: "addr-alice",
      providerAddress: "addr-bob",
      holdAmount: 50_000_000n,
      assetId: "uep-test/teur",
      slaMinDeliveryE6: 200_000n, // requires 200k
      isHoldActive: true,
      settled: false,
    };

    // Valid AGGREGATED evidence delivering only 120k
    const evidence: AggregatedQuote = {
      stage: "AGGREGATED",
      baseAssetId: "uep-test/tenergy",
      quoteAssetId: "uep-test/teur",
      priceE6: 120_000n,
      sourcesUsed: 3,
      minPriceE6: 119_000n,
      maxPriceE6: 121_000n,
      observedAtMs: 100_000,
      aggregatedAtMs: 100_000,
      contextId: "svc-strict-001",
      sources: [],
    };

    const evaluation = evaluateSvcContractSettlement(contract, evidence);
    assert.equal(evaluation.decision, "REJECTED_BY_POLICY");

    // Attempt settlement without authorization
    const unauthorizedSettlement = settlementEngine.settle(null as any);
    assert.equal(unauthorizedSettlement.ok, false);

    // Strict state verification: SMT root, note count, nullifier count, balances remain 100% UNCHANGED
    const postSnapshot = settlementEngine.getLedgerSnapshot();
    assert.equal(postSnapshot.smtRootHex, initialSnapshot.smtRootHex);
    assert.equal(postSnapshot.noteCount, initialSnapshot.noteCount);
    assert.equal(postSnapshot.nullifierCount, initialSnapshot.nullifierCount);
    assert.equal(postSnapshot.totalBalance, initialSnapshot.totalBalance);
  });

  // Test 27: HARDENING — Concurrency defense against duplicate sequences (Promise.all race)
  it("27. HARDENING: concurrent duplicate sequences in race condition accept exactly ONE and reject other", async () => {
    const agg = new OracleAggregator({ requireSignatures: false });
    const now = 100_000;

    const qA: OracleQuote = { stage: "ATTESTED", baseAssetId: "uep-test/tenergy", quoteAssetId: "uep-test/teur", priceE6: 120_000n, source: "node-race", sequence: 42n, observedAtMs: now };
    const qB: OracleQuote = { stage: "ATTESTED", baseAssetId: "uep-test/tenergy", quoteAssetId: "uep-test/teur", priceE6: 121_000n, source: "node-race", sequence: 42n, observedAtMs: now };

    // Fire concurrently
    const [res1, res2] = await Promise.all([
      agg.publish(qA, now),
      agg.publish(qB, now),
    ]);

    const passes = [res1, res2].filter(r => r.ok).length;
    const rejects = [res1, res2].filter(r => !r.ok && r.code === "REPLAY_ATTACK").length;

    assert.equal(passes, 1);
    assert.equal(rejects, 1);
  });

  // Test 28: HARDENING — Concurrency defense against double settlement
  it("28. HARDENING: concurrent double-settlement attempts allow exactly ONE settlement and block replay", () => {
    const settlementEngine = new MockSettlementEngine();
    const initialSnapshot = settlementEngine.getLedgerSnapshot();

    // Create valid authorization
    const contract: SvcContractHold = {
      contractId: "svc-race-002",
      payerAddress: "addr-alice",
      providerAddress: "addr-bob",
      holdAmount: 10_000_000n,
      assetId: "uep-test/teur",
      slaMinDeliveryE6: 90_000n,
      isHoldActive: true,
      settled: false,
    };

    const evidence: AggregatedQuote = {
      stage: "AGGREGATED",
      baseAssetId: "uep-test/tenergy",
      quoteAssetId: "uep-test/teur",
      priceE6: 120_000n,
      sourcesUsed: 2,
      minPriceE6: 120_000n,
      maxPriceE6: 120_000n,
      observedAtMs: 100_000,
      aggregatedAtMs: 100_000,
      contextId: "svc-race-002",
      sources: [],
    };

    const evaluation = evaluateSvcContractSettlement(contract, evidence);
    assert.equal(evaluation.decision, "ACCEPTED");

    const auth = issueSettlementAuthorization(
      evaluation,
      contract.contractId,
      contract.providerAddress,
      contract.assetId
    );

    // Two calls with the exact same authorization
    const settle1 = settlementEngine.settle(auth);
    const settle2 = settlementEngine.settle(auth);

    assert.equal(settle1.ok, true);
    assert.equal(settle2.ok, false);
    assert.ok(settle2.error?.includes("ALREADY_SETTLED"));

    // Ledger notes incremented by exactly 1, NOT 2
    const finalSnapshot = settlementEngine.getLedgerSnapshot();
    assert.equal(finalSnapshot.noteCount, initialSnapshot.noteCount + 1);
    assert.equal(finalSnapshot.nullifierCount, initialSnapshot.nullifierCount + 1);
  });

  // Test 29: HARDENING — Formal context binding validation
  it("29. HARDENING: validates formal context binding syntax (SVC, IoT, Dispute, Market)", () => {
    // Valid formal contexts
    assert.equal(validateFormalContextId("SVC", "svc:contract-100"), true);
    assert.equal(validateFormalContextId("SVC", "contract-100"), true);
    assert.equal(validateFormalContextId("IOT", "iot:grid-west:meter-42"), true);
    assert.equal(validateFormalContextId("DISPUTE", "dispute:disp-101:svc-contract-9001"), true);
    assert.equal(validateFormalContextId("MARKET", "market:uep-test/tenergy:uep-test/teur"), true);

    // Malformed / mismatched contexts rejected
    assert.equal(validateFormalContextId("IOT", "svc:contract-100"), false);
    assert.equal(validateFormalContextId("DISPUTE", "just-a-string"), false);
    assert.equal(validateFormalContextId("SVC", ""), false);
  });

  // Test 30: HARDENING — Complete pipeline: EconomicDecision -> SettlementAuthorization -> SettlementEngine
  it("30. HARDENING: EconomicDecision -> SettlementAuthorization voucher pipeline enforces strict boundary", () => {
    const contract: SvcContractHold = {
      contractId: "svc-pipeline-003",
      payerAddress: "addr-alice",
      providerAddress: "addr-bob",
      holdAmount: 300_000_000n,
      assetId: "uep-test/teur",
      slaMinDeliveryE6: 100_000n,
      isHoldActive: true,
      settled: false,
    };

    const evidence: AggregatedQuote = {
      stage: "AGGREGATED",
      baseAssetId: "uep-test/tcompute",
      quoteAssetId: "uep-test/teur",
      priceE6: 105_000n,
      sourcesUsed: 3,
      minPriceE6: 104_000n,
      maxPriceE6: 106_000n,
      observedAtMs: 100_000,
      aggregatedAtMs: 100_000,
      contextId: "svc-pipeline-003",
      sources: [],
    };

    // Step 1: Economic Policy Evaluation
    const evaluation = evaluateSvcContractSettlement(contract, evidence);
    assert.equal(evaluation.decision, "ACCEPTED");

    // Step 2: Issue SettlementAuthorization Voucher
    const auth = issueSettlementAuthorization(
      evaluation,
      contract.contractId,
      contract.providerAddress,
      contract.assetId
    );
    assert.equal(auth.authorized, true);
    assert.equal(auth.authorizedAmount, 300_000_000n);
    assert.ok(auth.decisionId.startsWith("auth:"));

    // Step 3: Cannot issue authorization from REJECTED decision
    const badEval = { ...evaluation, decision: "REJECTED_BY_POLICY" as const };
    assert.throws(() => {
      issueSettlementAuthorization(badEval, contract.contractId, contract.providerAddress, contract.assetId);
    }, /CANNOT_AUTHORIZE/);

    // Step 4: Settlement Engine consumes voucher
    const engine = new MockSettlementEngine();
    const result = engine.settle(auth);
    assert.equal(result.ok, true);
    assert.ok(result.txId?.startsWith("uep-tx:auth:"));
  });
});
