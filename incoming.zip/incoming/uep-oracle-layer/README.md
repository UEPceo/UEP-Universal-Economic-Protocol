# UEP Oracle Layer v0.1 (Hardened & Audited Release)

Production-hardened Oracle module for the **Universal Economic Protocol (UEP)**.

## Included Files
- `src/oracle/types.ts`: Core data structures, error codes, and fixed-point scales (1e6)
- `src/oracle/canonical.ts`: Canonical byte payload serialization and Poseidon BN254 hashing
- `src/oracle/verifier.ts`: Ed25519 signature verification, anti-replay, and timestamp checks
- `src/oracle/registry.ts`: Authorized source directory, weights, reputation, and emergency pause
- `src/oracle/index.ts`: Aggregator with stake-weighted median, TWAP, and AMM circuit breaker
- `src/oracle/mock.ts`: Testnet feed generator and chaos testing helpers
- `docs/ORACLE-LAYER-v0.1.md`: Full architectural specification and threat model
- `docs/ORACLE-INTEGRATION.md`: Integration guide for Ledger, AMM Pools, and Marketplace Paymaster
- `tests/oracle.test.ts`: Automated test suite (11/11 passing on Node.js 22)

## Running the Tests
```bash
# In your UEP repository:
node --experimental-strip-types --test tests/oracle.test.ts
```

## Security Invariants
1. **Consensus Isolation:** Spends do NOT require live oracle feeds.
2. **Anti-Replay:** Monotonic sequence tracking per (source, pair).
3. **Sybil Defense:** Stake-weighted median aggregation.
4. **ZK-Ready:** Canonical Poseidon BN254 scalar field element hashing.
