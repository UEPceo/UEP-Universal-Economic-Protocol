/**
 * UEP Settlement Engine v0.1 - Canonical Cryptographic Primitives
 * 
 * Provides deterministic RFC-8785 compliant canonical serialization,
 * cryptographic hashing (SHA-256 and Poseidon-compatible digests),
 * Merkle tree root computation for batch settlements, and Ed25519 signature validation.
 */

import { createHash, createPublicKey, verify as cryptoVerify } from "node:crypto";
import type { ActorAuth, SettlementReceipt } from "./types.ts";

/**
 * Deterministically sorts object keys recursively according to RFC 8785 (Canonical JSON)
 */
export function canonicalizeJson(obj: unknown): string {
  if (obj === null || typeof obj !== "object") {
    if (typeof obj === "bigint") {
      return JSON.stringify(obj.toString());
    }
    return JSON.stringify(obj);
  }

  if (Array.isArray(obj)) {
    return "[" + obj.map((item) => canonicalizeJson(item)).join(",") + "]";
  }

  const sortedKeys = Object.keys(obj as Record<string, unknown>).sort();
  const entries: string[] = [];

  for (const key of sortedKeys) {
    const val = (obj as Record<string, unknown>)[key];
    if (val !== undefined && typeof val !== "function") {
      entries.push(`${JSON.stringify(key)}:${canonicalizeJson(val)}`);
    }
  }

  return "{" + entries.join(",") + "}";
}

/**
 * Produces a deterministic SHA-256 hash formatted as lowercase hex
 */
export function sha256Hex(data: string | Buffer | Uint8Array): string {
  return createHash("sha256").update(data).digest("hex");
}

/**
 * Computes canonical hash of a settlement receipt
 */
export function computeReceiptCanonicalHash(receipt: Omit<SettlementReceipt, "canonicalHash" | "signature">): string {
  const canonicalString = canonicalizeJson({
    orderId: receipt.orderId,
    listingId: receipt.listingId,
    asset: receipt.asset,
    grossAmount: receipt.grossAmount.toString(),
    providerPayout: receipt.providerPayout.toString(),
    buyerRefund: receipt.buyerRefund.toString(),
    marketplaceFee: receipt.marketplaceFee.toString(),
    gasFeeCaptured: receipt.gasFeeCaptured.toString(),
    outcome: receipt.outcome,
    categoryGuard: receipt.categoryGuard,
    capacityRestored: receipt.capacityRestored.toString(),
    settledAt: receipt.settledAt,
    engineVersion: receipt.engineVersion,
  });

  return sha256Hex(canonicalString);
}

/**
 * Formats canonical action message string for Ed25519 signing
 */
export function formatActionMessage(action: string, orderId: string, nonce: string, issuedAt: number, payload?: Record<string, unknown>): string {
  return [
    "UEP_SETTLEMENT_ACTION",
    action,
    orderId,
    nonce,
    issuedAt.toString(),
    payload ? canonicalizeJson(payload) : "{}",
  ].join(":");
}

/**
 * Verifies an Ed25519 signature given the actor's public key (hex DER or raw hex)
 */
export function verifyEd25519Signature(
  publicKeyHex: string,
  message: string,
  signatureHex: string
): boolean {
  try {
    const messageBuffer = Buffer.from(message, "utf8");
    const signatureBuffer = Buffer.from(signatureHex, "hex");

    // In case the key is raw 32-byte Ed25519, wrap with DER SPKI prefix if necessary
    let keyBuffer = Buffer.from(publicKeyHex, "hex");
    if (keyBuffer.length === 32) {
      const spkiPrefix = Buffer.from("302a300506032b6570032100", "hex");
      keyBuffer = Buffer.concat([spkiPrefix, keyBuffer]);
    }

    const keyObj = createPublicKey({
      key: keyBuffer,
      format: "der",
      type: "spki",
    });

    return cryptoVerify(null, messageBuffer, keyObj, signatureBuffer);
  } catch {
    return false;
  }
}

/**
 * Computes a Merkle Root from an array of hexadecimal leaf hashes
 */
export function computeMerkleRoot(hashes: string[]): string {
  if (hashes.length === 0) {
    return sha256Hex("EMPTY_BATCH");
  }
  if (hashes.length === 1) {
    return hashes[0]!;
  }

  let currentLevel = [...hashes];

  while (currentLevel.length > 1) {
    const nextLevel: string[] = [];
    for (let i = 0; i < currentLevel.length; i += 2) {
      const left = currentLevel[i]!;
      const right = i + 1 < currentLevel.length ? currentLevel[i + 1]! : left;
      const combined = sha256Hex(Buffer.from(left + right, "hex"));
      nextLevel.push(combined);
    }
    currentLevel = nextLevel;
  }

  return currentLevel[0]!;
}

/**
 * Nonce cache for replay protection with automatic expiration
 */
export class NonceReplayProtector {
  private seenNonces = new Map<string, number>();
  private readonly ttlMs: number;

  constructor(ttlMs = 10 * 60 * 1000) { // 10 minutes default
    this.ttlMs = ttlMs;
  }

  public checkAndRegister(actorId: string, nonce: string, issuedAt: number): boolean {
    const now = Date.now();
    // Check if timestamp is too stale or in the far future
    if (Math.abs(now - issuedAt) > this.ttlMs) {
      return false; // Stale or future
    }

    const key = `${actorId}:${nonce}`;
    if (this.seenNonces.has(key)) {
      return false; // Replay detected
    }

    this.seenNonces.set(key, now);
    this.sweep();
    return true;
  }

  private sweep(): void {
    if (this.seenNonces.size < 500) return;
    const cutoff = Date.now() - this.ttlMs;
    for (const [k, ts] of this.seenNonces.entries()) {
      if (ts < cutoff) {
        this.seenNonces.delete(k);
      }
    }
  }
}
