/**
 * UEP Settlement Engine v0.1 - High-Throughput Batch Settlement Pipeline
 * 
 * Provides parallel and chunked execution of settlement intents,
 * aggregating multiple settlement receipts into a cryptographic BatchSettlementProof
 * with Merkle root anchoring suitable for UEP Ledger blocks and SMT commits.
 */

import type {
  BatchSettlementIntent,
  BatchSettlementProof,
  SettlementReceipt,
} from "./types.ts";
import { computeMerkleRoot, sha256Hex } from "./canonical.ts";
import type { UepSettlementEngine } from "./engine.ts";

export interface BatchExecutionResult {
  successful: SettlementReceipt[];
  failed: Array<{ orderId: string; error: string }>;
  proof: BatchSettlementProof;
}

export class BatchSettlementPipeline {
  private engine: UepSettlementEngine;

  constructor(engine: UepSettlementEngine) {
    this.engine = engine;
  }

  /**
   * Executes a batch of settlement intents sequentially with fail-safe isolation
   */
  public executeBatch(intents: BatchSettlementIntent[]): BatchExecutionResult {
    const startTime = performance.now();
    const successful: SettlementReceipt[] = [];
    const failed: Array<{ orderId: string; error: string }> = [];

    const totalGross: Record<string, bigint> = {};
    const totalFees: Record<string, bigint> = {};
    const assetsSet = new Set<string>();

    for (const intent of intents) {
      try {
        let receipt: SettlementReceipt;
        if (intent.resolution) {
          receipt = this.engine.resolveDispute(intent.orderId, intent.auth, intent.resolution);
        } else {
          receipt = this.engine.settle(intent.orderId, intent.auth);
        }

        successful.push(receipt);
        assetsSet.add(receipt.asset);

        totalGross[receipt.asset] = (totalGross[receipt.asset] ?? 0n) + receipt.grossAmount;
        totalFees[receipt.asset] = (totalFees[receipt.asset] ?? 0n) + receipt.marketplaceFee;
      } catch (err: unknown) {
        const errorMsg = err instanceof Error ? err.message : String(err);
        failed.push({ orderId: intent.orderId, error: errorMsg });
      }
    }

    const receiptHashes = successful.map((r) => r.canonicalHash);
    const rootHash = computeMerkleRoot(receiptHashes);
    const endTime = performance.now();

    const proof: BatchSettlementProof = {
      batchId: `batch-${Date.now()}-${sha256Hex(rootHash).slice(0, 8)}`,
      rootHash,
      receiptsCount: successful.length,
      assetsProcessed: Array.from(assetsSet),
      totalGrossProcessed: totalGross,
      totalFeesCollected: totalFees,
      timestamp: Date.now(),
      executionTimeMs: Math.round((endTime - startTime) * 100) / 100,
    };

    return {
      successful,
      failed,
      proof,
    };
  }
}
