/**
 * UEP Settlement Engine v0.1 - Core Settlement Engine
 * 
 * Production-ready settlement engine for the Universal Economic Protocol (UEP).
 * Enforces atomic state transitions, mathematical value conservation,
 * Ed25519 signature authentication, category guard validation, and idempotent receipts.
 */

import {
  type ActorAuth,
  type CategoryGuardHooks,
  type CategoryGuardStatus,
  type DisputeOutcome,
  type DisputeResolution,
  type ISettlementLedger,
  type OrderSettlementStatus,
  type ServiceCategory,
  type SettlementEngineConfig,
  type SettlementOrder,
  type SettlementReceipt,
  type ValueConservationAudit,
  CANONICAL_BPS_DENOMINATOR,
  DEFAULT_MARKETPLACE_FEE_BPS,
  SETTLEMENT_ENGINE_VERSION,
} from "./types.ts";
import {
  computeReceiptCanonicalHash,
  formatActionMessage,
  NonceReplayProtector,
  verifyEd25519Signature,
} from "./canonical.ts";
import { ReferenceSettlementLedger } from "./reference-ledger.ts";

export class UepSettlementEngine {
  private ledger: ISettlementLedger;
  private config: Required<SettlementEngineConfig>;
  private orders = new Map<string, SettlementOrder>();
  private settlements = new Map<string, SettlementReceipt>();
  private categoryGuards = new Map<ServiceCategory, CategoryGuardHooks>();
  private replayProtector = new NonceReplayProtector();
  private orderLocks = new Set<string>(); // In-flight order execution lock

  constructor(
    ledger?: ISettlementLedger,
    config: SettlementEngineConfig = {}
  ) {
    this.ledger = ledger ?? new ReferenceSettlementLedger();
    this.config = {
      marketplaceFeeBps: config.marketplaceFeeBps ?? DEFAULT_MARKETPLACE_FEE_BPS,
      deliveryDisputeWindowMs: config.deliveryDisputeWindowMs ?? 24 * 60 * 60 * 1000,
      disputeResolutionWindowMs: config.disputeResolutionWindowMs ?? 7 * 24 * 60 * 60 * 1000,
      cancellationGraceMs: config.cancellationGraceMs ?? 2 * 60 * 1000,
      adminPublicKeyHex: config.adminPublicKeyHex ?? "",
      arbiterPublicKeyHex: config.arbiterPublicKeyHex ?? "",
      requireSignedTelemetryForIoT: config.requireSignedTelemetryForIoT ?? true,
      strictConservationCheck: config.strictConservationCheck ?? true,
    };
  }

  public getLedger(): ISettlementLedger {
    return this.ledger;
  }

  public getSettlement(orderId: string): SettlementReceipt | undefined {
    return this.settlements.get(orderId);
  }

  public getOrder(orderId: string): SettlementOrder {
    const order = this.orders.get(orderId);
    if (!order) throw new Error("ORDER_NOT_FOUND");
    return { ...order };
  }

  public attachCategoryGuard(category: ServiceCategory, hooks: CategoryGuardHooks): void {
    this.categoryGuards.set(category, hooks);
  }

  /**
   * Registers a new order into the settlement engine pipeline
   */
  public registerOrder(orderInput: Omit<SettlementOrder, "heldAmount" | "status" | "createdAt" | "updatedAt">): SettlementOrder {
    if (this.orders.has(orderInput.orderId)) {
      throw new Error("ORDER_ALREADY_EXISTS");
    }

    const now = Date.now();
    const order: SettlementOrder = {
      ...orderInput,
      heldAmount: 0n,
      status: "PENDING_HOLD",
      createdAt: now,
      updatedAt: now,
    };

    this.orders.set(order.orderId, order);
    return { ...order };
  }

  /**
   * Puts buyer funds into escrow (HOLD state)
   */
  public holdFunds(orderId: string, amount: bigint): SettlementOrder {
    return this.withOrderLock(orderId, () => {
      const order = this.getOrder(orderId);
      if (order.status !== "PENDING_HOLD") {
        throw new Error("ORDER_NOT_IN_PENDING_HOLD");
      }

      const required = order.grossAmount + order.gasFee;
      if (amount !== required) {
        throw new Error(`HOLD_NOT_COMPLETE: requested ${amount} but order requires ${required}`);
      }

      this.ledger.hold(order.buyerId, order.asset, amount);
      order.heldAmount = amount;
      order.status = "HELD";
      order.updatedAt = Date.now();
      this.orders.set(orderId, order);
      return { ...order };
    });
  }

  /**
   * Marks order delivered by provider (starts the dispute window)
   */
  public markDelivered(orderId: string, deliveryReportHash?: string): SettlementOrder {
    return this.withOrderLock(orderId, () => {
      const order = this.getOrder(orderId);
      if (order.status !== "HELD") {
        throw new Error("ORDER_NOT_IN_HELD_STATE");
      }

      const now = Date.now();
      order.status = "DELIVERED";
      order.deliveredAt = now;
      order.deliveryReportHash = deliveryReportHash;
      order.updatedAt = now;
      this.orders.set(orderId, order);
      return { ...order };
    });
  }

  /**
   * Buyer opens a dispute during the dispute window
   */
  public openDispute(orderId: string, auth: ActorAuth, reason: string): SettlementOrder {
    return this.withOrderLock(orderId, () => {
      const order = this.getOrder(orderId);
      this.authenticateActor(auth, "dispute", orderId, { reason });

      if (auth.actorId !== order.buyerId) {
        throw new Error("DISPUTE_NOT_AUTHORIZED: only buyer can initiate dispute");
      }

      if (order.status === "DISPUTED") return { ...order };
      if (order.status !== "DELIVERED") throw new Error("ORDER_NOT_DELIVERED");

      const now = Date.now();
      const deliveredTime = order.deliveredAt ?? order.updatedAt;
      if (now > deliveredTime + this.config.deliveryDisputeWindowMs) {
        throw new Error("DISPUTE_WINDOW_CLOSED");
      }

      order.status = "DISPUTED";
      order.disputedAt = now;
      order.disputeDeadline = now + this.config.disputeResolutionWindowMs;
      order.updatedAt = now;
      this.orders.set(orderId, order);
      return { ...order };
    });
  }

  /**
   * Settles a delivered order:
   * - Buyer can settle at any time after delivery.
   * - Provider can claim settlement after the dispute window has elapsed without dispute.
   * - Arbiter can release payment directly.
   */
  public settle(orderId: string, auth: ActorAuth): SettlementReceipt {
    return this.withOrderLock(orderId, () => {
      const order = this.getOrder(orderId);
      this.authenticateActor(auth, "settle", orderId);

      // Check if already finalized (Idempotency check)
      if (this.settlements.has(orderId)) {
        return this.settlements.get(orderId)!;
      }

      const isBuyer = auth.actorId === order.buyerId;
      const isProvider = auth.actorId === order.providerId;
      const isArbiter = this.isArbiter(auth);

      if (!isBuyer && !isProvider && !isArbiter) {
        throw new Error("SETTLEMENT_NOT_AUTHORIZED");
      }

      if (order.status === "DISPUTED") {
        const now = Date.now();
        if (now >= (order.disputeDeadline ?? Number.POSITIVE_INFINITY)) {
          return this.timeoutDispute(orderId);
        }
        if (!isBuyer) {
          throw new Error("DISPUTE_PENDING");
        }
        // Buyer withdraws dispute and releases payment
        return this.executePayout(order, order.grossAmount, "RELEASE");
      }

      if (order.status !== "DELIVERED") {
        throw new Error("ORDER_NOT_SETTLEABLE");
      }

      const now = Date.now();
      if (isProvider && !isBuyer && !isArbiter) {
        const deliveredTime = order.deliveredAt ?? order.updatedAt;
        if (now < deliveredTime + this.config.deliveryDisputeWindowMs) {
          throw new Error("SETTLEMENT_DISPUTE_WINDOW_ACTIVE");
        }
      }

      return this.executePayout(order, order.grossAmount, "RELEASE");
    });
  }

  /**
   * Arbiter resolves an open dispute with RELEASE, REFUND_BUYER, or SPLIT
   */
  public resolveDispute(orderId: string, auth: ActorAuth, resolution: DisputeResolution): SettlementReceipt {
    return this.withOrderLock(orderId, () => {
      const order = this.getOrder(orderId);
      this.authenticateActor(auth, "resolve", orderId, { outcome: resolution.outcome, providerAmount: resolution.providerAmount?.toString() });

      if (!this.isArbiter(auth)) {
        throw new Error("DISPUTE_RESOLUTION_NOT_AUTHORIZED: caller is not configured arbiter");
      }

      if (this.settlements.has(orderId)) {
        return this.settlements.get(orderId)!;
      }

      if (order.status !== "DISPUTED") {
        throw new Error("DISPUTE_NOT_OPEN");
      }

      if (resolution.outcome === "RELEASE") {
        return this.executePayout(order, order.grossAmount, "RELEASE", "ARBITER_OVERRIDE");
      }

      if (resolution.outcome === "REFUND_BUYER") {
        return this.executePayout(order, 0n, "REFUND_BUYER");
      }

      if (resolution.outcome === "SPLIT") {
        const splitAmount = resolution.providerAmount;
        if (splitAmount === undefined || splitAmount < 0n || splitAmount > order.grossAmount) {
          throw new Error("DISPUTE_SPLIT_INVALID");
        }
        return this.executePayout(order, splitAmount, "SPLIT");
      }

      throw new Error("DISPUTE_OUTCOME_INVALID");
    });
  }

  /**
   * Provider voluntarily refunds the buyer in full
   */
  public refundBuyer(orderId: string, auth: ActorAuth): SettlementReceipt {
    return this.withOrderLock(orderId, () => {
      const order = this.getOrder(orderId);
      this.authenticateActor(auth, "refund", orderId);

      if (auth.actorId !== order.providerId) {
        throw new Error("REFUND_NOT_AUTHORIZED: only provider can initiate voluntary refund");
      }

      if (this.settlements.has(orderId)) {
        return this.settlements.get(orderId)!;
      }

      if (order.status !== "DELIVERED" && order.status !== "DISPUTED") {
        throw new Error("ORDER_NOT_REFUNDABLE");
      }

      return this.executePayout(order, 0n, "REFUND_BUYER");
    });
  }

  /**
   * Handles dispute timeout: releases if guard passes, otherwise refunds buyer
   */
  public timeoutDispute(orderId: string): SettlementReceipt {
    return this.withOrderLock(orderId, () => {
      const order = this.getOrder(orderId);
      if (this.settlements.has(orderId)) return this.settlements.get(orderId)!;
      if (order.status !== "DISPUTED") throw new Error("DISPUTE_NOT_OPEN");

      const guard = this.runCategoryGuard(order);
      if (guard.status === "PASSED" || guard.status === "NOT_APPLICABLE") {
        return this.executePayout(order, order.grossAmount, "RELEASE", guard.status);
      } else {
        return this.executePayout(order, 0n, "REFUND_BUYER", "TIMEOUT_REFUNDED");
      }
    });
  }

  /**
   * Verifies mathematical value conservation for an order execution
   */
  public auditValueConservation(
    heldAmount: bigint,
    providerPayout: bigint,
    buyerRefund: bigint,
    marketplaceFee: bigint,
    gasCaptured: bigint
  ): ValueConservationAudit {
    const distributed = providerPayout + buyerRefund + marketplaceFee + gasCaptured;
    const delta = distributed - heldAmount;
    return {
      conserved: delta === 0n,
      heldAmount,
      distributedTotal: distributed,
      providerPayout,
      buyerRefund,
      marketplaceFee,
      gasCaptured,
      delta,
    };
  }

  /**
   * Atomic payout execution engine:
   * Moves funds strictly once, verifies mathematical conservation, updates order status,
   * and creates the immutable SettlementReceipt.
   */
  private executePayout(
    order: SettlementOrder,
    providerGrossTarget: bigint,
    outcome: DisputeOutcome,
    overrideGuardStatus?: CategoryGuardStatus
  ): SettlementReceipt {
    const totalRequired = order.grossAmount + order.gasFee;
    if (order.heldAmount !== totalRequired) {
      throw new Error("HOLD_NOT_COMPLETE");
    }

    if (this.ledger.getHeldBalance(order.buyerId, order.asset) < order.heldAmount) {
      throw new Error("HELD_BALANCE_INSUFFICIENT");
    }

    // Category guard check for normal release
    let guardStatus: CategoryGuardStatus = overrideGuardStatus ?? "NOT_APPLICABLE";
    if (!overrideGuardStatus) {
      const guardResult = this.runCategoryGuard(order);
      guardStatus = guardResult.status;
      if (outcome === "RELEASE" && guardResult.status === "FAILED") {
        throw new Error("IOT_GUARD_VERIFICATION_FAILED: telemetry not verified or incomplete");
      }
    }

    // Calculate capacity restoration
    const capacityRestored = this.calculateCapacityRestored(order, providerGrossTarget);

    let fee = 0n;
    let providerNet = 0n;
    let gasCaptured = 0n;

    if (providerGrossTarget > 0n) {
      // Fee calculation: 3% (300 bps), minimum 1 unit (UEP-A16)
      const rawFee = (providerGrossTarget * this.config.marketplaceFeeBps) / CANONICAL_BPS_DENOMINATOR;
      fee = rawFee > 0n ? rawFee : 1n; // 1 unit floor
      if (fee > providerGrossTarget) fee = providerGrossTarget;

      providerNet = providerGrossTarget - fee;
      gasCaptured = order.gasFee;
    }

    const buyerRefund = order.heldAmount - providerNet - fee - gasCaptured;

    // Mathematical conservation check (Zero leakage invariant)
    const audit = this.auditValueConservation(
      order.heldAmount,
      providerNet,
      buyerRefund,
      fee,
      gasCaptured
    );

    if (!audit.conserved && this.config.strictConservationCheck) {
      throw new Error(`PAYOUT_NOT_CONSERVED: delta=${audit.delta}`);
    }

    // Atomic Ledger Transfer
    // 1. Release net provider payment from held balance
    if (providerNet > 0n) {
      this.ledger.releaseHeld(order.buyerId, order.providerId, order.asset, providerNet);
    }
    // 2. Consume fee and gas from held balance and credit treasury / paymaster
    if (fee > 0n) {
      if ("consumeHeld" in this.ledger && typeof (this.ledger as any).consumeHeld === "function") {
        (this.ledger as any).consumeHeld(order.buyerId, order.asset, fee);
      } else {
        this.ledger.releaseHeld(order.buyerId, "treasury", order.asset, fee);
      }
      this.ledger.recordFee(order.asset, fee);
    }
    if (gasCaptured > 0n) {
      if ("consumeHeld" in this.ledger && typeof (this.ledger as any).consumeHeld === "function") {
        (this.ledger as any).consumeHeld(order.buyerId, order.asset, gasCaptured);
      } else {
        this.ledger.releaseHeld(order.buyerId, "paymaster", order.asset, gasCaptured);
      }
      this.ledger.recordGas(order.asset, gasCaptured);
    }
    // 3. Refund remainder to buyer from held balance
    if (buyerRefund > 0n) {
      this.ledger.releaseHeld(order.buyerId, order.buyerId, order.asset, buyerRefund);
    }

    // Update Order State
    const now = Date.now();
    order.heldAmount = 0n;
    order.status = providerGrossTarget > 0n ? (outcome === "SPLIT" ? "SPLIT_SETTLED" : "SETTLED") : "REFUNDED";
    order.disputeOutcome = outcome;
    order.capacityRestored = capacityRestored;
    order.capacityConsumed = order.quantity - capacityRestored;
    order.updatedAt = now;
    this.orders.set(order.orderId, order);

    // Generate Canonical Receipt
    const receiptPreimage = {
      receiptId: `rcpt-${order.orderId}-${now}`,
      orderId: order.orderId,
      listingId: order.listingId,
      asset: order.asset,
      grossAmount: order.grossAmount,
      providerPayout: providerNet,
      buyerRefund,
      marketplaceFee: fee,
      gasFeeCaptured: gasCaptured,
      outcome,
      categoryGuard: guardStatus,
      capacityRestored,
      settledAt: now,
      engineVersion: SETTLEMENT_ENGINE_VERSION,
    };

    const canonicalHash = computeReceiptCanonicalHash(receiptPreimage);
    const receipt: SettlementReceipt = {
      ...receiptPreimage,
      canonicalHash,
    };

    this.settlements.set(order.orderId, receipt);
    return receipt;
  }

  private calculateCapacityRestored(order: SettlementOrder, providerAmount: bigint): bigint {
    if (providerAmount >= order.grossAmount) return 0n;
    const hooks = this.categoryGuards.get(order.category);
    let evidenceUnits = 0n;
    if (hooks?.consumedUnits) {
      try {
        const units = hooks.consumedUnits({ ...order });
        evidenceUnits = units < 0n ? 0n : units > order.quantity ? order.quantity : units;
      } catch {
        evidenceUnits = 0n;
      }
    }

    const paidUnits = providerAmount <= 0n ? 0n : (providerAmount * order.quantity + order.grossAmount - 1n) / order.grossAmount;
    const consumed = evidenceUnits > paidUnits ? evidenceUnits : paidUnits;
    const restore = order.quantity - consumed;
    return restore > order.quantity ? order.quantity : restore < 0n ? 0n : restore;
  }

  private runCategoryGuard(order: SettlementOrder): { status: CategoryGuardStatus } {
    if (order.category === "IOT_M2M") {
      const hook = this.categoryGuards.get("IOT_M2M");
      if (!hook?.settlementGuard) {
        if (this.config.requireSignedTelemetryForIoT) {
          throw new Error("IOT_SETTLEMENT_GUARD_REQUIRED: IoT/M2M orders require verified telemetry guard");
        }
        return { status: "NOT_APPLICABLE" };
      }
      try {
        hook.settlementGuard({ ...order });
        return { status: "PASSED" };
      } catch {
        return { status: "FAILED" };
      }
    }

    const hook = this.categoryGuards.get(order.category);
    if (!hook?.settlementGuard) return { status: "NOT_APPLICABLE" };

    try {
      hook.settlementGuard({ ...order });
      return { status: "PASSED" };
    } catch {
      return { status: "FAILED" };
    }
  }

  private authenticateActor(
    auth: ActorAuth,
    action: string,
    orderId: string,
    payload?: Record<string, unknown>
  ): void {
    if (!auth || !auth.actorId || !auth.publicKeyHex || !auth.signature) {
      throw new Error("SETTLEMENT_NOT_AUTHORIZED: missing actor credentials");
    }

    const now = Date.now();
    if (auth.expiresAt < now) {
      throw new Error("SIGNATURE_EXPIRED: authorization token has expired");
    }

    const message = formatActionMessage(action, orderId, auth.nonce, auth.issuedAt, payload);
    const valid = verifyEd25519Signature(auth.publicKeyHex, message, auth.signature);
    if (!valid) {
      throw new Error("SIGNATURE_INVALID: Ed25519 signature verification failed");
    }

    const registered = this.replayProtector.checkAndRegister(auth.actorId, auth.nonce, auth.issuedAt);
    if (!registered) {
      throw new Error("REPLAY_SIGNATURE_DETECTED: nonce has already been used or timestamp is out of bounds");
    }
  }

  private isArbiter(auth: ActorAuth): boolean {
    if (!this.config.arbiterPublicKeyHex) return false;
    return auth.publicKeyHex.toLowerCase() === this.config.arbiterPublicKeyHex.toLowerCase();
  }

  private withOrderLock<T>(orderId: string, fn: () => T): T {
    if (this.orderLocks.has(orderId)) {
      throw new Error(`CONCURRENT_ORDER_MODIFICATION: order ${orderId} is currently undergoing state transition`);
    }
    this.orderLocks.add(orderId);
    try {
      return fn();
    } finally {
      this.orderLocks.delete(orderId);
    }
  }
}
