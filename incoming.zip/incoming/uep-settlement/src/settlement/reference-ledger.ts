/**
 * UEP Settlement Engine v0.1 - Reference Ledger & Adapter
 * 
 * Provides an atomic, high-performance, double-entry multi-asset ledger
 * designed for escrow, holds, fee collection, and value conservation validation.
 */

import type { ISettlementLedger, TreasurySplit } from "./types.ts";

export class ReferenceSettlementLedger implements ISettlementLedger {
  // Accounts mapping: asset -> address -> available balance
  private accounts = new Map<string, Map<string, bigint>>();

  // Held mapping: asset -> address -> held balance in escrow
  private held = new Map<string, Map<string, bigint>>();

  // Collected fees per asset
  private feesCollected = new Map<string, bigint>();

  // Collected gas fees per asset
  private gasCollected = new Map<string, bigint>();

  // Treasury split buckets per asset
  private treasurySplits = new Map<string, TreasurySplit>();

  // Initial minted/deposited supply per asset to enforce global conservation
  private totalInjectedSupply = new Map<string, bigint>();

  public getBalance(address: string, asset: string): bigint {
    return this.accounts.get(asset)?.get(address) ?? 0n;
  }

  public getHeldBalance(address: string, asset: string): bigint {
    return this.held.get(asset)?.get(address) ?? 0n;
  }

  public getFeesCollected(asset: string): bigint {
    return this.feesCollected.get(asset) ?? 0n;
  }

  public getGasCollected(asset: string): bigint {
    return this.gasCollected.get(asset) ?? 0n;
  }

  public getTreasurySplit(asset: string): TreasurySplit {
    return this.treasurySplits.get(asset) ?? {
      totalFee: 0n,
      infrastructure: 0n,
      development: 0n,
      liquidityReserve: 0n,
      ecosystem: 0n,
    };
  }

  /**
   * Deposit or mint initial balance for an address (used during funding/testing)
   */
  public deposit(address: string, asset: string, amount: bigint): void {
    if (amount <= 0n) throw new Error("DEPOSIT_AMOUNT_MUST_BE_POSITIVE");
    this.credit(address, asset, amount);
    const currentSupply = this.totalInjectedSupply.get(asset) ?? 0n;
    this.totalInjectedSupply.set(asset, currentSupply + amount);
  }

  public credit(address: string, asset: string, amount: bigint): void {
    if (amount < 0n) throw new Error("CREDIT_AMOUNT_CANNOT_BE_NEGATIVE");
    if (amount === 0n) return;

    let assetMap = this.accounts.get(asset);
    if (!assetMap) {
      assetMap = new Map<string, bigint>();
      this.accounts.set(asset, assetMap);
    }
    const current = assetMap.get(address) ?? 0n;
    assetMap.set(address, current + amount);
  }

  public debit(address: string, asset: string, amount: bigint): void {
    if (amount < 0n) throw new Error("DEBIT_AMOUNT_CANNOT_BE_NEGATIVE");
    if (amount === 0n) return;

    const current = this.getBalance(address, asset);
    if (current < amount) {
      throw new Error(`INSUFFICIENT_FUNDS: address ${address} has ${current} but requires ${amount}`);
    }

    this.accounts.get(asset)!.set(address, current - amount);
  }

  /**
   * Moves amount from available balance to held escrow
   */
  public hold(address: string, asset: string, amount: bigint): void {
    if (amount <= 0n) throw new Error("HOLD_AMOUNT_MUST_BE_POSITIVE");
    this.debit(address, asset, amount);

    let assetHeld = this.held.get(asset);
    if (!assetHeld) {
      assetHeld = new Map<string, bigint>();
      this.held.set(asset, assetHeld);
    }
    const currentHeld = assetHeld.get(address) ?? 0n;
    assetHeld.set(address, currentHeld + amount);
  }

  /**
   * Releases held funds directly to a destination address
   */
  public releaseHeld(fromAddress: string, toAddress: string, asset: string, amount: bigint): void {
    if (amount < 0n) throw new Error("RELEASE_AMOUNT_CANNOT_BE_NEGATIVE");
    if (amount === 0n) return;

    const currentHeld = this.getHeldBalance(fromAddress, asset);
    if (currentHeld < amount) {
      throw new Error(`INSUFFICIENT_HELD_BALANCE: ${fromAddress} has held ${currentHeld} but releasing ${amount}`);
    }

    this.held.get(asset)!.set(fromAddress, currentHeld - amount);
    this.credit(toAddress, asset, amount);
  }

  /**
   * Internal reduction of held funds without crediting (e.g. fee extraction from escrow)
   */
  public consumeHeld(fromAddress: string, asset: string, amount: bigint): void {
    if (amount < 0n) throw new Error("CONSUME_AMOUNT_CANNOT_BE_NEGATIVE");
    if (amount === 0n) return;

    const currentHeld = this.getHeldBalance(fromAddress, asset);
    if (currentHeld < amount) {
      throw new Error(`INSUFFICIENT_HELD_BALANCE: ${fromAddress} has held ${currentHeld} but consuming ${amount}`);
    }

    this.held.get(asset)!.set(fromAddress, currentHeld - amount);
  }

  public recordFee(asset: string, amount: bigint): void {
    if (amount <= 0n) return;
    const current = this.getFeesCollected(asset);
    this.feesCollected.set(asset, current + amount);

    // Compute treasury split: 40% infra, 25% dev, 20% reserve, 15% ecosystem
    const infra = (amount * 40n) / 100n;
    const dev = (amount * 25n) / 100n;
    const reserve = (amount * 20n) / 100n;
    const eco = amount - (infra + dev + reserve); // preserve exact remainder

    const split = this.getTreasurySplit(asset);
    this.treasurySplits.set(asset, {
      totalFee: split.totalFee + amount,
      infrastructure: split.infrastructure + infra,
      development: split.development + dev,
      liquidityReserve: split.liquidityReserve + reserve,
      ecosystem: split.ecosystem + eco,
    });
  }

  public recordGas(asset: string, amount: bigint): void {
    if (amount <= 0n) return;
    const current = this.getGasCollected(asset);
    this.gasCollected.set(asset, current + amount);
  }

  /**
   * Mathematically proves total value conservation for a given asset:
   * Total Injected == Sum(Available) + Sum(Held) + FeesCollected + GasCollected
   */
  public verifyGlobalConservation(asset: string): { conserved: boolean; totalInjected: bigint; totalTracked: bigint; delta: bigint } {
    const injected = this.totalInjectedSupply.get(asset) ?? 0n;

    let availableSum = 0n;
    const assetAccounts = this.accounts.get(asset);
    if (assetAccounts) {
      for (const bal of assetAccounts.values()) availableSum += bal;
    }

    let heldSum = 0n;
    const assetHeld = this.held.get(asset);
    if (assetHeld) {
      for (const bal of assetHeld.values()) heldSum += bal;
    }

    const fees = this.getFeesCollected(asset);
    const gas = this.getGasCollected(asset);

    const tracked = availableSum + heldSum + fees + gas;
    return {
      conserved: injected === tracked,
      totalInjected: injected,
      totalTracked: tracked,
      delta: tracked - injected,
    };
  }
}
