/**
 * UEP Settlement Engine v0.1 - Canonical Types
 * 
 * Formal type definitions for cryptographically verified, multi-asset,
 * deterministic settlement inside the Universal Economic Protocol.
 * 
 * Compliant with UEP v0.5.0, UEP-A16 (fee floors), UEP-B09 (actor authorization),
 * UEP-D04 (category guards) and UEP-D05 (capacity restoration).
 */

export const SETTLEMENT_ENGINE_VERSION = "0.1.0" as const;
export const CANONICAL_BPS_DENOMINATOR = 10_000n;
export const DEFAULT_MARKETPLACE_FEE_BPS = 300n; // 3.00%
export const PROTOCOL_FEE_BPS = 10n; // 0.10%

export type ServiceCategory = "COMPUTE" | "STORAGE" | "API" | "DATA" | "IOT_M2M" | "CUSTOM";

export type OrderSettlementStatus = 
  | "PENDING_HOLD"
  | "HELD"
  | "DELIVERED"
  | "DISPUTED"
  | "SETTLED"
  | "REFUNDED"
  | "SPLIT_SETTLED"
  | "CANCELLED"
  | "EXPIRED";

export type DisputeOutcome = "RELEASE" | "REFUND_BUYER" | "SPLIT";

export type CategoryGuardStatus = "PASSED" | "FAILED" | "ARBITER_OVERRIDE" | "TIMEOUT_REFUNDED" | "NOT_APPLICABLE";

/**
 * Mathematical conservation check result for any settlement operation
 */
export interface ValueConservationAudit {
  conserved: boolean;
  heldAmount: bigint;
  distributedTotal: bigint;
  providerPayout: bigint;
  buyerRefund: bigint;
  marketplaceFee: bigint;
  gasCaptured: bigint;
  delta: bigint;
}

/**
 * Canonical representation of an order undergoing settlement
 */
export interface SettlementOrder {
  orderId: string;
  listingId: string;
  buyerId: string;
  providerId: string;
  asset: string; // e.g. "uep-test/teur", "uep-global/eur"
  quantity: bigint;
  unitPrice: bigint;
  grossAmount: bigint;
  heldAmount: bigint;
  depositAmount: bigint;
  gasFee: bigint;
  gasQuoteId?: string;
  status: OrderSettlementStatus;
  category: ServiceCategory;
  createdAt: number;
  updatedAt: number;
  deliveredAt?: number;
  disputedAt?: number;
  disputeDeadline?: number;
  disputeReasonHash?: string;
  disputeOutcome?: DisputeOutcome;
  deliveryReportHash?: string;
  capacityConsumed?: bigint;
  capacityRestored?: bigint;
}

/**
 * Signed Actor Authorization compliant with UEP-B09
 */
export interface ActorAuth {
  actorId: string;
  publicKeyHex: string;
  signature: string; // Ed25519 signature over canonical payload
  nonce: string;
  issuedAt: number;
  expiresAt: number;
}

/**
 * Dispute Resolution intent signed by designated Arbiter
 */
export interface DisputeResolution {
  outcome: DisputeOutcome;
  providerAmount?: bigint; // Required for SPLIT outcome
  reason?: string;
}

/**
 * Immutable, cryptographically verifiable receipt generated upon order settlement
 */
export interface SettlementReceipt {
  receiptId: string;
  orderId: string;
  listingId: string;
  asset: string;
  grossAmount: bigint;
  providerPayout: bigint;
  buyerRefund: bigint;
  marketplaceFee: bigint;
  gasFeeCaptured: bigint;
  outcome: DisputeOutcome;
  categoryGuard: CategoryGuardStatus;
  capacityRestored: bigint;
  settledAt: number;
  engineVersion: string;
  canonicalHash: string; // SHA-256 / Poseidon state digest
  signature?: string; // Optional engine or arbiter signature
}

/**
 * Batch Settlement Request for high-throughput scaling
 */
export interface BatchSettlementIntent {
  orderId: string;
  auth: ActorAuth;
  resolution?: DisputeResolution;
}

/**
 * Cryptographic batch settlement proof aggregating multiple receipts
 */
export interface BatchSettlementProof {
  batchId: string;
  rootHash: string; // Merkle root of all receipt hashes in the batch
  receiptsCount: number;
  assetsProcessed: string[];
  totalGrossProcessed: Record<string, bigint>;
  totalFeesCollected: Record<string, bigint>;
  timestamp: number;
  executionTimeMs: number;
}

/**
 * Category Settlement Guard hook (e.g. IoT verified telemetry or SLA verification)
 */
export interface CategoryGuardHooks {
  /**
   * Throws if validation fails. Returning void indicates successful verification.
   */
  settlementGuard?: (order: SettlementOrder) => void;
  
  /**
   * Returns units proven to have been executed (e.g., telemetry units)
   */
  consumedUnits?: (order: SettlementOrder) => bigint;
}

/**
 * Split of the 3% marketplace fee across treasury buckets (40/25/20/15)
 */
export interface TreasurySplit {
  totalFee: bigint;
  infrastructure: bigint; // 40%
  development: bigint;    // 25%
  liquidityReserve: bigint; // 20%
  ecosystem: bigint;       // 15%
}

/**
 * Bidirectional ledger adapter interface for real or mock economic state
 */
export interface ISettlementLedger {
  getBalance(address: string, asset: string): bigint;
  getHeldBalance(address: string, asset: string): bigint;
  hold(address: string, asset: string, amount: bigint): void;
  releaseHeld(fromAddress: string, toAddress: string, asset: string, amount: bigint): void;
  credit(address: string, asset: string, amount: bigint): void;
  debit(address: string, asset: string, amount: bigint): void;
  recordFee(asset: string, amount: bigint): void;
  recordGas(asset: string, amount: bigint): void;
}

/**
 * Settlement Engine Configuration options
 */
export interface SettlementEngineConfig {
  marketplaceFeeBps?: bigint; // default 300n (3%)
  deliveryDisputeWindowMs?: number; // default 24h
  disputeResolutionWindowMs?: number; // default 7 days
  cancellationGraceMs?: number; // default 2 min
  adminPublicKeyHex?: string;
  arbiterPublicKeyHex?: string;
  requireSignedTelemetryForIoT?: boolean; // default true
  strictConservationCheck?: boolean; // default true
}

/**
 * Typed error codes for transparent, fail-closed handling
 */
export type SettlementErrorCode =
  | "ORDER_NOT_FOUND"
  | "ORDER_NOT_SETTLEABLE"
  | "ORDER_NOT_DELIVERED"
  | "ORDER_ALREADY_SETTLED"
  | "ORDER_NOT_REFUNDABLE"
  | "SETTLEMENT_NOT_AUTHORIZED"
  | "SETTLEMENT_DISPUTE_WINDOW_ACTIVE"
  | "SETTLEMENT_ALREADY_FINALIZED"
  | "DISPUTE_PENDING"
  | "DISPUTE_WINDOW_CLOSED"
  | "DISPUTE_RESOLUTION_NOT_AUTHORIZED"
  | "DISPUTE_OUTCOME_INVALID"
  | "DISPUTE_SPLIT_INVALID"
  | "DISPUTE_NOT_OPEN"
  | "HOLD_NOT_COMPLETE"
  | "HELD_BALANCE_INSUFFICIENT"
  | "PAYOUT_AMOUNT_INVALID"
  | "PAYOUT_NOT_CONSERVED"
  | "IOT_SETTLEMENT_GUARD_REQUIRED"
  | "IOT_GUARD_VERIFICATION_FAILED"
  | "CAPACITY_ACCOUNTING_INVALID"
  | "REPLAY_SIGNATURE_DETECTED"
  | "SIGNATURE_EXPIRED"
  | "SIGNATURE_INVALID"
  | "BATCH_ORDER_FAILED";
