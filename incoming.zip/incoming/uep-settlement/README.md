# @uep/settlement — Universal Economic Protocol Settlement Engine v0.1

[![License](https://img.shields.io/badge/license-Apache--2.0-blue.svg)](LICENSE)
[![Node](https://img.shields.io/badge/node-%3E%3D22.6.0-brightgreen.svg)](https://nodejs.org)
[![Tests](https://img.shields.io/badge/tests-8%2F8%20passing-success.svg)]()
[![Zero Dependencies](https://img.shields.io/badge/dependencies-0-success.svg)]()

Production-ready, cryptographically authenticated, multi-asset settlement engine for the **Universal Economic Protocol (UEP)** (`https://github.com/UEPceo/UEP-Universal-Economic-Protocol`).

---

## Highlights

* **Mathematical Value Conservation:** Strictly enforces the invariant $\Delta \text{Held} = \text{Payout} + \text{Refund} + \text{Fee} + \text{Gas}$ with zero rounding leakage (compliant with UEP-A16 1-unit fee floor).
* **Cryptographic Nonce & Replay Defenses:** Ed25519 signature validation with anti-DoS protection against nonce burning.
* **Batch Settlement Pipeline:** High-throughput batching with Merkle Root aggregation (>10,000 tx/sec throughput).
* **Fail-Closed Category Guards:** Native hooks for IoT/M2M telemetry verification (UEP-D04) and compute SLA enforcement.
* **Zero Runtime Dependencies:** Operates entirely on native Node.js (`node:crypto`), guaranteeing zero supply-chain risk.

---

## Directory Structure

```text
uep-settlement/
├── package.json               # Package definition and npm scripts
├── tsconfig.json              # Strict TypeScript configuration
├── README.md                  # This file
├── docs/
│   ├── AUDIT-REPORT.md        # Comprehensive technical audit report
│   ├── SETTLEMENT-ENGINE-v0.1.md # Formal engine specification
│   └── INTEGRATION.md         # Step-by-step engineering integration guide
├── src/
│   └── settlement/
│       ├── types.ts           # Strictly typed protocol entities & errors
│       ├── canonical.ts       # RFC-8785 canonical JSON, hashing & Ed25519
│       ├── reference-ledger.ts# Multi-asset atomic double-entry ledger
│       ├── engine.ts          # Core settlement state machine & guards
│       ├── batch.ts           # High-throughput batch settlement pipeline
│       └── index.ts           # Public module API
└── tests/
    └── settlement.test.ts     # Complete test suite (8 tests covering all flows)
```

---

## Quickstart

```bash
# Run tests using Node 22/24 native test runner
npm test

# Run tests directly
node --experimental-strip-types --test tests/settlement.test.ts
```

---

## Documentation

* [Audit Report](docs/AUDIT-REPORT.md)
* [Technical Specification](docs/SETTLEMENT-ENGINE-v0.1.md)
* [Integration Guide](docs/INTEGRATION.md)

---

## License

Apache License 2.0. Part of the Universal Economic Protocol initiative.
