# UEP Settlement Engine Specification v0.1.0

## 1. Architectural Overview

The **UEP Settlement Engine** (`@uep/settlement`) provides deterministic, cryptographically authenticated, multi-asset financial settlement for the Universal Economic Protocol (UEP).

It operates at the boundary between the **Services Layer** (Marketplace, IoT/M2M, Compute, Storage) and the **Ledger/Economic State Layer** (Sparse Merkle Tree, Note Commitments, Treasury).

```text
┌────────────────────────────────────────────────────────┐
│             UEP SERVICE CONSUMER / AGENT               │
│          Signs ActorAuth with Ed25519 Key              │
└───────────────────────────┬────────────────────────────┘
                            │ Canonical Action Intent
                            ▼
┌────────────────────────────────────────────────────────┐
│              UEP SETTLEMENT ENGINE v0.1                │
│  - Nonce Replay Protector & Anti-DoS Verification     │
│  - Per-Order Mutex Lock Manager (Race Prevention)      │
│  - Category Settlement Guards (IoT Verified Telemetry) │
│  - Value Conservation Law Invariant Validator          │
│  - Batch Settlement Pipeline & Merkle Aggregator       │
└─────────────┬────────────────────────────┬─────────────┘
              │ Atomic Movement            │ Immutable Receipt
              ▼                            ▼
┌──────────────────────────┐  ┌──────────────────────────┐
│   SETTLEMENT LEDGER      │  │    SETTLEMENT RECEIPT    │
│  - Buyer Held Escrow     │  │  - Canonical State Hash  │
│  - Provider Payout       │  │  - Merkle Root Anchor    │
│  - Treasury 4-Way Split  │  │  - Ed25519 Witness Proof │
│  - Paymaster Gas Capture │  └──────────────────────────┘
└──────────────────────────┘
```

---

## 2. Order Settlement State Machine

An order moves through deterministic lifecycle states:

```text
              [ PENDING_HOLD ]
                     │
                     │ holdFunds(gross + gas)
                     ▼
                 [ HELD ]
                     │
                     │ markDelivered(reportHash)
                     ▼
               [ DELIVERED ]
                │         │
 buyer settle() │         │ openDispute(reason)
 provider claim │         ▼
                │    [ DISPUTED ]
                │     │        │
                │     │        │ Arbiter resolveDispute()
                │     │        │ - RELEASE
                │     │        │ - REFUND_BUYER
                │     │        │ - SPLIT
                │     │        ▼
                │     │   [ SETTLED / REFUNDED / SPLIT_SETTLED ]
                │     │
                │     │ Timeout -> Category Guard Check
                │     └────────► [ TIMEOUT RELEASE / REFUND ]
                │
                ▼
        [ SETTLED ]
```

---

## 3. Mathematical Value Conservation Invariant

Every settlement execution must satisfy the Zero-Leakage Conservation Invariant:

$$\Delta \text{Held} = \text{ProviderPayout} + \text{BuyerRefund} + \text{MarketplaceFee} + \text{GasCaptured}$$

Where:
* **$\text{MarketplaceFee}$**: Calculated as:
  $$\text{Fee} = \max\left(1, \left\lfloor \frac{\text{Gross} \times \text{FeeBps}}{10000} \right\rfloor\right)$$
  (Governed by UEP-A16: minimum 1 asset unit for any positive amount).
* **$\text{ProviderPayout}$**: $\text{Gross} - \text{Fee}$.
* **$\text{BuyerRefund}$**: $\text{Held} - \text{ProviderPayout} - \text{Fee} - \text{GasCaptured}$.
* **$\text{Treasury Split}$**: The Marketplace fee is atomically split across 4 buckets:
  * 40% Infrastructure Pool
  * 25% Protocol Development Pool
  * 20% Liquidity & Insurance Reserve
  * 15% Ecosystem & Governance Grants

---

## 4. Cryptographic Proofs & Canonical Receipts

Each finalized settlement generates a `SettlementReceipt` with a canonical SHA-256 / Poseidon hash:

```typescript
export interface SettlementReceipt {
  receiptId: string;
  orderId: string;
  listingId: string;
  asset: string;
  grossAmount: bigint;
  providerPayout: bigint;
  buyerRefund: bigint;
  marketplaceFee: bigint;
  gasFeeCaptured: bigint;
  outcome: "RELEASE" | "REFUND_BUYER" | "SPLIT";
  categoryGuard: "PASSED" | "FAILED" | "ARBITER_OVERRIDE" | "TIMEOUT_REFUNDED" | "NOT_APPLICABLE";
  capacityRestored: bigint;
  settledAt: number;
  engineVersion: "0.1.0";
  canonicalHash: string; // Deterministic RFC-8785 JSON digest
}
```

In batch execution mode, $N$ receipts are combined into a binary Merkle tree yielding a `BatchSettlementProof.rootHash`, which can be committed directly to a UEP Ledger block header or SMT root.
