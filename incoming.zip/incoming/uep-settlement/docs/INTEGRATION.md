# Guía de Integración para Ingenieros de UEP

Esta guía proporciona las instrucciones exactas para que el equipo de ingeniería integre el nuevo módulo `@uep/settlement` tanto en el repositorio principal del protocolo (`UEP-Universal-Economic-Protocol`) como en la pasarela de servicios (`uep-bolt-integration`).

---

## 1. Integración en `UEP-Universal-Economic-Protocol`

### Paso 1: Ubicación del Módulo
Copia la carpeta `src/settlement/` directamente en:
```text
UEP-Universal-Economic-Protocol/
  └── src/
      └── settlement/
          ├── types.ts
          ├── canonical.ts
          ├── reference-ledger.ts
          ├── engine.ts
          ├── batch.ts
          └── index.ts
```

### Paso 2: Conexión con `DigitalServicesMarketplace` (`src/marketplace/marketplace.ts`)
En lugar de mutar directamente `this.held` y `this.accounts` en el método privado `payout()`, delega la ejecución al `UepSettlementEngine`:

```typescript
import { UepSettlementEngine } from "../settlement/index.ts";

export class DigitalServicesMarketplace {
  private settlementEngine: UepSettlementEngine;

  constructor(config: MarketplaceConfig = {}) {
    // Inicialización del motor con configuración de claves y políticas
    this.settlementEngine = new UepSettlementEngine(this.ledgerAdapter, {
      marketplaceFeeBps: BigInt(config.marketplaceFeeBps ?? 300),
      deliveryDisputeWindowMs: config.deliveryDisputeWindowMs,
      disputeResolutionWindowMs: config.disputeResolutionWindowMs,
      arbiterPublicKeyHex: this.arbiterKey ? publicKeyHexOf(this.arbiterKey) : undefined,
    });
  }

  // En settle():
  settle(orderId: string, auth: ActorAuth | undefined): SettlementRecord {
    const receipt = this.settlementEngine.settle(orderId, auth!);
    return this.mapReceiptToRecord(receipt);
  }
}
```

### Paso 3: Vinculación con las Guardias de Telemetría IoT (`src/service/iot-m2m.ts`)
Cuando se adjunte el servicio IoT con `attachCategoryService("IOT_M2M")`:

```typescript
marketplace.settlementEngine.attachCategoryGuard("IOT_M2M", {
  settlementGuard: (order) => {
    // Validar telemetría firmada del reporte entregado
    iotService.verifyDeliveredTelemetry(order.orderId, order.deliveryReportHash);
  },
  consumedUnits: (order) => {
    return iotService.getVerifiedUnits(order.orderId);
  }
});
```

---

## 2. Integración en `uep-bolt-integration` (`api-gateway`)

En el repositorio `uep-bolt-integration`, reemplaza la lógica en memoria de `api-gateway/src/server.ts` con el motor real:

```typescript
import { UepSettlementEngine, ReferenceSettlementLedger } from "./settlement/index.js";

const ledger = new ReferenceSettlementLedger();
const settlementEngine = new UepSettlementEngine(ledger, {
  marketplaceFeeBps: 300n, // 3%
});

// Endpoint de liquidación firmado
app.post("/v1/orders/:id/settle", requireUepAuth(ledger), async (req, res) => {
  try {
    const orderId = req.params.id;
    const authHeader = req.headers["x-uep-auth"] as string;
    const actorAuth = JSON.parse(authHeader);

    const receipt = settlementEngine.settle(orderId, actorAuth);
    res.json({
      ok: true,
      receipt,
      canonicalHash: receipt.canonicalHash,
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});
```

---

## 3. Comandos de Verificación y Testing

Para verificar que la suite corre limpiamente en tu entorno:

```bash
# Ejecutar los 8 tests unitarios y de seguridad
npm test

# Ejecutar con Node nativo sin dependencias
node --experimental-strip-types --test tests/settlement.test.ts
```

Todos los tests deben reportar `ok` en menos de 50 milisegundos con cero dependencias externas.
