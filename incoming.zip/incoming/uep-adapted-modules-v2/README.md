# UEP category modules v0.2.0 (hardened)

Swap, relay, dispute and drip adapters over business-layer HOLDs, rewritten after the audit in
[`docs/AUDIT-FIXES.md`](docs/AUDIT-FIXES.md). **Testnet reference code. Not production. No ZK claim.**

```
npm install
npm test          # tsc, then node --test (63 tests, including a seeded fuzz)
```

Node 22.6+. TypeScript 5.7, `@types/node` 22 (pinned in `package.json`).

## Layout

```
src/uep/
  ids.ts              id validation (<namespace>/<symbol> assets, safe integers, hex)
  canonical.ts        injective canonical encoding for everything hashed or signed
  crypto.ts           Ed25519, key-derived account ids, hashlock, ChaCha20, RFC 6962/9162 Merkle
  registry.ts         key registry (proof of possession), Signed<Body>, ReplayGuard, MonotonicClock
  ledger.ts           balances, module-owned HOLDs, signed mint, atomic rollback, LedgerPort
  treasury.ts         40/25/20/15 buckets backed by real funds, admin-signed paymaster funding
  settlement-index.ts settled work, writable only by swap and relay
  fees.ts             protocol 0.1% and marketplace 3% (min 1), BigInt maths, exact splits
src/category/
  swap.ts             dual-HOLD hashlock swap, signed intent + acceptance
  relay.ts            chunk-fraud relay: bond, recipient confirmation, fraud proofs, slashing
  dispute.ts          cases, evidence, arbiter quorum, bond, timeout; delegates escrow to categories
  disputable.ts       contract between the dispute engine and the categories
  drip.ts             paymaster drip bound to settled work
test/                 foundations, swap, relay, dispute, drip, fuzz
```

## Composition (see `test/helpers.ts → world()`)

```ts
const registry = new KeyRegistry(NET);                 // register faucet, admin, arbiters, users
const book     = new BalanceBook(registry, faucet.id); // only the composition root holds this
book.reserveAccount(PROTOCOL_TREASURY, 'protocol-governance');
const treasury = new Treasury(book, registry, admin.id);
const index    = new SettlementIndex();
const swap     = new SwapCategory(book, treasury, registry, index, NET);
const relay    = new RelayCategory(book, treasury, registry, index, NET);
const disputes = new DisputeCategory(book, treasury, registry, arbiterIds, 2);
disputes.attach(swap, swap.issueDisputeCap());
disputes.attach(relay, relay.issueDisputeCap());
const drip     = new DripController(treasury, treasury.issuePaymasterCap(), index, registry);
```

Every action that spends or locks funds is a `Signed<Body>` message. Modules never see private keys.

## Design decisions to confirm with the lead engineer

The public README (the only part of the repo that could be read) fixes the dispute outcomes
(`RELEASE` / `REFUND_BUYER` / `SPLIT`), the 3% fee, the 40/25/20/15 split and the refund-on-timeout
default. The following were **choices made here** and should be confirmed or replaced:

1. A forfeited dispute bond and a slashed relay bond go **80% to the injured party, 20% to the
   treasury `riskReserve`** (`forfeitRespondentBps`, `slashBuyerBps`).
2. Forfeiture requires the arbiters to sign `frivolous: true`, and only on a verdict entirely
   against the claimant. A claimant who simply loses keeps the bond.
3. Dispute timeout default is refund-buyer (or an even split). `RELEASE` is not allowed as a default.
4. Bond = `max(50, 1% of the escrow in that asset)`, one dispute per order.
5. Drip pays at most 50% of the marketplace fee the order generated, once per order.
6. Dust that cannot cover its fees on a partial release is returned to the locker instead of paid.
7. Quorum must be a strict majority of the arbiter set.

## Known limits

Listed in `docs/AUDIT-FIXES.md` ("Residual limits"): SHA-256 instead of Poseidon, in-process
isolation only, caller-supplied clock, no arbiter appeal or staking, no IoT module in this package.
