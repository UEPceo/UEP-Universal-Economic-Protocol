# Audit fixes: finding → fix → test

Every finding from the audit of `uep-adapted-modules.zip` (v0.1.0), what changed in v0.2.0, and the
test that fails if the fix is removed. "PoC Pn" refers to the 14 attack scripts of the audit; each
one is now a regression test. Test names are in `test/*.test.ts`.

A mutation run (re-introducing 8 of the original flaws by hand) is caught by the suite in every
case; see "How the tests were validated" at the end.

## Critical

| # | Finding (v0.1.0) | Fix (v0.2.0) | Covered by |
|---|---|---|---|
| C1 | Arbiter quorum forgeable: only ids were compared, signatures were verified with the public key carried by the caller (PoC P1) | Arbiter set is fixed at construction. Every verdict signature is verified against the **key registry**. Account ids are derived from the public key and registration needs proof of possession, so nobody can present their own key under an arbiter's id. Quorum must be a strict majority of distinct signers; signers cannot be parties; all signatures must carry the identical verdict, bound to the dispute id | `PoC P1`, `an arbiter who is a party…`, `constructor requires…` |
| C2 | `REFUND_BUYER` confiscated the buyer's bond and never moved escrow (PoC P3) | The dispute engine no longer touches escrow. It asks the owning category (swap/relay) to apply `releaseBps` (10000 release, 0 refund, between = split). Bond is returned unless arbiters sign `frivolous` on a verdict that goes entirely against the claimant | `PoC P3`, `frivolous is only valid…`, `SPLIT pays each leg…`, `seller side can claim too` |
| C3 | Provider could self-confirm content and close the fraud window (PoC P7) | `confirm` needs a message signed by the **named recipient**, verified against the registry, bound to the committed `chunkRoot` | `PoC P7` |
| C4 | Swap "signatures" were tautological: `open()` took both private keys | Buyer signs the intent, market maker signs an acceptance of that exact `intentId`. Modules receive `Signed<Body>` messages and never a private key | `signatures are verified, not assumed` |
| C5 | `settle` was not atomic: a fee larger than the leg failed after the first leg moved (PoC P6) | Legs too small to survive the fees are refused at `open`. Settlement runs in `ledger.atomic`, pays exactly the held amounts, and dust that cannot cover its fee is returned | `PoC P6`, fuzz |

## High

| # | Finding | Fix | Covered by |
|---|---|---|---|
| H1 | Dispute bond locked before the replay check and lost (PoC P2) | Validation first; `openHold` + `freeze` happen in one atomic block; nonce consumed only after success | `PoC P2` |
| H2 | Dispute id was `orderId+now`; squattable, duplicates possible | Deterministic id per `(category, orderId)`; one case per order, ever | `one case per order…` |
| H3 | Bond stuck forever if arbiters did not act in the window (PoC P4) | Evidence window, then resolution window, then permissionless `timeout()` applying a default (refund buyer or even split, never RELEASE), returning the bond and unfreezing | `PoC P4`, `timeout default…`, fuzz liveness |
| H4 | No evidence, no reply from the respondent, no party check | `submitEvidence`: both parties, until the evidence deadline, digest-checked, size- and count-limited, deduplicated | `evidence from both parties…` |
| H5 | Escrow in the dispute was whatever the claimant supplied; no link to swap/relay | The engine reads `escrowView()` from the category that owns the holds, freezes the order, and the category applies the verdict. Frozen orders cannot settle, finalize or expire | `PoC P4`, `dispute on relay…` |
| H6 | Relay `invalidFraudAttempts` never incremented (PoC P8) | Counted per submitter (buyer / recipient only), persisted, refused after 3 | `PoC P8` |
| H7 | `FRAUD_PROVEN` had no effect | State change, buyer refunded in full, provider bond slashed 80% buyer / 20% treasury risk reserve, counter incremented | `a proven chunk fraud…` |
| H8 | Relay unused fields (`fraudWindowEndsAt`, `retainer`, counters), `settleConservation` did not touch the ledger, price 0 gave a negative net (PoC P9) | Real lifecycle over ledger holds: price from the buyer, bond from the provider. Price/bond floors enforced; fee can never exceed the amount | `PoC P9`, `happy path…`, `no key before the deadline…` |
| H9 | `faucet` public; ids not validated, so one poisoned asset id made `assertConserved` fail forever (PoC P10); supply unbounded (PoC P11) | Mint needs a faucet-key signature, nonce replay-protected. Asset/account ids validated (`<namespace>/<symbol>`). Balances in nested maps, no string-concatenated keys. Supply checked to stay a safe integer | `PoC P12/P10/P11 ledger` |
| H10 | Treasury `buckets()` mutable; `fundPaymaster` unauthenticated (PoC P12) | Buckets private (copies returned). Credits only accepted against real funds in the treasury account. Paymaster funded only by an admin-signed move out of `distributable`, spent only through a capability issued once | `treasury: buckets are copies…` |
| H11 | `spendPaymaster` decremented the bucket before the transfer could fail (PoC P13) | Ledger move first, bucket updated after; failed claim changes nothing | `PoC P13` |
| H12 | Drip validated against a caller-supplied `Map`; any `receiptHash` accepted → wash-trading | Drip reads a `SettlementIndex` that only swap/relay can write. A node can only claim for its own settled orders, once each, up to 50% of the marketplace fee that order generated, so wash trading always loses money | `wash trading never pays back…`, `replay, double claim…` |
| H13 | `last ?? 0` cooldown bug; hourly cap collapsed to 0 on small buckets | `undefined` check; cap is `max(maxSingle, bps of window-start bucket)` | `cooldown works from the first timestamps`, `PoC P13` |
| H14 | Open swap locked one leg and left it (PoC P5) | Both holds in one atomic block; nonce not burned by a failed open | `PoC P5` |

## Medium

| # | Finding | Fix | Covered by |
|---|---|---|---|
| M1 | `canonical()` ambiguous (PoC P14) | `canonicalJson`: JSON-escaped strings, sorted keys, safe integers only; floats/undefined/Buffers rejected | `PoC P14` |
| M2 | Merkle claimed RFC 6962 but double-hashed leaves and duplicated odd nodes | RFC 6962/9162 tree (split at largest power of two, no duplication), fixed-width binary leaf encoding, RFC 9162 inclusion-proof verification | `merkle: RFC 9162…`, `an odd node is not duplicated` |
| M3 | Fraud verifier used the plaintext stored in the order | Order holds commitments only. Fraud is checked from `chunkRoot`, `wrapRoot`, `kCommit`, `contentLen`, `leafCount` and the **published** key | `order record never contains the plaintext…` |
| M4 | Hashlock accepted any preimage | Minimum 16 bytes; domain-separated with network and nonce via `canonicalJson` | `hashlock: weak preimages refused` |
| M5 | No clock sanity | Per-module monotonic clock; `CLOCK_REGRESSION` | `clock: regression is refused`, `swap: clock cannot move backwards` |
| M6 | `tsconfig` pointed at `/tmp/uep-tools`; no way to run `npm test` elsewhere | Standard `types: ["node"]`, pinned devDependencies | build |
| M7 | Tests only covered happy paths | 63 tests: all 14 PoCs, per-module negatives, a seeded fuzz with invariants after every step and a liveness check at the end | all |

## How the tests were validated

Eight flaws were re-introduced by hand into a copy of the code (skip the arbiter-set check, let any
party confirm a relay, forfeit the bond on any loss, drop the payout-sum check, allow tiny swap legs,
stop counting invalid fraud attempts, drop the drip provider check, remove the timeout escape). Each
mutation made at least one test fail, and each failing test is the one named for that property.

## Residual limits (not fixed, by design or by scope)

1. **Not the real hash.** Commitments are domain-separated SHA-256. The repo's core hash is Poseidon
   over BN254; wiring it in is a separate milestone. Nothing here is a ZK claim.
2. **In-process, single node.** `LedgerPort`, `DisputeCap`, `PaymasterCap` and `IndexWriter` stop
   mistakes and casual misuse between modules, not a hostile module running in the same JS process.
   The composition root still holds the raw `BalanceBook`.
3. **Time is caller-supplied.** The monotonic guard only refuses to go backwards. A deployment must
   bind `now` to a trusted clock.
4. **Treasury buckets are outside `ledger.atomic`.** Order of operations makes this safe today (the
   treasury check always runs after the funds have landed and cannot fail then), and the fuzz
   confirms it, but a future change that adds a failing step after `collect*` must be reviewed.
5. **Arbiter corruption is not modelled.** A colluding strict majority of arbiters can issue any
   verdict. There is no appeal or arbiter staking yet; those are the next mechanisms to add.
6. **No IoT module** was included in the zip, so the repo's IoT category guard and signed-telemetry
   rule are not exercised here. Disputes cover swap and relay only.
7. **No lockfile.** The sandbox had no network; run `npm install` once and commit `package-lock.json`.
