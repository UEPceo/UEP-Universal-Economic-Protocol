import { test } from 'node:test';
import { swapHashlock, type Identity } from '../src/uep/crypto.js';
import { buildFraudProof, CHUNK } from '../src/category/relay.js';
import {
  assert, NET, TUSD, TEUR, PREIMAGE,
  world, openSwap, openRelay, relayFixture, publishKeyMsg, confirmMsg, fraudMsg,
  openDisputeMsg, verdictMsgs, fundPaymaster, dripClaim,
  type RelayFixture,
} from './helpers.js';

function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Our own errors are coded strings. A TypeError/RangeError means a real bug, so it fails the run. */
function attempt(fn: () => unknown): boolean {
  try {
    fn();
    return true;
  } catch (e) {
    if (e instanceof TypeError || e instanceof RangeError || e instanceof ReferenceError || e instanceof SyntaxError) throw e;
    return false;
  }
}

function runFuzz(seed: number, steps: number) {
  const rnd = mulberry32(seed);
  const int = (lo: number, hi: number) => lo + Math.floor(rnd() * (hi - lo + 1));
  const pick = <T>(xs: T[]): T => xs[int(0, xs.length - 1)];

  const w = world({ dispute: { evidenceSeconds: 60, resolutionSeconds: 6000 } });
  const actors: Identity[] = Array.from({ length: 6 }, (_, i) => w.actor(`a${i}`));
  for (const a of actors) {
    w.mint(a.id, TUSD, 5000);
    w.mint(a.id, TEUR, 5000);
  }

  let t = 1;
  let nonce = 1;
  const swaps: { id: string; nonce: number }[] = [];
  const relays: { f: RelayFixture; chunks: number }[] = [];
  const cases: { id: string; order: string; category: 'swap' | 'relay' }[] = [];
  const counts = { swapOpen: 0, relayOpen: 0, disputeOpen: 0, resolved: 0, claims: 0 };

  for (let step = 0; step < steps; step++) {
    t += rnd() < 0.05 ? int(500, 4000) : int(0, 60);
    const op = pick([0, 1, 1, 2, 3, 4, 4, 5, 5, 6, 6, 7, 8, 8, 9, 9, 9, 10, 11, 11, 12, 12, 12, 13]);
    const a = pick(actors);
    let b = pick(actors);
    while (b.id === a.id) b = pick(actors);
    const c = pick(actors.filter((x) => x.id !== a.id && x.id !== b.id));

    switch (op) {
      case 0:
        attempt(() => w.mint(a.id, rnd() < 0.5 ? TUSD : TEUR, int(1, 800)));
        break;
      case 1: {
        const n = nonce++;
        const tiny = rnd() < 0.2;
        if (
          attempt(() => {
            const r = openSwap(w, a, b, {
              fromAmount: tiny ? int(1, 4) : int(2, 900),
              toAmount: tiny ? int(1, 4) : int(2, 900),
              orderNonce: n,
              hashlock: swapHashlock(PREIMAGE, n, NET),
              deadline: t + int(10, 3000),
            }, t);
            swaps.push({ id: r.intentId, nonce: n });
          })
        ) counts.swapOpen++;
        break;
      }
      case 2: {
        if (!swaps.length) break;
        const s = pick(swaps);
        attempt(() => w.swap.settle(s.id, rnd() < 0.9 ? PREIMAGE : 'wrong-preimage-123456', t));
        break;
      }
      case 3: {
        if (!swaps.length) break;
        attempt(() => w.swap.expire(pick(swaps).id, t));
        break;
      }
      case 4: {
        const len = pick([1, 700, CHUNK, CHUNK + 1, 3 * CHUNK]);
        const tamper = rnd() < 0.25 ? (wr: Buffer) => { wr[int(0, Math.min(wr.length, len) - 1)] ^= 0x55; } : undefined;
        if (
          attempt(() => {
            const f = relayFixture(a, b, c, { price: int(2, 3000), nonce: nonce++, keyDeadline: t + int(10, 3000), fraudWindowSeconds: int(60, 900) }, len, tamper, t);
            openRelay(w, f, int(18, 60), t);
            relays.push({ f, chunks: f.blob.commitment.leafCount });
          })
        ) counts.relayOpen++;
        break;
      }
      case 5: {
        if (!relays.length) break;
        const { f } = pick(relays);
        attempt(() => w.relay.publishKey(publishKeyMsg(f, rnd() < 0.9 ? f.k : Buffer.alloc(32, 7)), t));
        break;
      }
      case 6: {
        if (!relays.length) break;
        const { f } = pick(relays);
        const which = int(0, 2);
        if (which === 0) attempt(() => w.relay.confirm(confirmMsg(f), t));
        else if (which === 1) attempt(() => w.relay.finalize(f.orderId, t));
        else attempt(() => w.relay.expire(f.orderId, t));
        break;
      }
      case 7: {
        if (!relays.length) break;
        const { f, chunks } = pick(relays);
        const proof = buildFraudProof(f.blob.wrapped, f.blob.leaves, int(0, chunks - 1));
        attempt(() => w.relay.submitFraudProof(fraudMsg(f, proof, rnd() < 0.5 ? f.recipient : f.buyer), proof, t));
        break;
      }
      case 8: {
        const useSwap = swaps.length && (!relays.length || rnd() < 0.5);
        const category = useSwap ? 'swap' : 'relay';
        const orderId = useSwap ? pick(swaps).id : relays.length ? pick(relays).f.orderId : undefined;
        if (!orderId) break;
        const view = (useSwap ? w.swap : w.relay).escrowView(orderId);
        if (!view) break;
        const who = rnd() < 0.5 ? view.buyerSide[0] : view.sellerSide[0];
        const claimant = [...actors].find((x) => x.id === who);
        if (!claimant) break;
        const asset = view.escrows[0].asset;
        const need = Math.max(50, Math.ceil((view.escrows.filter((e) => e.asset === asset).reduce((s, e) => s + e.amount, 0) * 100) / 10_000));
        if (
          attempt(() => {
            const cs = w.disputes.open(openDisputeMsg(claimant, category, orderId, asset, need + int(0, 3), nonce++), t);
            cases.push({ id: cs.disputeId, order: orderId, category });
          })
        ) counts.disputeOpen++;
        break;
      }
      case 9: {
        if (!cases.length) break;
        const cs = pick(cases);
        const bps = pick([0, 5000, 10_000, int(1, 9999)]);
        const signers = [...w.arbiters].sort(() => rnd() - 0.5).slice(0, rnd() < 0.8 ? 2 : int(1, 3));
        if (attempt(() => w.disputes.resolve(cs.id, verdictMsgs(signers, cs.id, cs.order, cs.category, bps, rnd() < 0.15), t))) counts.resolved++;
        break;
      }
      case 10: {
        if (!cases.length) break;
        attempt(() => w.disputes.timeout(pick(cases).id, t));
        break;
      }
      case 11:
        attempt(() => fundPaymaster(w, rnd() < 0.5 ? TUSD : TEUR, int(1, 6)));
        break;
      case 12: {
        if (!relays.length) break;
        const { f } = pick(relays);
        if (attempt(() => w.drip.claim(dripClaim(w, f.provider, f.orderId, f.offer.asset, int(1, 4), t), t))) counts.claims++;
        break;
      }
      case 13: {
        // Value-conserving attack surface: arbitrary garbage must never throw a non-coded error.
        attempt(() => w.swap.settle('swp_nope', '', t));
        attempt(() => w.relay.finalize('rly_nope', t));
        break;
      }
    }

    // Invariants after EVERY step, whether it succeeded or threw.
    w.book.assertAllConserved();
    w.treasury.assertBacked(TUSD);
    w.treasury.assertBacked(TEUR);
  }

  // Liveness: with enough time and permissionless exits, nothing may stay locked.
  t += 10_000_000;
  for (const cs of cases) attempt(() => w.disputes.timeout(cs.id, t));
  for (const s of swaps) attempt(() => w.swap.expire(s.id, t));
  for (const { f } of relays) {
    attempt(() => w.relay.expire(f.orderId, t));
    attempt(() => w.relay.finalize(f.orderId, t));
  }
  for (const x of actors) {
    assert.equal(w.book.lockedOf(x.id, TUSD), 0, `seed ${seed}: stuck TUSD for ${x.label}`);
    assert.equal(w.book.lockedOf(x.id, TEUR), 0, `seed ${seed}: stuck TEUR for ${x.label}`);
  }
  w.book.assertAllConserved();
  return counts;
}

test('fuzz: conservation, treasury backing and liveness hold across random valid and invalid operations', () => {
  const totals = { swapOpen: 0, relayOpen: 0, disputeOpen: 0, resolved: 0, claims: 0 };
  for (const seed of [1, 7, 42, 1337, 20261004]) {
    const c = runFuzz(seed, 600);
    for (const k of Object.keys(totals) as (keyof typeof totals)[]) totals[k] += c[k];
  }
  // The fuzzer must actually reach the interesting paths, otherwise a green run means nothing.
  assert.ok(totals.swapOpen > 50, `swaps opened: ${totals.swapOpen}`);
  assert.ok(totals.relayOpen > 50, `relays opened: ${totals.relayOpen}`);
  assert.ok(totals.disputeOpen > 10, `disputes opened: ${totals.disputeOpen}`);
  assert.ok(totals.resolved >= 5, `disputes resolved: ${totals.resolved}`);
  assert.ok(totals.claims >= 3, `drip claims: ${totals.claims}`);
  console.log('fuzz coverage', JSON.stringify(totals));
});
