import { test } from 'node:test';
import { signMessage } from '../src/uep/registry.js';
import { DRIP_CLAIM_DOMAIN } from '../src/category/drip.js';
import {
  assert, expectThrow, NET, TUSD,
  world, relayFixture, openRelay, publishKeyMsg, confirmMsg, fundPaymaster, dripClaim,
  type World,
} from './helpers.js';
import type { Identity } from '../src/uep/crypto.js';

interface Econ {
  w: World;
  buyer: Identity;
  provider: Identity;
  recipient: Identity;
  nonce: number;
  settle(price: number, now: number): string;
}

function econ(opts: Parameters<typeof world>[0] = {}): Econ {
  const w = world(opts);
  const buyer = w.actor('buyer');
  const provider = w.actor('provider');
  const recipient = w.actor('recipient');
  w.mint(buyer.id, TUSD, 10_000_000);
  w.mint(provider.id, TUSD, 100_000);
  const e: Econ = {
    w, buyer, provider, recipient, nonce: 1,
    settle(price, now) {
      const f = relayFixture(buyer, provider, recipient, { price, nonce: e.nonce++, keyDeadline: now + 3600 }, 500, undefined, now);
      openRelay(w, f, 20, now);
      w.relay.publishKey(publishKeyMsg(f), now);
      w.relay.confirm(confirmMsg(f), now);
      return f.orderId;
    },
  };
  return e;
}

test('drip: a node claims against its own settled work and the paymaster is debited', () => {
  const { w, provider, settle } = econ();
  const order = settle(10_000, 100); // fee 300 -> distributable 45
  assert.equal(w.treasury.buckets(TUSD).distributable, 45);
  fundPaymaster(w, TUSD, 40);
  const before = w.book.free(provider.id, TUSD);
  assert.equal(w.drip.claim(dripClaim(w, provider, order, TUSD, 30, 101), 101), 30);
  assert.equal(w.book.free(provider.id, TUSD), before + 30);
  assert.equal(w.treasury.buckets(TUSD).paymaster, 10);
  w.checkInvariants();
});

test('drip: replay, double claim per order, unknown work, wrong node, wrong receipt and wrong signer are refused', () => {
  const { w, provider, recipient, settle } = econ();
  const order = settle(10_000, 100);
  fundPaymaster(w, TUSD, 40);
  const msg = dripClaim(w, provider, order, TUSD, 5, 101);
  w.drip.claim(msg, 101);
  expectThrow(() => w.drip.claim(msg, 200), 'REPLAY');
  expectThrow(() => w.drip.claim(dripClaim(w, provider, order, TUSD, 5, 201), 201), 'DRIP_ALREADY_CLAIMED');
  expectThrow(() => w.drip.claim(dripClaim(w, provider, 'ord_unknown', TUSD, 5, 202), 202), 'DRIP_WORK_UNVERIFIED');
  expectThrow(() => w.drip.claim(dripClaim(w, recipient, order, TUSD, 5, 203), 203), 'DRIP_NOT_PROVIDER');
  const bad = signMessage(provider, NET, DRIP_CLAIM_DOMAIN, { nodeId: provider.id, asset: TUSD, amount: 5, orderId: order, receiptHash: 'ab'.repeat(32), nonce: 5 });
  expectThrow(() => w.drip.claim(bad, 204), 'DRIP_WORK_MISMATCH');
  const impersonate = signMessage(provider, NET, DRIP_CLAIM_DOMAIN, { nodeId: recipient.id, asset: TUSD, amount: 5, orderId: order, receiptHash: 'ab'.repeat(32), nonce: 6 });
  expectThrow(() => w.drip.claim(impersonate, 205), 'DRIP_SIGNER');
  w.checkInvariants();
});

test('drip: entitlement is a share of the fee the order generated; tiny fees give nothing', () => {
  const { w, provider, settle } = econ();
  const big = settle(10_000, 100);
  fundPaymaster(w, TUSD, 40);
  const small = settle(100, 101); // fee 3 -> entitlement 1
  const tiny = settle(20, 102); // fee 1 -> entitlement 0
  expectThrow(() => w.drip.claim(dripClaim(w, provider, small, TUSD, 2, 103), 103), 'DRIP_AMOUNT_EXCEEDS_ENTITLEMENT');
  expectThrow(() => w.drip.claim(dripClaim(w, provider, tiny, TUSD, 1, 104), 104), 'DRIP_NO_ENTITLEMENT');
  expectThrow(() => w.drip.claim(dripClaim(w, provider, big, TUSD, 51, 105), 105), 'DRIP_AMOUNT_EXCEEDS_SINGLE');
  assert.equal(w.drip.claim(dripClaim(w, provider, small, TUSD, 1, 106), 106), 1);
  w.checkInvariants();
});

test('drip: wash trading never pays back what it costs in fees', () => {
  const { w, provider, settle } = econ();
  const seed = settle(10_000, 100);
  fundPaymaster(w, TUSD, 40);
  let feesPaid = 0;
  let recovered = 0;
  let now = 101;
  for (let i = 0; i < 20; i++) {
    const id = settle(100, now);
    feesPaid += w.index.get(id)!.feeCollected;
    now += 31;
    recovered += w.drip.claim(dripClaim(w, provider, id, TUSD, 1, now), now);
  }
  assert.equal(feesPaid, 60);
  assert.equal(recovered, 20);
  assert.ok(recovered < feesPaid, 'draw-back must be strictly below fees paid');
  assert.ok(w.index.get(seed));
  w.checkInvariants();
});

test('drip: cooldown works from the first timestamps and expires normally', () => {
  const { w, provider, settle } = econ();
  const seed = settle(10_000, 5);
  fundPaymaster(w, TUSD, 40);
  const a = settle(1000, 6);
  const b = settle(1000, 7);
  assert.equal(w.drip.claim(dripClaim(w, provider, a, TUSD, 1, 8), 8), 1); // old code rejected this when now < cooldown
  expectThrow(() => w.drip.claim(dripClaim(w, provider, b, TUSD, 1, 9), 9), 'DRIP_COOLDOWN');
  assert.equal(w.drip.claim(dripClaim(w, provider, b, TUSD, 1, 39), 39), 1);
  assert.ok(seed);
  w.checkInvariants();
});

test('PoC P13: a failed claim changes nothing and a small bucket still pays', () => {
  const { w, provider, settle } = econ();
  const order = settle(10_000, 100);
  fundPaymaster(w, TUSD, 5);
  const before = w.book.free(provider.id, TUSD);
  expectThrow(() => w.drip.claim(dripClaim(w, provider, order, TUSD, 10, 101), 101), 'TREASURY_PAYMASTER_EMPTY');
  assert.equal(w.treasury.buckets(TUSD).paymaster, 5);
  assert.equal(w.book.free(provider.id, TUSD), before);
  // The window was not consumed by the failure; the small bucket is spendable.
  assert.equal(w.drip.claim(dripClaim(w, provider, order, TUSD, 5, 102), 102), 5);
  assert.equal(w.treasury.buckets(TUSD).paymaster, 0);
  w.checkInvariants();
});

test('drip: hourly cap holds and resets with the window', () => {
  const { w, provider, settle } = econ({ drip: { maxSingle: 10, perOrderBps: 10_000, hourlyCapBps: 100, cooldownSeconds: 0 } });
  const a = settle(10_000, 100);
  const b = settle(10_000, 101);
  const c = settle(10_000, 102);
  fundPaymaster(w, TUSD, 100);
  assert.equal(w.drip.claim(dripClaim(w, provider, a, TUSD, 10, 103), 103), 10);
  expectThrow(() => w.drip.claim(dripClaim(w, provider, b, TUSD, 1, 104), 104), 'DRIP_HOURLY_CAP');
  assert.equal(w.drip.claim(dripClaim(w, provider, b, TUSD, 5, 103 + 3600), 103 + 3600), 5);
  assert.ok(c);
  w.checkInvariants();
});

test('drip: receipts expire', () => {
  const { w, provider, settle } = econ();
  const order = settle(10_000, 100);
  fundPaymaster(w, TUSD, 40);
  const late = 100 + 86_400 + 1;
  expectThrow(() => w.drip.claim(dripClaim(w, provider, order, TUSD, 5, late), late), 'DRIP_RECEIPT_EXPIRED');
});

test('settlement index: only the owning modules can write, once per order', () => {
  const { w, settle } = econ();
  const order = settle(10_000, 100);
  expectThrow(() => w.index.issueWriter('relay'), 'INDEX_WRITER_ALREADY_ISSUED');
  const copy = w.index.get(order)!;
  copy.feeCollected = 1_000_000;
  assert.equal(w.index.get(order)!.feeCollected, 300, 'index rows are returned as copies');
});
