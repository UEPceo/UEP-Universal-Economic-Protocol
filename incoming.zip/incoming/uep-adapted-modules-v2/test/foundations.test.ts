import { test } from 'node:test';
import { createIdentity, leafHash, merklePath, merkleRoot, sha256, verifyMerklePath, swapHashlock } from '../src/uep/crypto.js';
import { canonicalJson } from '../src/uep/canonical.js';
import { marketplaceFee, protocolFee, splitBps, TREASURY_SPLIT, mulDivFloor } from '../src/uep/fees.js';
import { BalanceBook, MINT_DOMAIN } from '../src/uep/ledger.js';
import { KeyRegistry, signMessage, verifyMessage, MonotonicClock } from '../src/uep/registry.js';
import { publicKeyDer, sign } from '../src/uep/crypto.js';
import { assert, expectThrow, NET, TUSD, TEUR, world, fundPaymaster } from './helpers.js';

test('fees: protocol and marketplace rules, exact for large amounts', () => {
  assert.equal(protocolFee(1), 1);
  assert.equal(protocolFee(999), 1);
  assert.equal(protocolFee(10_000), 10);
  assert.equal(marketplaceFee(1), 1);
  assert.equal(marketplaceFee(1000), 30);
  assert.equal(marketplaceFee(0), 0);
  const big = Number.MAX_SAFE_INTEGER;
  assert.equal(BigInt(marketplaceFee(big)), (BigInt(big) * 300n) / 10_000n);
  assert.equal(mulDivFloor(big, 10_000, 10_000), big);
  expectThrow(() => protocolFee(-1), 'UEP_AMOUNT');
  expectThrow(() => protocolFee(1.5), 'UEP_AMOUNT');
});

test('fees: treasury split is 40/25/20/15 and always sums exactly', () => {
  const parts = TREASURY_SPLIT.map((p) => ({ key: p.key, bps: p.bps }));
  assert.deepEqual(splitBps(100, parts), { operations: 40, riskReserve: 25, development: 20, distributable: 15 });
  for (let t = 0; t < 500; t++) {
    const out = splitBps(t, parts);
    assert.equal(Object.values(out).reduce((a, b) => a + b, 0), t);
  }
  expectThrow(() => splitBps(10, [{ key: 'a', bps: 5000 }]), 'UEP_SPLIT_BPS');
});

test('PoC P14: canonical encoding has no separator ambiguity', () => {
  const a = canonicalJson({ a: 'x|b:y', c: 'z' });
  const b = canonicalJson({ a: 'x', b: 'y', c: 'z' });
  assert.notEqual(a, b);
  assert.equal(canonicalJson({ b: 1, a: 2 }), canonicalJson({ a: 2, b: 1 }));
  expectThrow(() => canonicalJson({ a: 1.5 }), 'CANON_NUMBER');
  expectThrow(() => canonicalJson({ a: undefined }), 'CANON_UNDEFINED');
  expectThrow(() => canonicalJson({ a: Buffer.from('x') }), 'CANON_TYPE');
});

test('hashlock: weak preimages refused, domain separated by network and nonce', () => {
  expectThrow(() => swapHashlock('short', 1, NET), 'SWAP_PREIMAGE_WEAK');
  const h = swapHashlock('delivery-key-9921', 1, NET);
  assert.notEqual(h, swapHashlock('delivery-key-9921', 2, NET));
  assert.notEqual(h, swapHashlock('delivery-key-9921', 1, 'other-net'));
});

test('merkle: RFC 9162 inclusion proofs for every size and index', () => {
  for (let n = 1; n <= 40; n++) {
    const leaves = Array.from({ length: n }, (_, i) => leafHash(i, 4, Buffer.from([i, i, i, i])));
    const root = merkleRoot(leaves);
    for (let i = 0; i < n; i++) {
      const path = merklePath(leaves, i);
      assert.ok(verifyMerklePath(leaves[i], i, n, path, root), `n=${n} i=${i}`);
      if (n > 1) {
        // Wrong index, wrong leaf, truncated path and extended path all fail.
        assert.ok(!verifyMerklePath(leaves[i], (i + 1) % n, n, path, root));
        assert.ok(!verifyMerklePath(leaves[(i + 1) % n], i, n, path, root));
        assert.ok(!verifyMerklePath(leaves[i], i, n, path.slice(1), root));
        assert.ok(!verifyMerklePath(leaves[i], i, n, [...path, sha256(Buffer.from('x'))], root));
      }
      // NOTE: an inclusion proof does not bind the tree size to the root. The size must be
      // committed alongside the root, as the relay does (leafCount is signed and checked
      // against contentLen), so a verifier never chooses it.
      assert.ok(!verifyMerklePath(leaves[i], i, 0, path, root));
    }
  }
});

test('merkle: an odd node is not duplicated (no CVE-2012-2459 style ambiguity)', () => {
  const l = [0, 1, 2].map((i) => leafHash(i, 1, Buffer.from([i])));
  assert.notDeepEqual(merkleRoot(l), merkleRoot([...l, l[2]]));
});

test('registry: key squatting, forged proof of possession and duplicates are refused', () => {
  const reg = new KeyRegistry(NET);
  const alice = createIdentity('alice');
  const mallory = createIdentity('mallory');
  // Mallory tries to register Alice's id with her own key.
  expectThrow(() => reg.register(alice.id, publicKeyDer(mallory.publicKey), sign(mallory, 'x')), 'KEY_ID_MISMATCH');
  // Correct key, forged PoP.
  expectThrow(() => reg.register(alice.id, publicKeyDer(alice.publicKey), sign(mallory, 'x')), 'KEY_POP_INVALID');
  reg.registerLocal(alice);
  expectThrow(() => reg.registerLocal(alice), 'KEY_ALREADY_REGISTERED');
  // Treasury ids cannot be claimed as identities.
  expectThrow(() => reg.register('uep-treasury', publicKeyDer(alice.publicKey), sign(alice, 'x')), 'KEY_RESERVED_ID');
});

test('signed messages: tamper, wrong domain, wrong network, unknown signer, detached body', () => {
  const reg = new KeyRegistry(NET);
  const a = createIdentity('a');
  reg.registerLocal(a);
  const msg = signMessage(a, NET, 'D1', { x: 1 });
  assert.deepEqual(verifyMessage(reg, msg, 'D1'), { x: 1 });
  expectThrow(() => verifyMessage(reg, { ...msg, body: { x: 2 } }, 'D1'), 'SIG_INVALID');
  expectThrow(() => verifyMessage(reg, msg, 'D2'), 'SIG_DOMAIN');
  expectThrow(() => verifyMessage(reg, { ...msg, networkId: 'other' }, 'D1'), 'SIG_NETWORK');
  const stranger = createIdentity('s');
  expectThrow(() => verifyMessage(reg, signMessage(stranger, NET, 'D1', { x: 1 }), 'D1'), 'KEY_UNKNOWN');
  const body = verifyMessage(reg, msg, 'D1');
  body.x = 99;
  assert.equal(msg.body.x, 1, 'returned body is a detached copy');
});

test('clock: regression is refused', () => {
  const c = new MonotonicClock();
  c.check(10);
  c.check(10);
  expectThrow(() => c.check(9), 'CLOCK_REGRESSION');
  expectThrow(() => c.check(-1), 'CLOCK_INVALID');
});

test('PoC P12/P10/P11 ledger: mint needs the faucet key, ids are validated, supply is bounded', () => {
  const w = world();
  const u = w.actor('u');
  // Unsigned / foreign-signed mint
  const rogue = createIdentity('rogue');
  w.registry.registerLocal(rogue);
  expectThrow(() => w.book.mint(signMessage(rogue, NET, MINT_DOMAIN, { asset: TUSD, to: u.id, amount: 5, nonce: 1 })), 'UEP_FAUCET_AUTH');
  w.mint(u.id, TUSD, 100);
  // Replay of the same mint nonce
  const m = signMessage(w.faucet, NET, MINT_DOMAIN, { asset: TUSD, to: u.id, amount: 5, nonce: 777 });
  w.book.mint(m);
  expectThrow(() => w.book.mint(m), 'UEP_FAUCET_REPLAY');
  // P10: poisoned ids cannot be created
  expectThrow(() => w.mint(u.id, 'x|uep-test/tusd', 5), 'UEP_ID:asset');
  expectThrow(() => w.mint('evil|id', TUSD, 5), 'UEP_ID');
  w.book.assertConserved(TUSD);
  // P11: overflow of supply is refused and leaves state untouched
  w.mint(u.id, TEUR, Number.MAX_SAFE_INTEGER - 10);
  expectThrow(() => w.mint(u.id, TEUR, 11), 'UEP_OVERFLOW');
  w.book.assertConserved(TEUR);
  w.checkInvariants();
});

test('ledger: ports are single-use, holds are module-scoped, payouts must equal the hold, atomic rolls back', () => {
  const reg = new KeyRegistry(NET);
  const faucet = createIdentity('f');
  reg.registerLocal(faucet);
  const book = new BalanceBook(reg, faucet.id);
  const a = book.port('mod-a');
  const b = book.port('mod-b');
  expectThrow(() => book.port('mod-a'), 'UEP_PORT_ALREADY_ISSUED');
  book.mint(signMessage(faucet, NET, MINT_DOMAIN, { asset: TUSD, to: 'user1', amount: 100, nonce: 1 }));
  a.openHold('h1', 'user1', TUSD, 60);
  expectThrow(() => b.releaseHold('h1', [{ to: 'thief', amount: 60 }]), 'UEP_HOLD_UNKNOWN');
  expectThrow(() => a.releaseHold('h1', [{ to: 'x', amount: 59 }]), 'UEP_PAYOUT_SUM');
  expectThrow(() => a.releaseHold('h1', [{ to: 'x', amount: 61 }]), 'UEP_PAYOUT_SUM');
  // atomic rollback
  expectThrow(
    () =>
      a.atomic(() => {
        a.openHold('h2', 'user1', TUSD, 30);
        a.openHold('h3', 'user1', TUSD, 30); // only 40 free -> fails
      }),
    'UEP_INSUFFICIENT',
  );
  assert.equal(a.free('user1', TUSD), 40);
  assert.equal(a.holdInfo('h2'), undefined);
  a.releaseHold('h1', [{ to: 'x', amount: 60 }]);
  expectThrow(() => a.refundHold('h1'), 'UEP_HOLD_CLOSED');
  book.assertAllConserved();
});

test('ledger: treasury accounts cannot be spent by other modules', () => {
  const reg = new KeyRegistry(NET);
  const faucet = createIdentity('f');
  reg.registerLocal(faucet);
  const book = new BalanceBook(reg, faucet.id);
  book.reserveAccount('uep-treasury', 'treasury');
  const evil = book.port('evil');
  book.mint(signMessage(faucet, NET, MINT_DOMAIN, { asset: TUSD, to: 'uep-treasury', amount: 100, nonce: 1 }));
  expectThrow(() => evil.moveFree('uep-treasury', 'evil-acct', TUSD, 50), 'UEP_ACCOUNT_RESERVED');
  expectThrow(() => evil.moveFree('a', 'a', TUSD, 1), 'UEP_SELF_TRANSFER');
});

test('treasury: buckets are copies, credits need real backing, paymaster needs admin signature and cap', () => {
  const w = world();
  // P12: external mutation of a returned bucket does nothing
  const snap = w.treasury.buckets(TUSD);
  snap.distributable = 1e9;
  assert.equal(w.treasury.buckets(TUSD).distributable, 0);
  // Credits without funds in the treasury account are refused
  expectThrow(() => w.treasury.collectMarketplaceFee(TUSD, 10), 'TREASURY_UNBACKED_CREDIT');
  expectThrow(() => w.treasury.collectTransfer(TUSD, 10), 'TREASURY_UNBACKED_CREDIT');
  // Funding the paymaster without distributable funds, or with a non-admin signature, fails
  expectThrow(() => fundPaymaster(w, TUSD, 5), 'TREASURY_PAYMASTER_UNFUNDED');
  const rogue = w.actor('rogue');
  expectThrow(
    () => w.treasury.fundPaymaster(signMessage(rogue, NET, 'UEP-TREASURY-FUND-PAYMASTER-v1', { asset: TUSD, amount: 1, nonce: 1 })),
    'TREASURY_ADMIN_AUTH',
  );
  expectThrow(() => w.treasury.spendPaymaster({ kind: 'paymaster-cap' }, TUSD, rogue.id, 1), 'TREASURY_CAP_INVALID');
  expectThrow(() => w.treasury.issuePaymasterCap(), 'TREASURY_CAP_ALREADY_ISSUED');
  // Backed credit works and splits 40/25/20/15
  w.mint('uep-treasury', TUSD, 100);
  w.treasury.collectMarketplaceFee(TUSD, 100);
  assert.deepEqual(w.treasury.buckets(TUSD), { operations: 40, riskReserve: 25, development: 20, distributable: 15, paymaster: 0 });
  // The same funds cannot be credited twice
  expectThrow(() => w.treasury.collectMarketplaceFee(TUSD, 1), 'TREASURY_UNBACKED_CREDIT');
  w.checkInvariants();
});
