import assert from 'node:assert/strict';
import { createIdentity, swapHashlock, type Identity } from '../src/uep/crypto.js';
import { MINT_DOMAIN, BalanceBook } from '../src/uep/ledger.js';
import { KeyRegistry, signMessage, type Signed } from '../src/uep/registry.js';
import { SettlementIndex } from '../src/uep/settlement-index.js';
import { Treasury, FUND_PAYMASTER_DOMAIN } from '../src/uep/treasury.js';
import { PROTOCOL_TREASURY } from '../src/uep/ids.js';
import {
  SwapCategory,
  SWAP_ACCEPT_DOMAIN,
  SWAP_INTENT_DOMAIN,
  swapIntentId,
  type SwapIntentBody,
  type SwapAcceptBody,
} from '../src/category/swap.js';
import {
  RelayCategory,
  RELAY_COMMIT_DOMAIN,
  RELAY_OFFER_DOMAIN,
  RELAY_KEY_DOMAIN,
  RELAY_CONFIRM_DOMAIN,
  RELAY_FRAUD_DOMAIN,
  prepareBlob,
  newProviderKey,
  relayOrderId,
  proofDigest,
  type RelayOfferBody,
  type RelayCommitBody,
  type FraudProof,
  type PreparedBlob,
} from '../src/category/relay.js';
import {
  DisputeCategory,
  DISPUTE_OPEN_DOMAIN,
  DISPUTE_VERDICT_DOMAIN,
  DEFAULT_DISPUTE_CONFIG,
  verdictKindFor,
  type DisputeConfig,
  type OpenDisputeBody,
  type VerdictBody,
} from '../src/category/dispute.js';
import { DripController, DRIP_CLAIM_DOMAIN, DEFAULT_DRIP_CONFIG, type DripClaimBody, type DripConfig } from '../src/category/drip.js';
import { MARKETPLACE_TREASURY } from '../src/uep/ids.js';

export const NET = 'uep-testnet';
export const TUSD = 'uep-test/tusd';
export const TEUR = 'uep-test/teur';

export function world(opts: { dispute?: Partial<DisputeConfig>; drip?: Partial<DripConfig>; arbiterCount?: number; quorum?: number } = {}) {
  const registry = new KeyRegistry(NET);
  const faucet = createIdentity('faucet');
  const admin = createIdentity('admin');
  registry.registerLocal(faucet);
  registry.registerLocal(admin);

  const book = new BalanceBook(registry, faucet.id);
  book.reserveAccount(PROTOCOL_TREASURY, 'protocol-governance');
  const treasury = new Treasury(book, registry, admin.id);
  const index = new SettlementIndex();
  const swap = new SwapCategory(book, treasury, registry, index, NET);
  const relay = new RelayCategory(book, treasury, registry, index, NET);

  const arbiters: Identity[] = [];
  for (let i = 0; i < (opts.arbiterCount ?? 3); i++) {
    const a = createIdentity(`arbiter-${i}`);
    registry.registerLocal(a);
    arbiters.push(a);
  }
  const cfg: DisputeConfig = { ...DEFAULT_DISPUTE_CONFIG, ...opts.dispute };
  const disputes = new DisputeCategory(book, treasury, registry, arbiters.map((a) => a.id), opts.quorum ?? 2, cfg);
  disputes.attach(swap, swap.issueDisputeCap());
  disputes.attach(relay, relay.issueDisputeCap());
  const paymasterCap = treasury.issuePaymasterCap();
  const drip = new DripController(treasury, paymasterCap, index, registry, { ...DEFAULT_DRIP_CONFIG, ...opts.drip });

  let mintNonce = 0;
  let nonce = 1000;
  const w = {
    registry, book, treasury, index, swap, relay, disputes, drip, arbiters, faucet, admin, cfg,
    nextNonce: () => nonce++,
    actor(label: string): Identity {
      const i = createIdentity(label);
      registry.registerLocal(i);
      return i;
    },
    mint(to: string, asset: string, amount: number): void {
      book.mint(signMessage(faucet, NET, MINT_DOMAIN, { asset, to, amount, nonce: mintNonce++ }));
    },
    checkInvariants(): void {
      book.assertAllConserved();
      treasury.assertBacked(TUSD);
      treasury.assertBacked(TEUR);
    },
  };
  return w;
}
export type World = ReturnType<typeof world>;

// ----- swap helpers --------------------------------------------------------------

export const PREIMAGE = 'delivery-key-9921';

export function swapIntent(buyer: Identity, maker: Identity, over: Partial<SwapIntentBody> = {}, now = 1): SwapIntentBody {
  return {
    version: 1,
    category: 'uep.service.swap.v1',
    networkId: NET,
    buyerId: buyer.id,
    marketMakerId: maker.id,
    fromAsset: TUSD,
    fromAmount: 1000,
    toAsset: TEUR,
    toAmount: 900,
    hashlock: swapHashlock(PREIMAGE, 1, NET),
    deadline: now + 3600,
    orderNonce: 1,
    ...over,
  };
}

export function openSwap(w: World, buyer: Identity, maker: Identity, over: Partial<SwapIntentBody> = {}, now = 1) {
  const intent = swapIntent(buyer, maker, over, now);
  const offer = signMessage(buyer, NET, SWAP_INTENT_DOMAIN, intent);
  const accept = signMessage<SwapAcceptBody>(maker, NET, SWAP_ACCEPT_DOMAIN, { intentId: swapIntentId(intent) });
  return { intent, intentId: swapIntentId(intent), order: w.swap.open(offer, accept, now), offer, accept };
}

// ----- relay helpers -------------------------------------------------------------

export interface RelayFixture {
  buyer: Identity;
  provider: Identity;
  recipient: Identity;
  offer: RelayOfferBody;
  orderId: string;
  k: Buffer;
  content: Buffer;
  blob: PreparedBlob;
}

export function relayFixture(
  buyer: Identity,
  provider: Identity,
  recipient: Identity,
  over: Partial<RelayOfferBody> = {},
  contentLen = 3000,
  tamper?: (wrapped: Buffer) => void,
  now = 1,
): RelayFixture {
  const offer: RelayOfferBody = {
    version: 1,
    category: 'uep.service.relay.v1',
    networkId: NET,
    buyerId: buyer.id,
    providerId: provider.id,
    recipientId: recipient.id,
    asset: TUSD,
    price: 500,
    minBond: 20,
    keyDeadline: now + 3600,
    fraudWindowSeconds: 600,
    nonce: 7,
    ...over,
  };
  const orderId = relayOrderId(offer);
  const content = Buffer.alloc(contentLen);
  for (let i = 0; i < contentLen; i++) content[i] = (i * 31 + 7) & 0xff;
  const k = newProviderKey();
  const blob = prepareBlob(content, k, NET, orderId, tamper);
  return { buyer, provider, recipient, offer, orderId, k, content, blob };
}

export function openRelay(w: World, f: RelayFixture, bond = 20, now = 1) {
  const offerMsg = signMessage(f.buyer, NET, RELAY_OFFER_DOMAIN, f.offer);
  const commit: RelayCommitBody = { orderId: f.orderId, ...f.blob.commitment, bond };
  const commitMsg = signMessage(f.provider, NET, RELAY_COMMIT_DOMAIN, commit);
  return w.relay.open(offerMsg, commitMsg, now);
}

export const publishKeyMsg = (f: RelayFixture, k: Buffer = f.k, by: Identity = f.provider) =>
  signMessage(by, NET, RELAY_KEY_DOMAIN, { orderId: f.orderId, k: k.toString('hex') });

export const confirmMsg = (f: RelayFixture, by: Identity = f.recipient, chunkRoot = f.blob.commitment.chunkRoot) =>
  signMessage(by, NET, RELAY_CONFIRM_DOMAIN, { orderId: f.orderId, chunkRoot });

export const fraudMsg = (f: RelayFixture, proof: FraudProof, by: Identity) =>
  signMessage(by, NET, RELAY_FRAUD_DOMAIN, { orderId: f.orderId, proofDigest: proofDigest(proof) });

// ----- dispute helpers -----------------------------------------------------------

export function openDisputeMsg(who: Identity, category: 'swap' | 'relay', orderId: string, bondAsset: string, bondAmount: number, nonce: number) {
  const body: OpenDisputeBody = { category, orderId, bondAsset, bondAmount, nonce };
  return signMessage(who, NET, DISPUTE_OPEN_DOMAIN, body);
}

export function verdictMsgs(
  signers: Identity[],
  disputeId: string,
  orderId: string,
  category: 'swap' | 'relay',
  releaseBps: number,
  frivolous = false,
) {
  const body: VerdictBody = { disputeId, orderId, category, kind: verdictKindFor(releaseBps), releaseBps, frivolous };
  return signers.map((s) => signMessage(s, NET, DISPUTE_VERDICT_DOMAIN, body));
}

// ----- treasury / drip helpers -------------------------------------------------------

export function fundPaymaster(w: World, asset: string, amount: number) {
  w.treasury.fundPaymaster(signMessage(w.admin, NET, FUND_PAYMASTER_DOMAIN, { asset, amount, nonce: w.nextNonce() }));
}

export function dripClaim(w: World, node: Identity, orderId: string, asset: string, amount: number, now: number) {
  const work = w.index.get(orderId);
  const body: DripClaimBody = {
    nodeId: node.id,
    asset,
    amount,
    orderId,
    receiptHash: work?.receiptHash ?? '0'.repeat(64),
    nonce: w.nextNonce(),
  };
  return signMessage(node, NET, DRIP_CLAIM_DOMAIN, body);
}

export function expectThrow(fn: () => unknown, code: string | RegExp): void {
  assert.throws(fn, (e: unknown) => {
    const msg = (e as Error).message;
    return typeof code === 'string' ? msg.includes(code) : code.test(msg);
  });
}

export { assert, MARKETPLACE_TREASURY, PROTOCOL_TREASURY };
export type { Signed };
