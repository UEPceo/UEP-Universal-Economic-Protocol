import { test } from 'node:test';
import { swapHashlock } from '../src/uep/crypto.js';
import { signMessage } from '../src/uep/registry.js';
import { SWAP_ACCEPT_DOMAIN, SWAP_INTENT_DOMAIN, swapIntentId } from '../src/category/swap.js';
import {
  assert, expectThrow, NET, TUSD, TEUR, PREIMAGE, PROTOCOL_TREASURY, MARKETPLACE_TREASURY,
  world, swapIntent, openSwap,
} from './helpers.js';

function funded() {
  const w = world();
  const alice = w.actor('alice');
  const bob = w.actor('bob');
  w.mint(alice.id, TUSD, 1000);
  w.mint(bob.id, TEUR, 900);
  return { w, alice, bob };
}

test('swap: happy path settles both legs, charges fees once, conserves value', () => {
  const { w, alice, bob } = funded();
  const { intentId } = openSwap(w, alice, bob);
  assert.equal(w.book.lockedOf(alice.id, TUSD), 1000);
  assert.equal(w.book.lockedOf(bob.id, TEUR), 900);
  const s = w.swap.settle(intentId, PREIMAGE, 5);
  assert.equal(s.state, 'ATOMICALLY_SETTLED');
  // leg 1: 1000 TUSD -> bob minus 1 protocol fee
  assert.equal(w.book.free(bob.id, TUSD), 999);
  assert.equal(w.book.free(PROTOCOL_TREASURY, TUSD), 1);
  // leg 2: 900 TEUR -> alice minus 1 protocol fee and 27 marketplace fee
  assert.equal(w.book.free(alice.id, TEUR), 872);
  assert.equal(w.book.free(PROTOCOL_TREASURY, TEUR), 1);
  assert.equal(w.book.free(MARKETPLACE_TREASURY, TEUR), 27);
  assert.deepEqual(w.treasury.buckets(TEUR), { operations: 11, riskReserve: 7, development: 5, distributable: 4, paymaster: 0 });
  assert.equal(w.index.get(intentId)?.feeCollected, 27);
  w.checkInvariants();
  expectThrow(() => w.swap.settle(intentId, PREIMAGE, 6), 'SWAP_ALREADY_SETTLED');
});

test('swap: wrong preimage, expired intent and weak preimage are refused', () => {
  const { w, alice, bob } = funded();
  const { intentId } = openSwap(w, alice, bob);
  expectThrow(() => w.swap.settle(intentId, 'wrong-preimage-123456', 2), 'SWAP_HASHLOCK_MISMATCH');
  expectThrow(() => w.swap.settle(intentId, 'x', 2), 'SWAP_PREIMAGE_WEAK');
  expectThrow(() => w.swap.settle(intentId, PREIMAGE, 3602), 'SWAP_INTENT_EXPIRED');
  w.checkInvariants();
});

test('swap: expiry refunds 100% of both legs and charges no fee', () => {
  const { w, alice, bob } = funded();
  const { intentId } = openSwap(w, alice, bob);
  expectThrow(() => w.swap.expire(intentId, 100), 'SWAP_NOT_EXPIRED');
  const e = w.swap.expire(intentId, 3602);
  assert.equal(e.state, 'EXPIRED_REFUNDED');
  assert.equal(w.book.free(alice.id, TUSD), 1000);
  assert.equal(w.book.free(bob.id, TEUR), 900);
  assert.equal(w.book.free(PROTOCOL_TREASURY, TUSD), 0);
  w.checkInvariants();
});

test('swap: signatures are verified, not assumed (forged buyer, forged maker, tampered body)', () => {
  const { w, alice, bob } = funded();
  const mallory = w.actor('mallory');
  const intent = swapIntent(alice, bob);
  const id = swapIntentId(intent);
  const goodAccept = signMessage(bob, NET, SWAP_ACCEPT_DOMAIN, { intentId: id });
  // Mallory signs an intent that names Alice as the buyer
  expectThrow(() => w.swap.open(signMessage(mallory, NET, SWAP_INTENT_DOMAIN, intent), goodAccept, 1), 'SWAP_BAD_SIGNATURE');
  // Mallory accepts on Bob's behalf
  const offer = signMessage(alice, NET, SWAP_INTENT_DOMAIN, intent);
  expectThrow(() => w.swap.open(offer, signMessage(mallory, NET, SWAP_ACCEPT_DOMAIN, { intentId: id }), 1), 'SWAP_BAD_SIGNATURE');
  // Body edited after signing
  expectThrow(() => w.swap.open({ ...offer, body: { ...offer.body, toAmount: 1 } }, goodAccept, 1), 'SIG_INVALID');
  // Acceptance of a different intent
  const other = swapIntentId(swapIntent(alice, bob, { toAmount: 800 }));
  expectThrow(() => w.swap.open(offer, signMessage(bob, NET, SWAP_ACCEPT_DOMAIN, { intentId: other }), 1), 'SWAP_INTENT_MISMATCH');
  // Nothing was locked by any failed attempt
  assert.equal(w.book.lockedOf(alice.id, TUSD), 0);
  assert.equal(w.book.lockedOf(bob.id, TEUR), 0);
  w.checkInvariants();
});

test('PoC P5: a failed second leg rolls back the first hold and does not burn the nonce', () => {
  const w = world();
  const alice = w.actor('alice');
  const bob = w.actor('bob');
  w.mint(alice.id, TUSD, 1000); // bob has nothing yet
  expectThrow(() => openSwap(w, alice, bob), 'UEP_INSUFFICIENT');
  assert.equal(w.book.free(alice.id, TUSD), 1000);
  assert.equal(w.book.lockedOf(alice.id, TUSD), 0);
  w.mint(bob.id, TEUR, 900);
  const { order } = openSwap(w, alice, bob, {}, 2); // same nonce, now succeeds
  assert.equal(order.state, 'DUAL_HOLD_LOCKED');
  w.checkInvariants();
});

test('PoC P6: amounts that cannot cover their fees are refused up front, so settle never half-fails', () => {
  const { w, alice, bob } = funded();
  expectThrow(() => openSwap(w, alice, bob, { toAmount: 1 }), 'SWAP_AMOUNT_TOO_SMALL');
  expectThrow(() => openSwap(w, alice, bob, { toAmount: 2 }), 'SWAP_AMOUNT_TOO_SMALL');
  expectThrow(() => openSwap(w, alice, bob, { fromAmount: 1 }), 'SWAP_AMOUNT_TOO_SMALL');
  // Smallest viable: 3 units on the service leg (1 protocol + 1 marketplace + 1 net)
  const { intentId } = openSwap(w, alice, bob, { toAmount: 3 });
  w.swap.settle(intentId, PREIMAGE, 2);
  assert.equal(w.book.free(alice.id, TEUR), 1);
  w.checkInvariants();
});

test('swap: nonce replay, duplicate intents and intent validation', () => {
  const { w, alice, bob } = funded();
  const first = openSwap(w, alice, bob);
  expectThrow(() => w.swap.open(first.offer, first.accept, 2), 'SWAP_NONCE_REPLAY');
  w.mint(alice.id, TUSD, 1000);
  w.mint(bob.id, TEUR, 900);
  // Same buyer nonce, different body: still a replay of the nonce
  expectThrow(() => openSwap(w, alice, bob, { toAmount: 800 }, 2), 'REPLAY');
  // A fresh nonce is fine
  openSwap(w, alice, bob, { orderNonce: 2, hashlock: swapHashlock(PREIMAGE, 2, NET) }, 2);
  expectThrow(() => openSwap(w, alice, bob, { orderNonce: 3, deadline: 1 }, 2), 'SWAP_INTENT_EXPIRED');
  expectThrow(() => openSwap(w, alice, bob, { orderNonce: 3, deadline: 2 + 8 * 24 * 3600 }, 2), 'SWAP_DEADLINE_TOO_FAR');
  expectThrow(() => openSwap(w, alice, bob, { orderNonce: 3, toAsset: TUSD }, 2), 'SWAP_ASSET_MISMATCH');
  expectThrow(() => openSwap(w, alice, bob, { orderNonce: 3, fromAmount: 1.5 }, 2), /CANON_NUMBER|UEP_INT/);
  expectThrow(() => openSwap(w, alice, bob, { orderNonce: 3, networkId: 'other-net' }, 2), 'SWAP_NETWORK');
  expectThrow(() => openSwap(w, alice, bob, { orderNonce: 3, hashlock: 'zz' }, 2), 'UEP_HEX');
  expectThrow(() => openSwap(w, alice, alice, { orderNonce: 3 }, 2), 'SWAP_PARTY');
  w.checkInvariants();
});

test('swap: clock cannot move backwards', () => {
  const { w, alice, bob } = funded();
  const { intentId } = openSwap(w, alice, bob, {}, 100);
  expectThrow(() => w.swap.settle(intentId, PREIMAGE, 50), 'CLOCK_REGRESSION');
});
