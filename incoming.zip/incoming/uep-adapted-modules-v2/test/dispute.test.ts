import { test } from 'node:test';
import { createIdentity, sha256Hex } from '../src/uep/crypto.js';
import { signMessage } from '../src/uep/registry.js';
import { DISPUTE_EVIDENCE_DOMAIN, DISPUTE_VERDICT_DOMAIN, disputeIdOf, verdictKindFor, type DisputeConfig, type VerdictBody } from '../src/category/dispute.js';
import {
  assert, expectThrow, NET, TUSD, TEUR, PROTOCOL_TREASURY, MARKETPLACE_TREASURY, PREIMAGE,
  world, openSwap, openDisputeMsg, verdictMsgs, relayFixture, openRelay, publishKeyMsg, confirmMsg,
  type World,
} from './helpers.js';

/** Swap of 1000 TUSD for 900 TEUR; alice has 50 TUSD spare for the bond; dispute opened at t=10. */
function swapCase(opts: { dispute?: Partial<DisputeConfig>; claimant?: 'alice' | 'bob' } = {}) {
  const w = world({ dispute: opts.dispute });
  const alice = w.actor('alice');
  const bob = w.actor('bob');
  w.mint(alice.id, TUSD, 1050);
  w.mint(bob.id, TEUR, 950);
  const { intentId } = openSwap(w, alice, bob);
  const claimant = opts.claimant === 'bob' ? bob : alice;
  const asset = opts.claimant === 'bob' ? TEUR : TUSD;
  const c = w.disputes.open(openDisputeMsg(claimant, 'swap', intentId, asset, 50, w.nextNonce()), 10);
  return { w, alice, bob, intentId, c, id: c.disputeId };
}

const T_RESOLVE = 3611; // just after the 3600 s evidence window opened at t=10

test('PoC P3: a buyer who wins is refunded in full and gets the bond back (no inversion)', () => {
  const { w, alice, bob, intentId, id } = swapCase();
  const res = w.disputes.resolve(id, verdictMsgs([w.arbiters[0], w.arbiters[1]], id, intentId, 'swap', 0), T_RESOLVE);
  assert.equal(res.state, 'RESOLVED');
  assert.equal(res.bondForfeited, false);
  assert.equal(w.book.free(alice.id, TUSD), 1050);
  assert.equal(w.book.free(bob.id, TEUR), 950);
  assert.equal(w.book.free(PROTOCOL_TREASURY, TUSD), 0);
  assert.equal(w.swap.get(intentId)?.state, 'DISPUTE_RESOLVED');
  assert.equal(w.disputes.adverseCount(alice.id), 0);
  w.checkInvariants();
});

test('dispute: a frivolous claim loses 80% of the bond to the respondent and 20% to the risk reserve', () => {
  const { w, alice, bob, intentId, id } = swapCase();
  const res = w.disputes.resolve(id, verdictMsgs([w.arbiters[0], w.arbiters[2]], id, intentId, 'swap', 10_000, true), T_RESOLVE);
  assert.equal(res.bondForfeited, true);
  assert.equal(w.book.free(bob.id, TUSD), 999 + 40);
  assert.equal(w.book.free(alice.id, TEUR), 872);
  assert.equal(w.book.free(alice.id, TUSD), 0);
  assert.equal(w.treasury.buckets(TUSD).riskReserve, 10);
  assert.equal(w.treasury.buckets(TEUR).riskReserve, 7);
  assert.equal(w.disputes.adverseCount(alice.id), 1);
  w.checkInvariants();
});

test('dispute: `frivolous` is only valid on a verdict entirely against the claimant; a plain loss keeps the bond', () => {
  const { w, alice, intentId, id } = swapCase();
  const two = [w.arbiters[0], w.arbiters[1]];
  expectThrow(() => w.disputes.resolve(id, verdictMsgs(two, id, intentId, 'swap', 5000, true), T_RESOLVE), 'DISPUTE_VERDICT_INVALID');
  expectThrow(() => w.disputes.resolve(id, verdictMsgs(two, id, intentId, 'swap', 0, true), T_RESOLVE), 'DISPUTE_VERDICT_INVALID');
  assert.equal(w.disputes.get(id)?.state, 'OPEN');
  const res = w.disputes.resolve(id, verdictMsgs(two, id, intentId, 'swap', 10_000, false), T_RESOLVE);
  assert.equal(res.bondForfeited, false);
  assert.equal(w.book.free(alice.id, TUSD), 50); // bond came back; the 1000 went to the swap
  w.checkInvariants();
});

test('dispute: SPLIT pays each leg proportionally, fees only on the released part, value conserved', () => {
  const { w, alice, bob, intentId, id } = swapCase();
  w.disputes.resolve(id, verdictMsgs([w.arbiters[0], w.arbiters[1]], id, intentId, 'swap', 5000), T_RESOLVE);
  assert.equal(w.book.free(bob.id, TUSD), 499);
  assert.equal(w.book.free(alice.id, TUSD), 500 + 50);
  assert.equal(w.book.free(PROTOCOL_TREASURY, TUSD), 1);
  assert.equal(w.book.free(alice.id, TEUR), 436);
  assert.equal(w.book.free(bob.id, TEUR), 450 + 50);
  assert.equal(w.book.free(MARKETPLACE_TREASURY, TEUR), 13);
  w.checkInvariants();
});

test('PoC P1: a forged quorum is rejected (outsiders, impersonation, duplicates, mismatches, bad binding)', () => {
  const { w, alice, intentId, id } = swapCase();
  const [a0, a1] = w.arbiters;
  const outsider1 = w.actor('o1');
  const outsider2 = w.actor('o2');
  // Two real signatures from keys that are not in the arbiter set
  expectThrow(() => w.disputes.resolve(id, verdictMsgs([outsider1, outsider2], id, intentId, 'swap', 0), T_RESOLVE), 'DISPUTE_ARBITER');
  // Same id as an arbiter, different key: cannot register, cannot sign
  const fake = createIdentity('fake');
  expectThrow(() => w.registry.register(a0.id, Buffer.alloc(0), Buffer.alloc(64)), /KEY_ALREADY_REGISTERED/);
  const forged = verdictMsgs([fake], id, intentId, 'swap', 0).map((m) => ({ ...m, signer: a0.id }));
  expectThrow(() => w.disputes.resolve(id, forged, T_RESOLVE), 'SIG_INVALID');
  // One arbiter signing twice is one vote
  const once = verdictMsgs([a0], id, intentId, 'swap', 0);
  expectThrow(() => w.disputes.resolve(id, [...once, ...once], T_RESOLVE), 'DISPUTE_QUORUM_NOT_MET');
  expectThrow(() => w.disputes.resolve(id, once, T_RESOLVE), 'DISPUTE_QUORUM_NOT_MET');
  // Arbiter plus outsider
  expectThrow(() => w.disputes.resolve(id, [...once, ...verdictMsgs([outsider1], id, intentId, 'swap', 0)], T_RESOLVE), 'DISPUTE_ARBITER');
  // Two arbiters disagree
  const mixed = [...verdictMsgs([a0], id, intentId, 'swap', 0), ...verdictMsgs([a1], id, intentId, 'swap', 10_000)];
  expectThrow(() => w.disputes.resolve(id, mixed, T_RESOLVE), 'DISPUTE_VERDICT_MISMATCH');
  // Verdict signed for another dispute
  expectThrow(() => w.disputes.resolve(id, verdictMsgs([a0, a1], 'dsp_other', intentId, 'swap', 0), T_RESOLVE), 'DISPUTE_VERDICT_BINDING');
  // Kind inconsistent with releaseBps
  const badKind = [a0, a1].map((s) =>
    signMessage<VerdictBody>(s, NET, DISPUTE_VERDICT_DOMAIN, { disputeId: id, orderId: intentId, category: 'swap', kind: 'RELEASE', releaseBps: 0, frivolous: false }),
  );
  expectThrow(() => w.disputes.resolve(id, badKind, T_RESOLVE), 'DISPUTE_VERDICT_INVALID');
  // Nothing moved
  assert.equal(w.disputes.get(id)?.state, 'OPEN');
  assert.equal(w.book.lockedOf(alice.id, TUSD), 1050);
  w.checkInvariants();
  // The honest quorum still works afterwards
  w.disputes.resolve(id, verdictMsgs([a0, a1], id, intentId, 'swap', 0), T_RESOLVE);
});

test('dispute: an arbiter who is a party to the order cannot sign', () => {
  const w = world();
  const bob = w.actor('bob');
  const party = w.arbiters[0];
  w.mint(party.id, TUSD, 1000);
  w.mint(bob.id, TEUR, 950);
  const { intentId } = openSwap(w, party, bob);
  const c = w.disputes.open(openDisputeMsg(bob, 'swap', intentId, TEUR, 50, 1), 10).disputeId;
  expectThrow(
    () => w.disputes.resolve(c, verdictMsgs([w.arbiters[0], w.arbiters[1]], c, intentId, 'swap', 0), T_RESOLVE),
    'DISPUTE_ARBITER_CONFLICT',
  );
  // Two arbiters who are not parties can still resolve it
  w.disputes.resolve(c, verdictMsgs([w.arbiters[1], w.arbiters[2]], c, intentId, 'swap', 0), T_RESOLVE);
  w.checkInvariants();
});

test('PoC P2: a refused open never leaks a bond and never freezes the order', () => {
  const w = world();
  const alice = w.actor('alice');
  const bob = w.actor('bob');
  const stranger = w.actor('stranger');
  w.mint(alice.id, TUSD, 1050);
  w.mint(bob.id, TEUR, 900);
  w.mint(stranger.id, TUSD, 500);
  const { intentId } = openSwap(w, alice, bob);
  const open = (who: typeof alice, orderId: string, asset: string, bond: number, n: number) =>
    w.disputes.open(openDisputeMsg(who, 'swap', orderId, asset, bond, n), 10);
  expectThrow(() => open(stranger, intentId, TUSD, 50, 1), 'DISPUTE_NOT_PARTY');
  expectThrow(() => open(alice, 'swp_unknown', TUSD, 50, 2), 'DISPUTE_ORDER_UNKNOWN');
  expectThrow(() => open(alice, intentId, TUSD, 49, 3), 'DISPUTE_BOND_TOO_LOW');
  expectThrow(() => open(alice, intentId, 'uep-test/zzz', 50, 4), 'DISPUTE_BOND_ASSET');
  expectThrow(() => open(alice, intentId, TUSD, 60, 5), 'UEP_INSUFFICIENT'); // only 50 spare
  assert.equal(w.book.lockedOf(alice.id, TUSD), 1000);
  assert.equal(w.book.lockedOf(stranger.id, TUSD), 0);
  assert.equal(w.swap.escrowView(intentId)?.frozen, false);
  // The order is still live: it can settle normally
  w.checkInvariants();
  w.swap.settle(intentId, PREIMAGE, 20);
});

test('dispute: one case per order; a second open, even by the counterparty, is refused', () => {
  const { w, bob, intentId } = swapCase();
  w.mint(bob.id, TEUR, 50);
  expectThrow(() => w.disputes.open(openDisputeMsg(bob, 'swap', intentId, TEUR, 50, w.nextNonce()), 11), 'DISPUTE_ALREADY_EXISTS');
  assert.equal(w.book.lockedOf(bob.id, TEUR), 900);
  w.checkInvariants();
});

test('dispute: replayed open message and settled orders are refused', () => {
  const w = world();
  const alice = w.actor('alice');
  const bob = w.actor('bob');
  w.mint(alice.id, TUSD, 1050);
  w.mint(bob.id, TEUR, 900);
  const { intentId } = openSwap(w, alice, bob);
  w.swap.settle(intentId, PREIMAGE, 5);
  expectThrow(() => w.disputes.open(openDisputeMsg(alice, 'swap', intentId, TUSD, 50, 1), 6), 'DISPUTE_ORDER_CLOSED');
});

test('PoC P4: an order frozen by a dispute cannot settle or expire, and there is always a way out', () => {
  const { w, alice, bob, intentId, id } = swapCase();
  expectThrow(() => w.swap.settle(intentId, PREIMAGE, 20), 'SWAP_FROZEN');
  expectThrow(() => w.swap.expire(intentId, 3700), 'SWAP_FROZEN');
  expectThrow(() => w.disputes.resolve(id, verdictMsgs([w.arbiters[0], w.arbiters[1]], id, intentId, 'swap', 0), 100), 'DISPUTE_EVIDENCE_OPEN');
  expectThrow(() => w.disputes.timeout(id, T_RESOLVE), 'DISPUTE_NOT_TIMED_OUT');
  const late = 10 + 3600 + 7 * 24 * 3600 + 1;
  expectThrow(() => w.disputes.resolve(id, verdictMsgs([w.arbiters[0], w.arbiters[1]], id, intentId, 'swap', 0), late), 'DISPUTE_RESOLUTION_EXPIRED');
  const r = w.disputes.timeout(id, late);
  assert.equal(r.state, 'TIMED_OUT');
  assert.equal(r.bondForfeited, false);
  assert.equal(w.book.free(alice.id, TUSD), 1050);
  assert.equal(w.book.free(bob.id, TEUR), 950);
  assert.equal(w.book.lockedOf(alice.id, TUSD), 0);
  assert.equal(w.swap.get(intentId)?.state, 'DISPUTE_RESOLVED');
  expectThrow(() => w.disputes.timeout(id, late + 1), 'DISPUTE_CLOSED');
  w.checkInvariants();
});

test('dispute: the timeout default can be an even split but never RELEASE', () => {
  const { w, alice, bob, id } = swapCase({ dispute: { defaultReleaseBps: 5000 } });
  w.disputes.timeout(id, 10 + 3600 + 7 * 24 * 3600 + 1);
  assert.equal(w.book.free(bob.id, TUSD), 499);
  assert.equal(w.book.free(alice.id, TEUR), 436);
  w.checkInvariants();
  expectThrow(() => world({ dispute: { defaultReleaseBps: 10_000 as unknown as 0 } }), 'DISPUTE_DEFAULT');
});

test('dispute: constructor requires registered distinct arbiters and a strict-majority quorum', () => {
  expectThrow(() => world({ quorum: 1 }), 'DISPUTE_QUORUM');
  expectThrow(() => world({ quorum: 4 }), 'DISPUTE_QUORUM');
  expectThrow(() => world({ arbiterCount: 0 }), 'DISPUTE_ARBITERS');
  const w = world({ arbiterCount: 5, quorum: 3 });
  assert.ok(w.arbiters.length === 5);
});

test('dispute: evidence from both parties, until the deadline, with digest, size and count limits', () => {
  const { w, alice, bob, id } = swapCase();
  const stranger = w.actor('stranger');
  const ev = (who: typeof alice, evidenceId: string, payload: Buffer, now: number, digest = sha256Hex(payload)) =>
    w.disputes.submitEvidence(signMessage(who, NET, DISPUTE_EVIDENCE_DOMAIN, { disputeId: id, evidenceId, digest }), payload, now);
  ev(alice, 'ev_a1', Buffer.from('claimant says X'), 20);
  // The respondent can answer (the old engine blocked this)
  ev(bob, 'ev_b1', Buffer.from('respondent says Y'), 30);
  expectThrow(() => ev(stranger, 'ev_s', Buffer.from('hi'), 31), 'DISPUTE_NOT_PARTY');
  expectThrow(() => ev(alice, 'ev_a1', Buffer.from('dup'), 32), 'DISPUTE_EVIDENCE_DUPLICATE');
  expectThrow(() => ev(alice, 'ev_a2', Buffer.from('payload'), 33, '00'.repeat(32)), 'DISPUTE_EVIDENCE_DIGEST');
  expectThrow(() => ev(alice, 'ev_a3', Buffer.alloc(0), 34), 'DISPUTE_EVIDENCE_SIZE');
  expectThrow(() => ev(alice, 'ev_a4', Buffer.alloc(64 * 1024 + 1), 35), 'DISPUTE_EVIDENCE_SIZE');
  for (let i = 0; i < 7; i++) ev(alice, `ev_x${i}`, Buffer.from(`n${i}`), 40 + i);
  expectThrow(() => ev(alice, 'ev_over', Buffer.from('one too many'), 60), 'DISPUTE_EVIDENCE_LIMIT');
  expectThrow(() => ev(bob, 'ev_late', Buffer.from('late'), 3611), 'DISPUTE_EVIDENCE_CLOSED');
  assert.equal(w.disputes.get(id)?.evidence.length, 9);
});

test('dispute: the bond scales with the value in escrow', () => {
  const w = world();
  const alice = w.actor('alice');
  const bob = w.actor('bob');
  w.mint(alice.id, TUSD, 102_000);
  w.mint(bob.id, TEUR, 90_000);
  const { intentId } = openSwap(w, alice, bob, { fromAmount: 100_000, toAmount: 90_000 });
  expectThrow(() => w.disputes.open(openDisputeMsg(alice, 'swap', intentId, TUSD, 999, 1), 10), 'DISPUTE_BOND_TOO_LOW');
  const c = w.disputes.open(openDisputeMsg(alice, 'swap', intentId, TUSD, 1000, 2), 10);
  assert.equal(c.bondAmount, 1000);
  w.checkInvariants();
});

test('dispute: the seller side can claim too; bond logic mirrors the buyer side', () => {
  // Seller wins with RELEASE -> bond back, swap completes.
  let s = swapCase({ claimant: 'bob' });
  expectThrow(() => s.w.disputes.resolve(s.id, verdictMsgs([s.w.arbiters[0], s.w.arbiters[1]], s.id, s.intentId, 'swap', 10_000, true), T_RESOLVE), 'DISPUTE_VERDICT_INVALID');
  s.w.disputes.resolve(s.id, verdictMsgs([s.w.arbiters[0], s.w.arbiters[1]], s.id, s.intentId, 'swap', 10_000), T_RESOLVE);
  assert.equal(s.w.book.free(s.bob.id, TEUR), 50);
  assert.equal(s.w.book.free(s.alice.id, TEUR), 872);
  s.w.checkInvariants();
  // Seller loses frivolously (REFUND + frivolous) -> bond to the buyer and the risk reserve.
  s = swapCase({ claimant: 'bob' });
  s.w.disputes.resolve(s.id, verdictMsgs([s.w.arbiters[0], s.w.arbiters[1]], s.id, s.intentId, 'swap', 0, true), T_RESOLVE);
  assert.equal(s.w.book.free(s.alice.id, TEUR), 40);
  assert.equal(s.w.book.free(s.alice.id, TUSD), 1050);
  assert.equal(s.w.treasury.buckets(TEUR).riskReserve, 10);
  s.w.checkInvariants();
});

// ----- relay disputes ---------------------------------------------------------------

function relayCase(keyReleased: boolean) {
  const w = world();
  const buyer = w.actor('buyer');
  const provider = w.actor('provider');
  const recipient = w.actor('recipient');
  w.mint(buyer.id, TUSD, 1000);
  w.mint(provider.id, TUSD, 100);
  w.mint(recipient.id, TUSD, 100);
  const f = relayFixture(buyer, provider, recipient);
  openRelay(w, f);
  if (keyReleased) w.relay.publishKey(publishKeyMsg(f), 5);
  return { w, buyer, provider, recipient, f };
}

test('dispute on relay: REFUND returns the price and the bond, and the frozen order cannot be settled around it', () => {
  const { w, buyer, provider, f } = relayCase(true);
  const c = w.disputes.open(openDisputeMsg(buyer, 'relay', f.orderId, TUSD, 50, 1), 20);
  expectThrow(() => w.relay.finalize(f.orderId, 700), 'RELAY_FROZEN');
  expectThrow(() => w.relay.confirm(confirmMsg(f), 701), 'RELAY_FROZEN');
  const r = w.disputes.resolve(c.disputeId, verdictMsgs([w.arbiters[0], w.arbiters[1]], c.disputeId, f.orderId, 'relay', 0), 3621);
  assert.equal(r.state, 'RESOLVED');
  assert.equal(w.book.free(buyer.id, TUSD), 1000);
  assert.equal(w.book.free(provider.id, TUSD), 100);
  assert.equal(w.relay.get(f.orderId)?.state, 'DISPUTE_RESOLVED');
  w.checkInvariants();
});

test('dispute on relay: RELEASE pays the provider minus fee; the recipient may open as buyer side', () => {
  const { w, buyer, provider, recipient, f } = relayCase(false);
  const c = w.disputes.open(openDisputeMsg(recipient, 'relay', f.orderId, TUSD, 50, 1), 20);
  assert.equal(c.claimantIsBuyerSide, true);
  assert.equal(c.respondentId, provider.id);
  w.disputes.resolve(c.disputeId, verdictMsgs([w.arbiters[1], w.arbiters[2]], c.disputeId, f.orderId, 'relay', 10_000), 3621);
  assert.equal(w.book.free(provider.id, TUSD), 100 + 485);
  assert.equal(w.book.free(MARKETPLACE_TREASURY, TUSD), 15);
  assert.equal(w.book.free(recipient.id, TUSD), 100); // bond returned, loss was not flagged frivolous
  assert.equal(w.book.free(buyer.id, TUSD), 500);
  w.checkInvariants();
});

test('dispute: ids are deterministic per (category, order)', () => {
  assert.equal(disputeIdOf('swap', 'a'), disputeIdOf('swap', 'a'));
  assert.notEqual(disputeIdOf('swap', 'a'), disputeIdOf('relay', 'a'));
  assert.equal(verdictKindFor(10_000), 'RELEASE');
  assert.equal(verdictKindFor(0), 'REFUND_BUYER');
  assert.equal(verdictKindFor(1), 'SPLIT');
});

export type { World };
