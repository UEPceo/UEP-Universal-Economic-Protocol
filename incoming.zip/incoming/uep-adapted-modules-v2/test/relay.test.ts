import { test } from 'node:test';
import { newProviderKey, prepareBlob, buildFraudProof, CHUNK, completionBps, relayOrderId, verifyChunkFraud } from '../src/category/relay.js';
import { RELAY_COMMIT_DOMAIN, RELAY_CONFIRM_DOMAIN, RELAY_OFFER_DOMAIN } from '../src/category/relay.js';
import { signMessage } from '../src/uep/registry.js';
import {
  assert, expectThrow, NET, TUSD, MARKETPLACE_TREASURY,
  world, relayFixture, openRelay, publishKeyMsg, confirmMsg, fraudMsg,
} from './helpers.js';

function setup(over = {}, contentLen = 3000, tamper?: (w: Buffer) => void) {
  const w = world();
  const buyer = w.actor('buyer');
  const provider = w.actor('provider');
  const recipient = w.actor('recipient');
  w.mint(buyer.id, TUSD, 1000);
  w.mint(provider.id, TUSD, 100);
  const f = relayFixture(buyer, provider, recipient, over, contentLen, tamper);
  return { w, buyer, provider, recipient, f };
}

test('relay: happy path, recipient confirms early, provider is paid minus fee and gets the bond back', () => {
  const { w, buyer, provider, f } = setup();
  openRelay(w, f);
  assert.equal(w.book.lockedOf(buyer.id, TUSD), 500);
  assert.equal(w.book.lockedOf(provider.id, TUSD), 20);
  assert.equal(w.relay.publishKey(publishKeyMsg(f), 10), 'KEY_RELEASED');
  const o = w.relay.confirm(confirmMsg(f), 20);
  assert.equal(o.state, 'SETTLED');
  assert.equal(w.book.free(provider.id, TUSD), 100 - 20 + 485 + 20);
  assert.equal(w.book.free(MARKETPLACE_TREASURY, TUSD), 15);
  assert.equal(w.book.free(buyer.id, TUSD), 500);
  assert.equal(w.index.get(f.orderId)?.feeCollected, 15);
  const c = w.relay.providerCounters(provider.id);
  assert.equal(c.settledCount, 1);
  assert.equal(completionBps(c), 10_000);
  w.checkInvariants();
});

test('PoC P7: the provider cannot confirm for the recipient, with or without forging the signer', () => {
  const { w, provider, recipient, f } = setup();
  openRelay(w, f);
  w.relay.publishKey(publishKeyMsg(f), 10);
  expectThrow(() => w.relay.confirm(confirmMsg(f, provider), 11), 'RELAY_NOT_RECIPIENT');
  const forged = { ...confirmMsg(f, provider), signer: recipient.id };
  expectThrow(() => w.relay.confirm(forged, 11), 'SIG_INVALID');
  assert.equal(w.relay.get(f.orderId)?.state, 'KEY_RELEASED');
  // wrong content root
  expectThrow(() => w.relay.confirm(confirmMsg(f, recipient, 'ab'.repeat(32)), 11), 'RELAY_CONFIRM_ROOT');
  w.checkInvariants();
});

test('relay: finalize is permissionless but only after the fraud window', () => {
  const { w, provider, f } = setup();
  openRelay(w, f);
  w.relay.publishKey(publishKeyMsg(f), 10); // window ends at 610
  expectThrow(() => w.relay.finalize(f.orderId, 500), 'RELAY_FRAUD_WINDOW_OPEN');
  assert.equal(w.relay.finalize(f.orderId, 611).state, 'SETTLED');
  assert.equal(w.relay.providerCounters(provider.id).settledCount, 1);
  w.checkInvariants();
});

test('relay: a proven chunk fraud refunds the buyer and slashes the bond 80/20', () => {
  const { w, buyer, provider, recipient, f } = setup({}, 3000, (wr) => {
    wr[CHUNK + 5] ^= 0xff; // corrupt chunk 1 before the provider commits to the wrapped data
  });
  openRelay(w, f);
  w.relay.publishKey(publishKeyMsg(f), 10);
  const proof = buildFraudProof(f.blob.wrapped, f.blob.leaves, 1);
  assert.equal(
    verifyChunkFraud({ ...f.blob.commitment, networkId: NET, orderId: f.orderId }, f.k, proof),
    'FRAUD_PROVEN',
  );
  assert.equal(w.relay.submitFraudProof(fraudMsg(f, proof, recipient), proof, 20), 'FRAUD_PROVEN');
  assert.equal(w.relay.get(f.orderId)?.state, 'FRAUD_PROVEN');
  assert.equal(w.book.free(buyer.id, TUSD), 1000 + 16);
  assert.equal(w.book.free(provider.id, TUSD), 100 - 20);
  assert.equal(w.treasury.buckets(TUSD).riskReserve, 4);
  assert.equal(w.relay.providerCounters(provider.id).fraudProvenCount, 1);
  expectThrow(() => w.relay.finalize(f.orderId, 700), 'RELAY_ORDER_STATE');
  expectThrow(() => w.relay.confirm(confirmMsg(f), 701), 'RELAY_ORDER_STATE');
  w.checkInvariants();
});

test('PoC P8: invalid proofs are counted per submitter and stop being accepted', () => {
  const { w, buyer, recipient, f } = setup();
  openRelay(w, f);
  w.relay.publishKey(publishKeyMsg(f), 10);
  const honest = buildFraudProof(f.blob.wrapped, f.blob.leaves, 0); // honest chunk: not fraud
  for (let i = 0; i < 3; i++) {
    assert.equal(w.relay.submitFraudProof(fraudMsg(f, honest, buyer), honest, 20 + i), 'RELAY_FRAUD_INVALID');
  }
  assert.equal(w.relay.get(f.orderId)?.invalidFraudAttempts[buyer.id], 3);
  expectThrow(() => w.relay.submitFraudProof(fraudMsg(f, honest, buyer), honest, 30), 'RELAY_FRAUD_ATTEMPTS');
  // The recipient has their own budget and the order is untouched
  assert.equal(w.relay.submitFraudProof(fraudMsg(f, honest, recipient), honest, 31), 'RELAY_FRAUD_INVALID');
  assert.equal(w.relay.get(f.orderId)?.state, 'KEY_RELEASED');
  w.checkInvariants();
});

test('relay: fraud proofs are restricted to parties, the window, a matching digest and sane sizes', () => {
  const { w, recipient, f } = setup();
  const stranger = w.actor('stranger');
  openRelay(w, f);
  w.relay.publishKey(publishKeyMsg(f), 10);
  const honest = buildFraudProof(f.blob.wrapped, f.blob.leaves, 0);
  expectThrow(() => w.relay.submitFraudProof(fraudMsg(f, honest, stranger), honest, 20), 'RELAY_NOT_PARTY');
  const other = buildFraudProof(f.blob.wrapped, f.blob.leaves, 1);
  expectThrow(() => w.relay.submitFraudProof(fraudMsg(f, other, recipient), honest, 20), 'RELAY_PROOF_DIGEST');
  const tiny = { ...honest, wrappedChunk: Buffer.alloc(10) };
  assert.equal(w.relay.submitFraudProof(fraudMsg(f, tiny, recipient), tiny, 21), 'RELAY_FRAUD_SIZE');
  expectThrow(() => w.relay.submitFraudProof(fraudMsg(f, honest, recipient), honest, 700), 'RELAY_FRAUD_WINDOW_CLOSED');
  w.checkInvariants();
});

test('relay: tampering inside the very first chunk is detected too', () => {
  const { w, recipient, f } = setup({}, 3000, (wr) => {
    wr[3] ^= 1;
  });
  openRelay(w, f);
  w.relay.publishKey(publishKeyMsg(f), 10);
  const proof = buildFraudProof(f.blob.wrapped, f.blob.leaves, 0);
  // Fraud is judged under the published key; flipping a bit in chunk 0 is a real fraud.
  assert.equal(w.relay.submitFraudProof(fraudMsg(f, proof, recipient), proof, 20), 'FRAUD_PROVEN');
});

test('relay: an inconsistent key is a service fault, refunded and not slashed', () => {
  const { w, buyer, provider, f } = setup();
  openRelay(w, f);
  const wrong = newProviderKey();
  assert.equal(w.relay.publishKey(publishKeyMsg(f, wrong), 10), 'KEY_RELEASE_FAULT');
  assert.equal(w.relay.get(f.orderId)?.state, 'KEY_RELEASE_FAULT');
  assert.equal(w.book.free(buyer.id, TUSD), 1000);
  assert.equal(w.book.free(provider.id, TUSD), 100);
  const c = w.relay.providerCounters(provider.id);
  assert.equal(c.fraudProvenCount, 0);
  assert.equal(c.expiredNoFinalCount, 1);
  w.checkInvariants();
});

test('relay: no key before the deadline refunds everyone and counts against completion', () => {
  const { w, buyer, provider, f } = setup();
  openRelay(w, f);
  expectThrow(() => w.relay.expire(f.orderId, 100), 'RELAY_NOT_EXPIRED');
  assert.equal(w.relay.expire(f.orderId, 3602).state, 'EXPIRED_REFUNDED');
  assert.equal(w.book.free(buyer.id, TUSD), 1000);
  assert.equal(w.book.free(provider.id, TUSD), 100);
  assert.equal(completionBps(w.relay.providerCounters(provider.id)), 0);
  expectThrow(() => w.relay.publishKey(publishKeyMsg(f), 3603), 'RELAY_ORDER_STATE');
  w.checkInvariants();
});

test('relay: only the provider can publish the key, and only before the deadline', () => {
  const { w, buyer, f } = setup();
  openRelay(w, f);
  expectThrow(() => w.relay.publishKey(publishKeyMsg(f, f.k, buyer), 10), 'RELAY_NOT_PROVIDER');
  expectThrow(() => w.relay.publishKey(publishKeyMsg(f), 3602), 'RELAY_DEADLINE');
});

test('PoC P9: price and bond floors, commitment shape and order binding are enforced', () => {
  const { w, buyer, provider, recipient, f } = setup();
  expectThrow(() => openRelay(w, relayFixture(buyer, provider, recipient, { price: 1, nonce: 11 })), 'RELAY_PRICE_TOO_LOW');
  expectThrow(() => openRelay(w, relayFixture(buyer, provider, recipient, { price: 0, nonce: 12 })), 'UEP_INT');
  expectThrow(() => openRelay(w, relayFixture(buyer, provider, recipient, { minBond: 5, nonce: 13 })), 'RELAY_BOND_TOO_LOW');
  expectThrow(() => openRelay(w, relayFixture(buyer, provider, recipient, { nonce: 14 }), 19), 'RELAY_BOND_TOO_LOW');
  // Commitment whose leafCount disagrees with contentLen
  const g = relayFixture(buyer, provider, recipient, { nonce: 15 });
  const offerMsg = signMessage(buyer, NET, RELAY_OFFER_DOMAIN, g.offer);
  const bad = signMessage(provider, NET, RELAY_COMMIT_DOMAIN, { orderId: g.orderId, ...g.blob.commitment, leafCount: 9, bond: 20 });
  expectThrow(() => w.relay.open(offerMsg, bad, 1), 'RELAY_COMMIT_SHAPE');
  // Commitment signed for a different order
  const wrongOrder = signMessage(provider, NET, RELAY_COMMIT_DOMAIN, { orderId: relayOrderId({ ...g.offer, nonce: 99 }), ...g.blob.commitment, bond: 20 });
  expectThrow(() => w.relay.open(offerMsg, wrongOrder, 1), 'RELAY_ORDER_MISMATCH');
  // Provider and recipient must be distinct from the other roles
  expectThrow(() => openRelay(w, relayFixture(buyer, provider, provider, { nonce: 16 })), 'RELAY_PARTY');
  // The valid one still opens, nothing leaked from the failures
  openRelay(w, f);
  assert.equal(w.book.lockedOf(buyer.id, TUSD), 500);
  w.checkInvariants();
});

test('relay: a missing bond rolls back the buyer price hold', () => {
  const w = world();
  const buyer = w.actor('buyer');
  const provider = w.actor('provider');
  const recipient = w.actor('recipient');
  w.mint(buyer.id, TUSD, 1000); // provider has no funds for the bond
  const f = relayFixture(buyer, provider, recipient);
  expectThrow(() => openRelay(w, f), 'UEP_INSUFFICIENT');
  assert.equal(w.book.free(buyer.id, TUSD), 1000);
  assert.equal(w.book.lockedOf(buyer.id, TUSD), 0);
  assert.equal(w.relay.get(f.orderId), undefined);
});

test('relay: the order record never contains the plaintext or the unpublished key', () => {
  const { w, f } = setup();
  openRelay(w, f);
  const json = JSON.stringify(w.relay.get(f.orderId));
  assert.ok(!json.includes(f.k.toString('hex')));
  w.relay.publishKey(publishKeyMsg(f), 10);
  assert.equal(w.relay.get(f.orderId)?.publishedKey, f.k.toString('hex'));
});

test('relay: single-chunk and exact-multiple contents prove and settle', () => {
  for (const len of [1, CHUNK, CHUNK + 1, 5 * CHUNK]) {
    const { w, f } = setup({ nonce: len }, len);
    openRelay(w, f);
    w.relay.publishKey(publishKeyMsg(f), 10);
    w.relay.confirm(confirmMsg(f), 11);
    w.checkInvariants();
  }
  const blob = prepareBlob(Buffer.alloc(10), newProviderKey(), NET, 'rly_x');
  assert.equal(blob.commitment.leafCount, 1);
});
