/**
 * Injective canonical encoding for anything that is hashed or signed.
 * Only strings, safe integers, booleans, null, arrays and plain objects are
 * accepted. Floats, undefined, Buffers and class instances throw. Object keys
 * are sorted. Because strings are JSON-escaped, no field value can masquerade
 * as a separator (the old `k:v|k:v` form was ambiguous).
 */

export function canonicalJson(value: unknown): string {
  if (value === null || typeof value === 'boolean') return JSON.stringify(value);
  if (typeof value === 'string') return JSON.stringify(value);
  if (typeof value === 'number') {
    if (!Number.isSafeInteger(value)) throw new Error('CANON_NUMBER');
    return String(value);
  }
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(',')}]`;
  if (typeof value === 'object') {
    const proto = Object.getPrototypeOf(value);
    if (proto !== Object.prototype && proto !== null) throw new Error('CANON_TYPE');
    const obj = value as Record<string, unknown>;
    const keys = Object.keys(obj).sort();
    const parts: string[] = [];
    for (const k of keys) {
      if (obj[k] === undefined) throw new Error('CANON_UNDEFINED');
      parts.push(`${JSON.stringify(k)}:${canonicalJson(obj[k])}`);
    }
    return `{${parts.join(',')}}`;
  }
  throw new Error('CANON_TYPE');
}
