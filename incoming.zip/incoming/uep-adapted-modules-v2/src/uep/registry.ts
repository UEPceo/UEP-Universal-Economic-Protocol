/**
 * Authentication layer. No module ever receives a private key: every action
 * that spends or locks someone's funds arrives as a `Signed<Body>` message that
 * is verified against a public key held in the registry.
 *
 *  - Account ids are derived from the public key (no squatting).
 *  - Registration needs a proof-of-possession signature.
 *  - A signature binds domain, network, signer and the canonical body.
 */

import type { KeyObject } from 'node:crypto';
import { canonicalJson } from './canonical.js';
import {
  deriveAccountId,
  parsePublicKeyDer,
  publicKeyDer,
  sign,
  verify,
  type Identity,
} from './crypto.js';
import { assertAccountId, isReservedAccount } from './ids.js';

export interface Signed<B> {
  domain: string;
  networkId: string;
  signer: string;
  body: B;
  sig: Buffer;
}

export function signedBytes(domain: string, networkId: string, signer: string, body: unknown): Buffer {
  return Buffer.from(canonicalJson([domain, networkId, signer, body]));
}

export function signMessage<B extends object>(
  identity: Identity,
  networkId: string,
  domain: string,
  body: B,
): Signed<B> {
  return {
    domain,
    networkId,
    signer: identity.id,
    body,
    sig: sign(identity, signedBytes(domain, networkId, identity.id, body)),
  };
}

const REGISTER_DOMAIN = 'UEP-KEY-REGISTER-v1';

export class KeyRegistry {
  private keys = new Map<string, KeyObject>();

  constructor(
    readonly networkId: string,
    private readonly strictDerivedIds = true,
  ) {}

  /** Register a public key with a proof-of-possession signature over (network, id, key). */
  register(id: string, publicKeyDerBytes: Buffer, popSig: Buffer): void {
    assertAccountId(id, 'registry id');
    if (isReservedAccount(id)) throw new Error('KEY_RESERVED_ID');
    if (this.keys.has(id)) throw new Error('KEY_ALREADY_REGISTERED');
    const pub = parsePublicKeyDer(publicKeyDerBytes);
    if (this.strictDerivedIds && deriveAccountId(pub) !== id) throw new Error('KEY_ID_MISMATCH');
    const msg = Buffer.from(canonicalJson([REGISTER_DOMAIN, this.networkId, id, publicKeyDerBytes.toString('hex')]));
    if (!verify(pub, msg, popSig)) throw new Error('KEY_POP_INVALID');
    this.keys.set(id, pub);
  }

  /** Composition-root / test convenience: builds the proof-of-possession from a local identity. */
  registerLocal(identity: Identity): void {
    const der = publicKeyDer(identity.publicKey);
    const msg = Buffer.from(canonicalJson([REGISTER_DOMAIN, this.networkId, identity.id, der.toString('hex')]));
    this.register(identity.id, der, sign(identity, msg));
  }

  has(id: string): boolean {
    return this.keys.has(id);
  }

  get(id: string): KeyObject {
    const k = this.keys.get(id);
    if (!k) throw new Error('KEY_UNKNOWN');
    return k;
  }
}

/** Verifies a signed message against the registry and returns a detached copy of its body. */
export function verifyMessage<B>(registry: KeyRegistry, msg: Signed<B>, domain: string): B {
  if (!msg || typeof msg !== 'object') throw new Error('SIG_MALFORMED');
  if (msg.domain !== domain) throw new Error('SIG_DOMAIN');
  if (msg.networkId !== registry.networkId) throw new Error('SIG_NETWORK');
  if (typeof msg.signer !== 'string' || !Buffer.isBuffer(msg.sig)) throw new Error('SIG_MALFORMED');
  const pub = registry.get(msg.signer);
  if (!verify(pub, signedBytes(msg.domain, msg.networkId, msg.signer, msg.body), msg.sig)) {
    throw new Error('SIG_INVALID');
  }
  // Detach: the caller keeps no live reference into state we store.
  return structuredClone(msg.body);
}

/** One-shot nonce ledger. `check` then `consume` so a failed action does not burn the nonce. */
export class ReplayGuard {
  private seen = new Set<string>();

  private key(scope: string, signer: string, nonce: string | number): string {
    return canonicalJson([scope, signer, nonce]);
  }

  check(scope: string, signer: string, nonce: string | number): void {
    if (this.seen.has(this.key(scope, signer, nonce))) throw new Error('REPLAY');
  }

  consume(scope: string, signer: string, nonce: string | number): void {
    const k = this.key(scope, signer, nonce);
    if (this.seen.has(k)) throw new Error('REPLAY');
    this.seen.add(k);
  }
}

/**
 * Time is supplied by the caller (as everywhere in this repo), so the module can
 * only refuse to go backwards. A real deployment must bind `now` to a trusted source.
 */
export class MonotonicClock {
  private last = Number.NEGATIVE_INFINITY;

  check(now: number): void {
    if (!Number.isSafeInteger(now) || now < 0) throw new Error('CLOCK_INVALID');
    if (now < this.last) throw new Error('CLOCK_REGRESSION');
    this.last = now;
  }
}
