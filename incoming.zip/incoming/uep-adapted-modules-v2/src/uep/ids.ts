/**
 * Identifier and primitive validation. Every id that reaches a map key, a hash
 * input or a signed payload passes through here first.
 * Asset ids follow the repo rule `<namespace>/<symbol>` (ADR 0001).
 */

export const MARKETPLACE_TREASURY = 'uep-treasury';
export const PROTOCOL_TREASURY = 'uep-protocol-treasury';

const ASSET_RE = /^[a-z0-9][a-z0-9-]{0,31}\/[A-Za-z0-9][A-Za-z0-9_-]{0,31}$/;
const ACCOUNT_RE = /^[A-Za-z0-9][A-Za-z0-9_.:-]{0,95}$/;
const HEX64_RE = /^[0-9a-f]{64}$/;

export function assertAssetId(v: unknown, label = 'asset'): asserts v is string {
  if (typeof v !== 'string' || !ASSET_RE.test(v)) throw new Error(`UEP_ID:${label}`);
}

export function assertAccountId(v: unknown, label = 'account'): asserts v is string {
  if (typeof v !== 'string' || !ACCOUNT_RE.test(v)) throw new Error(`UEP_ID:${label}`);
}

export function assertHex32(v: unknown, label = 'hex32'): asserts v is string {
  if (typeof v !== 'string' || !HEX64_RE.test(v)) throw new Error(`UEP_HEX:${label}`);
}

export function assertNonNegInt(v: unknown, label = 'int'): asserts v is number {
  if (typeof v !== 'number' || !Number.isSafeInteger(v) || v < 0) throw new Error(`UEP_INT:${label}`);
}

export function assertPositiveInt(v: unknown, label = 'int'): asserts v is number {
  if (typeof v !== 'number' || !Number.isSafeInteger(v) || v <= 0) throw new Error(`UEP_INT:${label}`);
}

export function isReservedAccount(id: string): boolean {
  return id === MARKETPLACE_TREASURY || id === PROTOCOL_TREASURY;
}
