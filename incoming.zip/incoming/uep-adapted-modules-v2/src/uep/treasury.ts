/**
 * Marketplace treasury accounting. Buckets receive only collected fees or explicit
 * transfers, and every credit is checked against the real balance of the treasury account.
 * Split is the published 40/25/20/15 (operations / risk reserve / development / distributable).
 * The paymaster can be funded only by an administrator-signed move out of `distributable`,
 * and spent only through a capability that is issued once. Nothing here mints.
 *
 * Buckets are private; `buckets()` returns a copy, so callers cannot edit accounting.
 */

import { assertPositiveAmount, splitBps, TREASURY_SPLIT } from './fees.js';
import { assertAssetId, assertNonNegInt, MARKETPLACE_TREASURY } from './ids.js';
import type { BalanceBook, LedgerPort } from './ledger.js';
import { ReplayGuard, verifyMessage, type KeyRegistry, type Signed } from './registry.js';

export interface Buckets {
  operations: number;
  riskReserve: number;
  development: number;
  distributable: number;
  paymaster: number;
}

export const FUND_PAYMASTER_DOMAIN = 'UEP-TREASURY-FUND-PAYMASTER-v1';

export interface FundPaymasterBody {
  asset: string;
  amount: number;
  nonce: number;
}

export interface PaymasterCap {
  readonly kind: 'paymaster-cap';
}

export class Treasury {
  private byAsset = new Map<string, Buckets>();
  private readonly ledger: LedgerPort;
  private readonly replay = new ReplayGuard();
  private paymasterCap?: PaymasterCap;
  readonly account = MARKETPLACE_TREASURY;

  constructor(
    book: BalanceBook,
    private readonly registry: KeyRegistry,
    private readonly adminId: string,
  ) {
    if (!registry.has(adminId)) throw new Error('TREASURY_ADMIN_UNREGISTERED');
    book.reserveAccount(this.account, 'treasury');
    this.ledger = book.port('treasury');
  }

  /** Copy of the buckets for an asset. Mutating it changes nothing. */
  buckets(asset: string): Buckets {
    const row = this.byAsset.get(asset);
    return row ? { ...row } : { operations: 0, riskReserve: 0, development: 0, distributable: 0, paymaster: 0 };
  }

  accounted(asset: string): number {
    const r = this.buckets(asset);
    return r.operations + r.riskReserve + r.development + r.distributable + r.paymaster;
  }

  /** Funds that sit in the treasury account but are not yet assigned to a bucket. */
  unassigned(asset: string): number {
    return this.ledger.free(this.account, asset) - this.accounted(asset);
  }

  /** Accounting can never exceed the real balance of the treasury account. */
  assertBacked(asset: string): void {
    if (this.accounted(asset) > this.ledger.free(this.account, asset)) {
      throw new Error(`TREASURY_UNBACKED:${asset}`);
    }
  }

  /**
   * Record a marketplace fee that has already been paid into the treasury account.
   * Split 40/25/20/15 with exact largest-remainder rounding.
   */
  collectMarketplaceFee(asset: string, fee: number): void {
    assertAssetId(asset);
    assertPositiveAmount(fee, 'fee');
    this.requireBacking(asset, fee);
    const parts = splitBps(fee, TREASURY_SPLIT.map((p) => ({ key: p.key, bps: p.bps })));
    const row = this.row(asset);
    row.operations += parts.operations;
    row.riskReserve += parts.riskReserve;
    row.development += parts.development;
    row.distributable += parts.distributable;
  }

  /**
   * Record a non-fee transfer already paid into the treasury account (for example a forfeited
   * dispute bond). Design choice: it is assigned to `riskReserve`, which exists to absorb abuse.
   */
  collectTransfer(asset: string, amount: number): void {
    assertAssetId(asset);
    assertPositiveAmount(amount);
    this.requireBacking(asset, amount);
    this.row(asset).riskReserve += amount;
  }

  /** Testnet policy: paymaster subsidy comes from already-collected distributable fees, admin-signed. */
  fundPaymaster(msg: Signed<FundPaymasterBody>): void {
    const b = verifyMessage(this.registry, msg, FUND_PAYMASTER_DOMAIN);
    if (msg.signer !== this.adminId) throw new Error('TREASURY_ADMIN_AUTH');
    assertAssetId(b.asset);
    assertPositiveAmount(b.amount);
    assertNonNegInt(b.nonce, 'nonce');
    this.replay.check('fund', msg.signer, b.nonce);
    const row = this.row(b.asset);
    if (row.distributable < b.amount) throw new Error('TREASURY_PAYMASTER_UNFUNDED');
    this.replay.consume('fund', msg.signer, b.nonce);
    row.distributable -= b.amount;
    row.paymaster += b.amount;
  }

  /** Issued once, to the drip controller. Whoever holds it can spend the paymaster bucket. */
  issuePaymasterCap(): PaymasterCap {
    if (this.paymasterCap) throw new Error('TREASURY_CAP_ALREADY_ISSUED');
    this.paymasterCap = Object.freeze({ kind: 'paymaster-cap' as const });
    return this.paymasterCap;
  }

  /** The ledger move runs first and throws before any bucket changes. */
  spendPaymaster(cap: PaymasterCap, asset: string, to: string, amount: number): void {
    if (cap !== this.paymasterCap) throw new Error('TREASURY_CAP_INVALID');
    assertAssetId(asset);
    assertPositiveAmount(amount);
    const row = this.row(asset);
    if (row.paymaster < amount) throw new Error('TREASURY_PAYMASTER_EMPTY');
    this.ledger.moveFree(this.account, to, asset, amount);
    row.paymaster -= amount;
  }

  private requireBacking(asset: string, amount: number): void {
    if (this.unassigned(asset) < amount) throw new Error('TREASURY_UNBACKED_CREDIT');
  }

  private row(asset: string): Buckets {
    let row = this.byAsset.get(asset);
    if (!row) {
      row = { operations: 0, riskReserve: 0, development: 0, distributable: 0, paymaster: 0 };
      this.byAsset.set(asset, row);
    }
    return row;
  }
}
