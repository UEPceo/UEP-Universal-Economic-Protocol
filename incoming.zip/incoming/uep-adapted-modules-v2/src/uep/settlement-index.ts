/**
 * Index of settled work. Only the swap and relay modules can write to it, through a writer
 * capability issued once per module name. The drip controller reads it and nothing else:
 * a node cannot declare its own work.
 */

export interface SettledWork {
  orderId: string;
  category: 'swap' | 'relay';
  providerId: string;
  asset: string;
  /** Marketplace fee actually collected for this order. */
  feeCollected: number;
  receiptHash: string;
  settledAt: number;
}

export type IndexWriter = (work: SettledWork) => void;

export class SettlementIndex {
  private rows = new Map<string, SettledWork>();
  private issued = new Set<string>();

  issueWriter(module: string): IndexWriter {
    if (this.issued.has(module)) throw new Error('INDEX_WRITER_ALREADY_ISSUED');
    this.issued.add(module);
    return (work) => {
      if (this.rows.has(work.orderId)) throw new Error('INDEX_DUPLICATE');
      this.rows.set(work.orderId, { ...work });
    };
  }

  get(orderId: string): SettledWork | undefined {
    const w = this.rows.get(orderId);
    return w ? { ...w } : undefined;
  }
}
