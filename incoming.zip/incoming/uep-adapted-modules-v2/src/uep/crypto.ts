/**
 * Cryptography used by these adapters.
 * Ed25519 is node:crypto (the testnet signature scheme).
 * Commitments here are domain-separated SHA-256. They are NOT Poseidon.
 * The public core hash is Poseidon BN254; plugging it in is a separate milestone
 * and must not be simulated by renaming SHA-256.
 */

import {
  createCipheriv,
  createHash,
  createPublicKey,
  generateKeyPairSync,
  hkdfSync,
  sign as cryptoSign,
  verify as cryptoVerify,
  type KeyObject,
} from 'node:crypto';
import { canonicalJson } from './canonical.js';
import { assertNonNegInt } from './ids.js';

export interface Identity {
  /** Key-derived account id (see deriveAccountId). */
  id: string;
  /** Free-form label for logs and tests; never part of any signed payload. */
  label: string;
  publicKey: KeyObject;
  privateKey: KeyObject;
}

export function sha256(data: Buffer | string): Buffer {
  return createHash('sha256').update(data).digest();
}

export function sha256Hex(data: Buffer | string): string {
  return sha256(data).toString('hex');
}

export function publicKeyDer(key: KeyObject): Buffer {
  return key.export({ type: 'spki', format: 'der' }) as Buffer;
}

export function parsePublicKeyDer(der: Buffer): KeyObject {
  const key = createPublicKey({ key: der, format: 'der', type: 'spki' });
  if (key.asymmetricKeyType !== 'ed25519') throw new Error('KEY_TYPE');
  return key;
}

/** Account ids commit to the public key, so an id cannot be squatted with a different key. */
export function deriveAccountId(publicKey: KeyObject): string {
  const h = sha256Hex(Buffer.concat([Buffer.from('UEP-ACCOUNT-KEY-v1\0'), publicKeyDer(publicKey)]));
  return `acct_${h.slice(0, 40)}`;
}

export function createIdentity(label = 'anon'): Identity {
  const { publicKey, privateKey } = generateKeyPairSync('ed25519');
  return { id: deriveAccountId(publicKey), label, publicKey, privateKey };
}

export function sign(identity: Identity, message: Buffer | string): Buffer {
  return cryptoSign(null, Buffer.isBuffer(message) ? message : Buffer.from(message), identity.privateKey);
}

export function verify(publicKey: KeyObject, message: Buffer | string, signature: Buffer): boolean {
  if (!Buffer.isBuffer(signature) || signature.length !== 64) return false;
  try {
    return cryptoVerify(null, Buffer.isBuffer(message) ? message : Buffer.from(message), publicKey, signature);
  } catch {
    return false;
  }
}

export const MIN_PREIMAGE_BYTES = 16;

/** Domain-separated hashlock. Explicitly SHA-256, not Poseidon. */
export function swapHashlock(preimage: string, orderNonce: number, networkId: string): string {
  assertNonNegInt(orderNonce, 'nonce');
  if (typeof preimage !== 'string' || Buffer.byteLength(preimage) < MIN_PREIMAGE_BYTES) {
    throw new Error('SWAP_PREIMAGE_WEAK');
  }
  return sha256Hex(canonicalJson(['UEP-SWAP-HASHLOCK-v1', networkId, preimage, orderNonce]));
}

export function wrapKey(k: Buffer, networkId: string, orderId: string): Buffer {
  if (k.length !== 32) throw new Error('RELAY_KEY_LENGTH');
  const info = Buffer.from(canonicalJson(['UEP-RELAY-WRAP-v5', networkId, orderId]));
  return Buffer.from(hkdfSync('sha256', k, Buffer.alloc(0), info, 32));
}

/** RFC 8439 ChaCha20 via Node: 4-byte LE block counter + 12-byte nonce. */
export function chacha20(key: Buffer, blockCounter: number, nonce: Buffer, data: Buffer): Buffer {
  if (key.length !== 32) throw new Error('RELAY_KEY_LENGTH');
  if (nonce.length !== 12) throw new Error('RELAY_NONCE');
  if (!Number.isSafeInteger(blockCounter) || blockCounter < 0 || blockCounter > 0xffffffff) {
    throw new Error('RELAY_COUNTER');
  }
  const iv = Buffer.alloc(16);
  iv.writeUInt32LE(blockCounter, 0);
  nonce.copy(iv, 4);
  const cipher = createCipheriv('chacha20', key, iv);
  return Buffer.concat([cipher.update(data), cipher.final()]);
}

export function keyCommit(orderId: string, k: Buffer): string {
  return sha256Hex(
    Buffer.concat([Buffer.from('UEP-RELAY-WRAPKEY-COMMIT-v5\0'), Buffer.from(orderId), Buffer.from([0]), k]),
  );
}

// ---------------------------------------------------------------------------
// Merkle tree, RFC 6962 / RFC 9162 shape.
// `leaves` are already leaf hashes (0x00-prefixed by leafHash). Interior nodes
// are H(0x01 || left || right). The tree splits at the largest power of two
// below n; an odd node is never duplicated, so [a,b,c] and [a,b,c,c] have
// different roots. Audit paths are verified against a known leaf count.
// ---------------------------------------------------------------------------

function nodeHash(left: Buffer, right: Buffer): Buffer {
  return sha256(Buffer.concat([Buffer.from([0x01]), left, right]));
}

/** Leaf hash with index and length bound in as fixed-width big-endian fields. */
export function leafHash(index: number, len: number, chunk: Buffer): Buffer {
  const head = Buffer.alloc(9);
  head[0] = 0x00;
  head.writeUInt32BE(index, 1);
  head.writeUInt32BE(len, 5);
  return sha256(Buffer.concat([head, chunk]));
}

function splitPoint(n: number): number {
  let k = 1;
  while (k * 2 < n) k *= 2;
  return k;
}

export function merkleRoot(leaves: Buffer[]): Buffer {
  const n = leaves.length;
  if (n === 0) throw new Error('RELAY_EMPTY_TREE');
  if (n === 1) return leaves[0];
  const k = splitPoint(n);
  return nodeHash(merkleRoot(leaves.slice(0, k)), merkleRoot(leaves.slice(k)));
}

export function merklePath(leaves: Buffer[], index: number): Buffer[] {
  const n = leaves.length;
  if (!Number.isSafeInteger(index) || index < 0 || index >= n) throw new Error('RELAY_INDEX');
  if (n === 1) return [];
  const k = splitPoint(n);
  if (index < k) return [...merklePath(leaves.slice(0, k), index), merkleRoot(leaves.slice(k))];
  return [...merklePath(leaves.slice(k), index - k), merkleRoot(leaves.slice(0, k))];
}

/** RFC 9162 section 2.1.3.2 inclusion-proof verification. */
export function verifyMerklePath(leaf: Buffer, index: number, size: number, path: Buffer[], root: Buffer): boolean {
  if (!Number.isSafeInteger(index) || !Number.isSafeInteger(size) || index < 0 || size < 1 || index >= size) {
    return false;
  }
  let fn = index;
  let sn = size - 1;
  let r = leaf;
  for (const p of path) {
    if (sn === 0) return false;
    if (fn % 2 === 1 || fn === sn) {
      r = nodeHash(p, r);
      if (fn % 2 === 0) {
        while (fn % 2 === 0 && fn !== 0) {
          fn = Math.floor(fn / 2);
          sn = Math.floor(sn / 2);
        }
      }
    } else {
      r = nodeHash(r, p);
    }
    fn = Math.floor(fn / 2);
    sn = Math.floor(sn / 2);
  }
  return sn === 0 && r.equals(root);
}
