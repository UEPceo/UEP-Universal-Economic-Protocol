/**
 * In-process business-layer balances for these adapters.
 * This is not the UEP ledger. It copies the conservation rule
 * inputs = outputs + fees, rejects self-transfers, and never mints
 * except through a faucet entry signed by the dedicated faucet key.
 * Marketplace balances are not consensus-final (ARCHITECTURE section 3).
 *
 * Design rules that close the audit findings:
 *  - Balances live in nested maps (asset -> account), never in concatenated string keys.
 *  - Funds are escrowed in HOLDS owned by the module that opened them. A module can only
 *    release or refund its own holds, and a release must pay out exactly the held amount.
 *  - Every mutation is bounded by a signed supply that is itself checked to stay a safe integer.
 *  - `atomic()` snapshots and rolls back on any throw, so no multi-step operation can half-apply.
 *  - Modules receive a `LedgerPort`, issued once per module name, never the raw book.
 */

import { canonicalJson } from './canonical.js';
import { assertAccountId, assertAssetId, assertNonNegInt, isReservedAccount } from './ids.js';
import { assertPositiveAmount, assertSafeAmount } from './fees.js';
import { verifyMessage, type KeyRegistry, type Signed } from './registry.js';

export const MINT_DOMAIN = 'UEP-FAUCET-MINT-v1';

export interface MintBody {
  asset: string;
  to: string;
  amount: number;
  nonce: number;
}

export type HoldState = 'OPEN' | 'RELEASED' | 'REFUNDED';

export interface Hold {
  id: string;
  owner: string;
  account: string;
  asset: string;
  amount: number;
  state: HoldState;
}

export interface Payout {
  to: string;
  amount: number;
}

export interface LedgerPort {
  free(account: string, asset: string): number;
  lockedOf(account: string, asset: string): number;
  openHold(holdId: string, account: string, asset: string, amount: number): void;
  holdInfo(holdId: string): Readonly<Hold> | undefined;
  /** Pays the whole held amount out. Payouts must sum exactly to the hold. */
  releaseHold(holdId: string, payouts: Payout[]): void;
  refundHold(holdId: string): void;
  /** Spends free funds. Callers must already hold the owner's signed authorization. */
  moveFree(from: string, to: string, asset: string, amount: number): void;
  atomic<T>(fn: () => T): T;
}

export class BalanceBook {
  private rows = new Map<string, Map<string, number>>();
  private holds = new Map<string, Hold>();
  private supply = new Map<string, number>();
  private mintNonces = new Set<string>();
  private reserved = new Map<string, string>();
  private issuedPorts = new Set<string>();
  readonly faucetLog: { asset: string; to: string; amount: number }[] = [];

  constructor(
    private readonly registry: KeyRegistry,
    private readonly faucetId: string,
  ) {
    if (!registry.has(faucetId)) throw new Error('UEP_FAUCET_KEY_UNREGISTERED');
  }

  // ----- administration (composition root only) -----------------------------

  /** Reserved accounts can only be debited by the module that owns them. */
  reserveAccount(account: string, module: string): void {
    assertAccountId(account);
    if (this.reserved.has(account)) throw new Error('UEP_ACCOUNT_RESERVED_ALREADY');
    this.reserved.set(account, module);
  }

  /** One port per module name; a second request is refused. */
  port(module: string): LedgerPort {
    if (this.issuedPorts.has(module)) throw new Error('UEP_PORT_ALREADY_ISSUED');
    this.issuedPorts.add(module);
    const book = this;
    return {
      free: (a, s) => book.free(a, s),
      lockedOf: (a, s) => book.lockedOf(a, s),
      openHold: (id, a, s, n) => book.openHold(module, id, a, s, n),
      holdInfo: (id) => book.holdInfo(module, id),
      releaseHold: (id, p) => book.releaseHold(module, id, p),
      refundHold: (id) => book.refundHold(module, id),
      moveFree: (f, t, s, n) => book.moveFree(module, f, t, s, n),
      atomic: (fn) => book.atomic(fn),
    };
  }

  /** Faucet mint: signed by the faucet key, replay-protected, bounded by a safe-integer supply. */
  mint(msg: Signed<MintBody>): void {
    const b = verifyMessage(this.registry, msg, MINT_DOMAIN);
    if (msg.signer !== this.faucetId) throw new Error('UEP_FAUCET_AUTH');
    assertAssetId(b.asset);
    assertAccountId(b.to, 'mint recipient');
    assertPositiveAmount(b.amount);
    assertNonNegInt(b.nonce, 'mint nonce');
    const nonceKey = canonicalJson(b.nonce);
    if (this.mintNonces.has(nonceKey)) throw new Error('UEP_FAUCET_REPLAY');
    const newSupply = (this.supply.get(b.asset) ?? 0) + b.amount;
    if (!Number.isSafeInteger(newSupply)) throw new Error('UEP_OVERFLOW');
    this.credit(b.to, b.asset, b.amount);
    this.supply.set(b.asset, newSupply);
    this.mintNonces.add(nonceKey);
    this.faucetLog.push({ asset: b.asset, to: b.to, amount: b.amount });
  }

  // ----- reads ----------------------------------------------------------------

  free(account: string, asset: string): number {
    return this.rows.get(asset)?.get(account) ?? 0;
  }

  lockedOf(account: string, asset: string): number {
    let sum = 0n;
    for (const h of this.holds.values()) {
      if (h.state === 'OPEN' && h.account === account && h.asset === asset) sum += BigInt(h.amount);
    }
    return Number(sum);
  }

  supplyOf(asset: string): number {
    return this.supply.get(asset) ?? 0;
  }

  /** free + open holds, as BigInt so the sum itself can never overflow. */
  total(asset: string): bigint {
    let sum = 0n;
    for (const v of this.rows.get(asset)?.values() ?? []) sum += BigInt(v);
    for (const h of this.holds.values()) if (h.state === 'OPEN' && h.asset === asset) sum += BigInt(h.amount);
    return sum;
  }

  assertConserved(asset: string): void {
    if (this.total(asset) !== BigInt(this.supply.get(asset) ?? 0)) throw new Error(`UEP_CONSERVATION:${asset}`);
  }

  assertAllConserved(): void {
    const assets = new Set<string>([...this.supply.keys(), ...this.rows.keys()]);
    for (const a of assets) this.assertConserved(a);
  }

  // ----- atomicity --------------------------------------------------------------

  atomic<T>(fn: () => T): T {
    const rows = new Map<string, Map<string, number>>();
    for (const [asset, m] of this.rows) rows.set(asset, new Map(m));
    const holds = new Map<string, Hold>();
    for (const [k, h] of this.holds) holds.set(k, { ...h });
    const supply = new Map(this.supply);
    const nonces = new Set(this.mintNonces);
    const logLen = this.faucetLog.length;
    try {
      return fn();
    } catch (e) {
      this.rows = rows;
      this.holds = holds;
      this.supply = supply;
      this.mintNonces = nonces;
      this.faucetLog.length = logLen;
      throw e;
    }
  }

  // ----- module-scoped operations (reached through LedgerPort) -----------------

  private holdKey(module: string, id: string): string {
    return canonicalJson([module, id]);
  }

  private openHold(module: string, id: string, account: string, asset: string, amount: number): void {
    assertAccountId(id, 'hold id');
    assertAccountId(account);
    assertAssetId(asset);
    assertPositiveAmount(amount);
    this.requireNotForeignReserved(account, module);
    const key = this.holdKey(module, id);
    if (this.holds.has(key)) throw new Error('UEP_HOLD_EXISTS');
    this.debit(account, asset, amount);
    this.holds.set(key, { id, owner: module, account, asset, amount, state: 'OPEN' });
  }

  private holdInfo(module: string, id: string): Readonly<Hold> | undefined {
    const h = this.holds.get(this.holdKey(module, id));
    return h ? { ...h } : undefined;
  }

  private releaseHold(module: string, id: string, payouts: Payout[]): void {
    const h = this.requireOpenHold(module, id);
    let sum = 0n;
    for (const p of payouts) {
      assertAccountId(p.to, 'payout recipient');
      assertPositiveAmount(p.amount, 'payout');
      sum += BigInt(p.amount);
    }
    if (sum !== BigInt(h.amount)) throw new Error('UEP_PAYOUT_SUM');
    for (const p of payouts) this.credit(p.to, h.asset, p.amount);
    h.state = 'RELEASED';
  }

  private refundHold(module: string, id: string): void {
    const h = this.requireOpenHold(module, id);
    this.credit(h.account, h.asset, h.amount);
    h.state = 'REFUNDED';
  }

  private moveFree(module: string, from: string, to: string, asset: string, amount: number): void {
    assertAccountId(from);
    assertAccountId(to);
    assertAssetId(asset);
    assertPositiveAmount(amount);
    if (from === to) throw new Error('UEP_SELF_TRANSFER');
    this.requireNotForeignReserved(from, module);
    this.debit(from, asset, amount);
    this.credit(to, asset, amount);
  }

  // ----- internals ----------------------------------------------------------------

  private requireOpenHold(module: string, id: string): Hold {
    const h = this.holds.get(this.holdKey(module, id));
    if (!h) throw new Error('UEP_HOLD_UNKNOWN');
    if (h.state !== 'OPEN') throw new Error('UEP_HOLD_CLOSED');
    return h;
  }

  private requireNotForeignReserved(account: string, module: string): void {
    const owner = this.reserved.get(account);
    if (owner !== undefined && owner !== module) throw new Error('UEP_ACCOUNT_RESERVED');
    if (owner === undefined && isReservedAccount(account)) throw new Error('UEP_ACCOUNT_RESERVED');
  }

  private assetRows(asset: string): Map<string, number> {
    let m = this.rows.get(asset);
    if (!m) {
      m = new Map();
      this.rows.set(asset, m);
    }
    return m;
  }

  private credit(account: string, asset: string, amount: number): void {
    assertSafeAmount(amount);
    const m = this.assetRows(asset);
    const next = (m.get(account) ?? 0) + amount;
    if (!Number.isSafeInteger(next)) throw new Error('UEP_OVERFLOW');
    m.set(account, next);
  }

  private debit(account: string, asset: string, amount: number): void {
    assertSafeAmount(amount);
    const m = this.assetRows(asset);
    const cur = m.get(account) ?? 0;
    if (cur < amount) throw new Error('UEP_INSUFFICIENT');
    m.set(account, cur - amount);
  }
}
