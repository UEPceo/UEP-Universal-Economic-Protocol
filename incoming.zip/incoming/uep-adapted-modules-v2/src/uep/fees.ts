/**
 * Public testnet fee rules (UEP architecture, v0.4.4+).
 * Protocol:    max(1, floor(amount * 10 / 10_000)) on a ledger spend.
 * Marketplace: max(1, floor(amount * 300 / 10_000)) on successful settlement only.
 * No native token. No burn. All intermediate products use BigInt.
 */

export function assertSafeAmount(amount: number, label = 'amount'): void {
  if (typeof amount !== 'number' || !Number.isSafeInteger(amount) || amount < 0) {
    throw new Error(`UEP_AMOUNT:${label}`);
  }
}

export function assertPositiveAmount(amount: number, label = 'amount'): void {
  assertSafeAmount(amount, label);
  if (amount === 0) throw new Error(`UEP_AMOUNT:${label}`);
}

export function safeAdd(a: number, b: number): number {
  const s = a + b;
  if (!Number.isSafeInteger(s)) throw new Error('UEP_OVERFLOW');
  return s;
}

/** floor(amount * num / den) computed exactly. Result never exceeds amount when num <= den. */
export function mulDivFloor(amount: number, num: number, den: number): number {
  assertSafeAmount(amount);
  const r = (BigInt(amount) * BigInt(num)) / BigInt(den);
  if (r > BigInt(Number.MAX_SAFE_INTEGER)) throw new Error('UEP_OVERFLOW');
  return Number(r);
}

export function protocolFee(amount: number): number {
  assertSafeAmount(amount);
  if (amount === 0) return 0;
  return Math.max(1, mulDivFloor(amount, 10, 10_000));
}

export function marketplaceFee(amount: number): number {
  assertSafeAmount(amount);
  if (amount === 0) return 0;
  return Math.max(1, mulDivFloor(amount, 300, 10_000));
}

/** Smallest amount for which the protocol fee leaves at least 1 unit. */
export const MIN_LEG_AMOUNT = 2;

/** Largest-remainder split in exact integer arithmetic; parts always sum to `total`. */
export function splitBps(total: number, parts: { key: string; bps: number }[]): Record<string, number> {
  assertSafeAmount(total);
  const keys = new Set(parts.map((p) => p.key));
  if (keys.size !== parts.length) throw new Error('UEP_SPLIT_KEYS');
  let sumBps = 0;
  for (const p of parts) {
    if (!Number.isSafeInteger(p.bps) || p.bps < 0 || p.bps > 10_000) throw new Error('UEP_SPLIT_BPS');
    sumBps += p.bps;
  }
  if (sumBps !== 10_000) throw new Error('UEP_SPLIT_BPS');
  const t = BigInt(total);
  const out: Record<string, number> = {};
  const rems: { key: string; rem: bigint }[] = [];
  let assigned = 0;
  for (const p of parts) {
    const num = t * BigInt(p.bps);
    out[p.key] = Number(num / 10_000n);
    rems.push({ key: p.key, rem: num % 10_000n });
    assigned += out[p.key];
  }
  const remainder = total - assigned;
  rems.sort((a, b) => (a.rem === b.rem ? a.key.localeCompare(b.key) : a.rem > b.rem ? -1 : 1));
  for (let i = 0; i < remainder; i++) out[rems[i].key] += 1;
  return out;
}

export const TREASURY_SPLIT = [
  { key: 'operations', bps: 4000 },
  { key: 'riskReserve', bps: 2500 },
  { key: 'development', bps: 2000 },
  { key: 'distributable', bps: 1500 },
] as const;
