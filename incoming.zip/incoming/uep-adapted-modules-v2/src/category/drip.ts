/**
 * Paymaster drip controller.
 *
 * A node can claim a subsidy only for work that the swap or relay module itself recorded as
 * settled (SettlementIndex). It cannot declare its own work, reuse a receipt, or claim for
 * someone else's order. Each order pays at most `perOrderBps` of the marketplace fee that
 * order generated, so wash-trading always costs the attacker more in fees than it can ever
 * draw back. Claims are signed by the node; the cap is bounded per hour; the ledger move runs
 * before any counter is updated, so a failed claim changes nothing.
 */

import { canonicalJson } from '../uep/canonical.js';
import { mulDivFloor } from '../uep/fees.js';
import { assertAccountId, assertAssetId, assertHex32, assertNonNegInt, assertPositiveInt } from '../uep/ids.js';
import { MonotonicClock, ReplayGuard, verifyMessage, type KeyRegistry, type Signed } from '../uep/registry.js';
import type { SettlementIndex } from '../uep/settlement-index.js';
import type { PaymasterCap, Treasury } from '../uep/treasury.js';

export const DRIP_CLAIM_DOMAIN = 'UEP-DRIP-CLAIM-v1';

export interface DripConfig {
  maxSingle: number;
  cooldownSeconds: number;
  /** Hourly cap as bps of the paymaster bucket at the start of the window. */
  hourlyCapBps: number;
  windowSeconds: number;
  /** Share of the order's collected marketplace fee that can be drawn back, in bps. */
  perOrderBps: number;
  validitySeconds: number;
}

export const DEFAULT_DRIP_CONFIG: DripConfig = {
  maxSingle: 50,
  cooldownSeconds: 30,
  hourlyCapBps: 50,
  windowSeconds: 3600,
  perOrderBps: 5000,
  validitySeconds: 86_400,
};

export interface DripClaimBody {
  nodeId: string;
  asset: string;
  amount: number;
  orderId: string;
  receiptHash: string;
  nonce: number;
}

export class DripController {
  private spentOrders = new Set<string>();
  private lastClaim = new Map<string, number>();
  private windows = new Map<string, { start: number; spent: number }>();
  private readonly replay = new ReplayGuard();
  private readonly clock = new MonotonicClock();

  constructor(
    private readonly treasury: Treasury,
    private readonly cap: PaymasterCap,
    private readonly index: SettlementIndex,
    private readonly registry: KeyRegistry,
    private readonly cfg: DripConfig = DEFAULT_DRIP_CONFIG,
  ) {}

  claim(msg: Signed<DripClaimBody>, now: number): number {
    this.clock.check(now);
    const b = verifyMessage(this.registry, msg, DRIP_CLAIM_DOMAIN);
    assertAccountId(b.nodeId, 'node');
    if (msg.signer !== b.nodeId) throw new Error('DRIP_SIGNER');
    assertAssetId(b.asset);
    assertPositiveInt(b.amount, 'amount');
    assertAccountId(b.orderId, 'order');
    assertHex32(b.receiptHash, 'receipt');
    assertNonNegInt(b.nonce, 'nonce');
    if (b.amount > this.cfg.maxSingle) throw new Error('DRIP_AMOUNT_EXCEEDS_SINGLE');
    this.replay.check('drip', b.nodeId, b.nonce);

    const work = this.index.get(b.orderId);
    if (!work) throw new Error('DRIP_WORK_UNVERIFIED');
    if (work.providerId !== b.nodeId) throw new Error('DRIP_NOT_PROVIDER');
    if (work.asset !== b.asset || work.receiptHash !== b.receiptHash) throw new Error('DRIP_WORK_MISMATCH');
    if (now < work.settledAt || now - work.settledAt > this.cfg.validitySeconds) throw new Error('DRIP_RECEIPT_EXPIRED');
    if (this.spentOrders.has(b.orderId)) throw new Error('DRIP_ALREADY_CLAIMED');

    const entitlement = Math.min(this.cfg.maxSingle, mulDivFloor(work.feeCollected, this.cfg.perOrderBps, 10_000));
    if (entitlement < 1) throw new Error('DRIP_NO_ENTITLEMENT');
    if (b.amount > entitlement) throw new Error('DRIP_AMOUNT_EXCEEDS_ENTITLEMENT');

    const cdKey = canonicalJson([b.nodeId, b.asset]);
    const last = this.lastClaim.get(cdKey);
    if (last !== undefined && now - last < this.cfg.cooldownSeconds) throw new Error('DRIP_COOLDOWN');

    let win = this.windows.get(b.asset);
    if (!win || now - win.start >= this.cfg.windowSeconds) win = { start: now, spent: 0 };
    const base = this.treasury.buckets(b.asset).paymaster + win.spent;
    const hourlyCap = Math.max(this.cfg.maxSingle, mulDivFloor(base, this.cfg.hourlyCapBps, 10_000));
    if (win.spent + b.amount > hourlyCap) throw new Error('DRIP_HOURLY_CAP');

    // The ledger move comes first and throws before anything below changes.
    this.treasury.spendPaymaster(this.cap, b.asset, b.nodeId, b.amount);

    win.spent += b.amount;
    this.windows.set(b.asset, win);
    this.lastClaim.set(cdKey, now);
    this.spentOrders.add(b.orderId);
    this.replay.consume('drip', b.nodeId, b.nonce);
    return b.amount;
  }
}
