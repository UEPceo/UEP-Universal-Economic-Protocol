/**
 * uep.service.dispute.v1 — dispute engine adapter.
 *
 * What this module decides: a dispute case, its evidence, and a verdict expressed as
 * `releaseBps` (10000 = RELEASE, 0 = REFUND_BUYER, in between = SPLIT) plus whether the
 * claim was frivolous. What it does NOT do: move escrow. The category that owns the holds
 * (swap, relay) applies the verdict through a capability, so escrow is always read from,
 * and settled by, the module that actually holds it.
 *
 * Properties (each one has a regression test):
 *  - The arbiter set is fixed at construction and every verdict signature is verified
 *    against the registry; presenting your own keys under an arbiter's id is impossible
 *    because ids are derived from keys and registration needs proof of possession.
 *  - One case per order. The bond is locked and the order frozen atomically, so a refused
 *    open never leaks a bond.
 *  - The claimant's bond is returned unless the arbiters sign `frivolous` on a verdict
 *    that goes entirely against the claimant; only then is it forfeited (80% respondent,
 *    20% treasury risk reserve). A buyer who wins is never penalised.
 *  - There is always a way out: after the resolution deadline anyone can call `timeout`,
 *    which applies the configured default (never RELEASE), returns the bond and unfreezes.
 *  - The respondent can answer: evidence is accepted from both parties until the evidence
 *    deadline, and the case stays open for it.
 */

import { canonicalJson } from '../uep/canonical.js';
import { sha256Hex } from '../uep/crypto.js';
import { mulDivFloor } from '../uep/fees.js';
import {
  assertAccountId,
  assertAssetId,
  assertHex32,
  assertNonNegInt,
  assertPositiveInt,
  MARKETPLACE_TREASURY,
} from '../uep/ids.js';
import type { BalanceBook, LedgerPort, Payout } from '../uep/ledger.js';
import { MonotonicClock, ReplayGuard, verifyMessage, type KeyRegistry, type Signed } from '../uep/registry.js';
import type { Treasury } from '../uep/treasury.js';
import type { Disputable, DisputeCap, EscrowView } from './disputable.js';

export const DISPUTE_OPEN_DOMAIN = 'UEP-DISPUTE-OPEN-v1';
export const DISPUTE_EVIDENCE_DOMAIN = 'UEP-DISPUTE-EVIDENCE-v1';
export const DISPUTE_VERDICT_DOMAIN = 'UEP-DISPUTE-VERDICT-v1';

export interface DisputeConfig {
  minBond: number;
  bondBps: number;
  evidenceSeconds: number;
  resolutionSeconds: number;
  /** Outcome when arbiters do not act in time. 0 = refund buyer, 5000 = even split. Never 10000. */
  defaultReleaseBps: 0 | 5000;
  forfeitRespondentBps: number;
  maxEvidencePerParty: number;
  maxEvidenceBytes: number;
}

export const DEFAULT_DISPUTE_CONFIG: DisputeConfig = {
  minBond: 50,
  bondBps: 100,
  evidenceSeconds: 3600,
  resolutionSeconds: 7 * 24 * 3600,
  defaultReleaseBps: 0,
  forfeitRespondentBps: 8000,
  maxEvidencePerParty: 8,
  maxEvidenceBytes: 64 * 1024,
};

export interface OpenDisputeBody {
  category: 'swap' | 'relay';
  orderId: string;
  bondAsset: string;
  bondAmount: number;
  nonce: number;
}

export interface EvidenceBody {
  disputeId: string;
  evidenceId: string;
  digest: string;
}

export type VerdictKind = 'RELEASE' | 'REFUND_BUYER' | 'SPLIT';

export interface VerdictBody {
  disputeId: string;
  orderId: string;
  category: 'swap' | 'relay';
  kind: VerdictKind;
  releaseBps: number;
  frivolous: boolean;
}

export type CaseState = 'OPEN' | 'RESOLVED' | 'TIMED_OUT';

export interface EvidenceItem {
  evidenceId: string;
  by: string;
  digest: string;
  size: number;
  at: number;
}

export interface DisputeCase {
  disputeId: string;
  category: 'swap' | 'relay';
  orderId: string;
  claimantId: string;
  respondentId: string;
  claimantIsBuyerSide: boolean;
  bondAsset: string;
  bondAmount: number;
  openedAt: number;
  evidenceDeadline: number;
  resolutionDeadline: number;
  state: CaseState;
  releaseBps?: number;
  frivolous?: boolean;
  bondForfeited?: boolean;
  evidence: EvidenceItem[];
}

export function disputeIdOf(category: string, orderId: string): string {
  return `dsp_${sha256Hex(canonicalJson(['UEP-DISPUTE-ID-v1', category, orderId])).slice(0, 32)}`;
}

export function verdictKindFor(releaseBps: number): VerdictKind {
  return releaseBps === 10_000 ? 'RELEASE' : releaseBps === 0 ? 'REFUND_BUYER' : 'SPLIT';
}

interface Attached {
  cat: Disputable;
  cap: DisputeCap;
}

export class DisputeCategory {
  private cases = new Map<string, DisputeCase>();
  private attached = new Map<string, Attached>();
  private adverse = new Map<string, number>();
  private readonly ledger: LedgerPort;
  private readonly replay = new ReplayGuard();
  private readonly clock = new MonotonicClock();
  private readonly arbiters: Set<string>;

  constructor(
    book: BalanceBook,
    private readonly treasury: Treasury,
    private readonly registry: KeyRegistry,
    arbiterIds: string[],
    private readonly quorum: number,
    private readonly cfg: DisputeConfig = DEFAULT_DISPUTE_CONFIG,
  ) {
    this.arbiters = new Set(arbiterIds);
    if (this.arbiters.size !== arbiterIds.length || this.arbiters.size === 0) throw new Error('DISPUTE_ARBITERS');
    for (const id of this.arbiters) if (!registry.has(id)) throw new Error('DISPUTE_ARBITER_UNREGISTERED');
    // Strict majority, so two conflicting verdicts can never both reach quorum.
    if (!Number.isSafeInteger(quorum) || quorum * 2 <= this.arbiters.size || quorum > this.arbiters.size) {
      throw new Error('DISPUTE_QUORUM');
    }
    if (cfg.defaultReleaseBps !== 0 && cfg.defaultReleaseBps !== 5000) throw new Error('DISPUTE_DEFAULT');
    this.ledger = book.port('dispute');
  }

  attach(cat: Disputable, cap: DisputeCap): void {
    if (this.attached.has(cat.category)) throw new Error('DISPUTE_ATTACHED');
    this.attached.set(cat.category, { cat, cap });
  }

  /** Opening locks the bond and freezes the order in one atomic step. */
  open(msg: Signed<OpenDisputeBody>, now: number): DisputeCase {
    this.clock.check(now);
    const b = verifyMessage(this.registry, msg, DISPUTE_OPEN_DOMAIN);
    const claimant = msg.signer;
    const att = this.attached.get(b.category);
    if (!att) throw new Error('DISPUTE_CATEGORY');
    assertAccountId(b.orderId, 'order');
    assertAssetId(b.bondAsset, 'bondAsset');
    assertPositiveInt(b.bondAmount, 'bondAmount');
    assertNonNegInt(b.nonce, 'nonce');

    const view = att.cat.escrowView(b.orderId);
    if (!view) throw new Error('DISPUTE_ORDER_UNKNOWN');
    if (!view.open) throw new Error('DISPUTE_ORDER_CLOSED');
    if (view.frozen) throw new Error('DISPUTE_ALREADY_EXISTS');
    const buyerSide = view.buyerSide.includes(claimant);
    if (!buyerSide && !view.sellerSide.includes(claimant)) throw new Error('DISPUTE_NOT_PARTY');

    const disputeId = disputeIdOf(b.category, b.orderId);
    if (this.cases.has(disputeId)) throw new Error('DISPUTE_ALREADY_EXISTS');
    this.replay.check('dispute-open', claimant, b.nonce);

    const escrowSum = view.escrows.filter((e) => e.asset === b.bondAsset).reduce((s, e) => s + BigInt(e.amount), 0n);
    if (escrowSum === 0n) throw new Error('DISPUTE_BOND_ASSET');
    const proportional = Number((escrowSum * BigInt(this.cfg.bondBps) + 9_999n) / 10_000n);
    const required = Math.max(this.cfg.minBond, proportional);
    if (b.bondAmount < required) throw new Error('DISPUTE_BOND_TOO_LOW');

    this.ledger.atomic(() => {
      this.ledger.openHold(`${disputeId}:bond`, claimant, b.bondAsset, b.bondAmount);
      att.cat.freeze(att.cap, b.orderId, disputeId);
    });
    this.replay.consume('dispute-open', claimant, b.nonce);

    const c: DisputeCase = {
      disputeId,
      category: b.category,
      orderId: b.orderId,
      claimantId: claimant,
      respondentId: buyerSide ? view.sellerId : view.buyerId,
      claimantIsBuyerSide: buyerSide,
      bondAsset: b.bondAsset,
      bondAmount: b.bondAmount,
      openedAt: now,
      evidenceDeadline: now + this.cfg.evidenceSeconds,
      resolutionDeadline: now + this.cfg.evidenceSeconds + this.cfg.resolutionSeconds,
      state: 'OPEN',
      evidence: [],
    };
    this.cases.set(disputeId, c);
    return structuredClone(c);
  }

  /** Either party may submit until the evidence deadline; the case stays open for replies. */
  submitEvidence(msg: Signed<EvidenceBody>, payload: Buffer, now: number): EvidenceItem {
    this.clock.check(now);
    const b = verifyMessage(this.registry, msg, DISPUTE_EVIDENCE_DOMAIN);
    const c = this.requireCase(b.disputeId);
    if (c.state !== 'OPEN') throw new Error('DISPUTE_CLOSED');
    if (now > c.evidenceDeadline) throw new Error('DISPUTE_EVIDENCE_CLOSED');
    if (msg.signer !== c.claimantId && msg.signer !== c.respondentId) throw new Error('DISPUTE_NOT_PARTY');
    assertAccountId(b.evidenceId, 'evidenceId');
    assertHex32(b.digest, 'digest');
    if (!Buffer.isBuffer(payload) || payload.length === 0 || payload.length > this.cfg.maxEvidenceBytes) {
      throw new Error('DISPUTE_EVIDENCE_SIZE');
    }
    if (sha256Hex(payload) !== b.digest) throw new Error('DISPUTE_EVIDENCE_DIGEST');
    if (c.evidence.some((e) => e.evidenceId === b.evidenceId)) throw new Error('DISPUTE_EVIDENCE_DUPLICATE');
    if (c.evidence.filter((e) => e.by === msg.signer).length >= this.cfg.maxEvidencePerParty) {
      throw new Error('DISPUTE_EVIDENCE_LIMIT');
    }
    const item: EvidenceItem = { evidenceId: b.evidenceId, by: msg.signer, digest: b.digest, size: payload.length, at: now };
    c.evidence.push(item);
    return { ...item };
  }

  /**
   * A quorum of distinct arbiters signs the same verdict. Signatures are verified against the
   * registry, signers must belong to the fixed arbiter set and must not be parties to the order.
   */
  resolve(disputeId: string, verdicts: Signed<VerdictBody>[], now: number): DisputeCase {
    this.clock.check(now);
    const c = this.requireCase(disputeId);
    if (c.state !== 'OPEN') throw new Error('DISPUTE_CLOSED');
    if (now <= c.evidenceDeadline) throw new Error('DISPUTE_EVIDENCE_OPEN');
    if (now > c.resolutionDeadline) throw new Error('DISPUTE_RESOLUTION_EXPIRED');
    const att = this.attachedFor(c);
    const view = att.cat.escrowView(c.orderId);
    if (!view) throw new Error('DISPUTE_ORDER_UNKNOWN');
    const parties = new Set([...view.buyerSide, ...view.sellerSide]);

    const signers = new Set<string>();
    let reference: string | undefined;
    let verdict: VerdictBody | undefined;
    for (const m of verdicts) {
      const v = verifyMessage(this.registry, m, DISPUTE_VERDICT_DOMAIN);
      if (!this.arbiters.has(m.signer)) throw new Error('DISPUTE_ARBITER');
      if (parties.has(m.signer)) throw new Error('DISPUTE_ARBITER_CONFLICT');
      if (v.disputeId !== c.disputeId || v.orderId !== c.orderId || v.category !== c.category) {
        throw new Error('DISPUTE_VERDICT_BINDING');
      }
      if (!Number.isSafeInteger(v.releaseBps) || v.releaseBps < 0 || v.releaseBps > 10_000) {
        throw new Error('DISPUTE_VERDICT_INVALID');
      }
      if (v.kind !== verdictKindFor(v.releaseBps) || typeof v.frivolous !== 'boolean') {
        throw new Error('DISPUTE_VERDICT_INVALID');
      }
      const canon = canonicalJson(v);
      if (reference !== undefined && canon !== reference) throw new Error('DISPUTE_VERDICT_MISMATCH');
      reference = canon;
      verdict = v;
      signers.add(m.signer);
    }
    if (!verdict || signers.size < this.quorum) throw new Error('DISPUTE_QUORUM_NOT_MET');

    // `frivolous` is only meaningful on a verdict that goes entirely against the claimant.
    const totalLoss = c.claimantIsBuyerSide ? verdict.releaseBps === 10_000 : verdict.releaseBps === 0;
    if (verdict.frivolous && !totalLoss) throw new Error('DISPUTE_VERDICT_INVALID');

    this.finish(c, att, verdict.releaseBps, verdict.frivolous, now);
    c.state = 'RESOLVED';
    return structuredClone(c);
  }

  /** Liveness: arbiters did not act in time. Applies the default, returns the bond, unfreezes. */
  timeout(disputeId: string, now: number): DisputeCase {
    this.clock.check(now);
    const c = this.requireCase(disputeId);
    if (c.state !== 'OPEN') throw new Error('DISPUTE_CLOSED');
    if (now <= c.resolutionDeadline) throw new Error('DISPUTE_NOT_TIMED_OUT');
    this.finish(c, this.attachedFor(c), this.cfg.defaultReleaseBps, false, now);
    c.state = 'TIMED_OUT';
    return structuredClone(c);
  }

  get(disputeId: string): DisputeCase | undefined {
    const c = this.cases.get(disputeId);
    return c ? structuredClone(c) : undefined;
  }

  adverseCount(id: string): number {
    return this.adverse.get(id) ?? 0;
  }

  // ----- internals -----------------------------------------------------------------

  private requireCase(id: string): DisputeCase {
    const c = this.cases.get(id);
    if (!c) throw new Error('DISPUTE_UNKNOWN');
    return c;
  }

  private attachedFor(c: DisputeCase): Attached {
    const a = this.attached.get(c.category);
    if (!a) throw new Error('DISPUTE_CATEGORY');
    return a;
  }

  /** Bond handling and escrow application in one atomic block; case state is set by the caller afterwards. */
  private finish(c: DisputeCase, att: Attached, releaseBps: number, frivolous: boolean, now: number): void {
    const forfeit = frivolous;
    let toTreasury = 0;
    this.ledger.atomic(() => {
      const holdId = `${c.disputeId}:bond`;
      if (forfeit) {
        const toRespondent = mulDivFloor(c.bondAmount, this.cfg.forfeitRespondentBps, 10_000);
        toTreasury = c.bondAmount - toRespondent;
        const payouts: Payout[] = [
          { to: c.respondentId, amount: toRespondent },
          { to: MARKETPLACE_TREASURY, amount: toTreasury },
        ].filter((p) => p.amount > 0);
        this.ledger.releaseHold(holdId, payouts);
      } else {
        this.ledger.refundHold(holdId);
      }
      att.cat.apply(att.cap, c.orderId, c.disputeId, releaseBps, now);
      if (toTreasury > 0) this.treasury.collectTransfer(c.bondAsset, toTreasury);
    });
    c.releaseBps = releaseBps;
    c.frivolous = frivolous;
    c.bondForfeited = forfeit;
    if (forfeit) this.adverse.set(c.claimantId, (this.adverse.get(c.claimantId) ?? 0) + 1);
  }
}

export type { EscrowView };
