/**
 * Contract between the dispute engine and the categories it can arbitrate.
 * The engine never touches escrow itself: it freezes an order, and later asks the
 * category (which owns the holds) to apply a verdict expressed as `releaseBps`:
 *   10000 = RELEASE, 0 = REFUND_BUYER, anything between = SPLIT.
 * The engine reads the escrow from the category; the claimant cannot supply a snapshot.
 */

export interface DisputeCap {
  readonly kind: 'dispute-cap';
}

export interface EscrowView {
  orderId: string;
  category: 'swap' | 'relay';
  buyerId: string;
  sellerId: string;
  buyerSide: string[];
  sellerSide: string[];
  escrows: { asset: string; amount: number }[];
  /** True while the order is in a state a dispute may still change. */
  open: boolean;
  frozen: boolean;
}

export interface Disputable {
  readonly category: 'swap' | 'relay';
  issueDisputeCap(): DisputeCap;
  escrowView(orderId: string): EscrowView | undefined;
  freeze(cap: DisputeCap, orderId: string, caseId: string): void;
  unfreeze(cap: DisputeCap, orderId: string, caseId: string): void;
  /** Releases or refunds all escrow per `releaseBps`, unfreezes, and closes the order. */
  apply(cap: DisputeCap, orderId: string, caseId: string, releaseBps: number, now: number): void;
}

export function newDisputeCapRegistry(): {
  issue(): DisputeCap;
  check(cap: DisputeCap): void;
} {
  let issued: DisputeCap | undefined;
  return {
    issue() {
      if (issued) throw new Error('DISPUTE_CAP_ALREADY_ISSUED');
      issued = Object.freeze({ kind: 'dispute-cap' as const });
      return issued;
    },
    check(cap) {
      if (cap !== issued) throw new Error('DISPUTE_CAP_INVALID');
    },
  };
}
