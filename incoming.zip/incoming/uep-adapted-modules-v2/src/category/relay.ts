/**
 * uep.service.relay.v1 — design adapter of UEP-SVC-RELAY-007.
 * Chunk fraud proofs only. ChaCha20 under an HKDF key. No full-blob endpoint.
 * Key inconsistency is a service fault, not a provider slash.
 * Ghost providers are bounded by counters, not "prevented".
 *
 * What changed against the first adapter (see docs/AUDIT-FIXES.md):
 *  - The order record holds commitments only. The module never sees the plaintext or the
 *    provider's secret key; fraud is checked from public commitments and the published key.
 *  - Only the named recipient can confirm early, by a signature the registry verifies.
 *  - Fraud proofs are submitted by the buyer or recipient, counted per submitter, and a
 *    proven fraud actually refunds the buyer and slashes the provider bond.
 *  - Money moves through ledger holds (price from the buyer, bond from the provider).
 *  - Orders can be frozen and resolved by the dispute engine.
 */

import { randomBytes } from 'node:crypto';
import { canonicalJson } from '../uep/canonical.js';
import {
  chacha20,
  keyCommit,
  leafHash,
  merklePath,
  merkleRoot,
  sha256Hex,
  verifyMerklePath,
  wrapKey,
} from '../uep/crypto.js';
import { marketplaceFee, mulDivFloor } from '../uep/fees.js';
import {
  assertAccountId,
  assertAssetId,
  assertHex32,
  assertNonNegInt,
  assertPositiveInt,
  MARKETPLACE_TREASURY,
} from '../uep/ids.js';
import type { BalanceBook, LedgerPort, Payout } from '../uep/ledger.js';
import { MonotonicClock, ReplayGuard, verifyMessage, type KeyRegistry, type Signed } from '../uep/registry.js';
import type { IndexWriter, SettlementIndex } from '../uep/settlement-index.js';
import type { Treasury } from '../uep/treasury.js';
import { newDisputeCapRegistry, type DisputeCap, type Disputable, type EscrowView } from './disputable.js';

export const CHUNK = 1024;
export const MAX_LEAVES = 1 << 20;
const MAX_PATH = 32;

export const RELAY_OFFER_DOMAIN = 'UEP-RELAY-OFFER-v1';
export const RELAY_COMMIT_DOMAIN = 'UEP-RELAY-COMMIT-v1';
export const RELAY_KEY_DOMAIN = 'UEP-RELAY-KEY-v1';
export const RELAY_CONFIRM_DOMAIN = 'UEP-RELAY-CONFIRM-v1';
export const RELAY_FRAUD_DOMAIN = 'UEP-RELAY-FRAUD-v1';

export interface RelayConfig {
  minPrice: number;
  minBond: number;
  maxLifetimeSeconds: number;
  minFraudWindowSeconds: number;
  maxFraudWindowSeconds: number;
  maxInvalidFraudAttempts: number;
  /** Share of a slashed bond paid to the buyer; the rest goes to the treasury risk reserve. */
  slashBuyerBps: number;
}

export const DEFAULT_RELAY_CONFIG: RelayConfig = {
  minPrice: 2,
  minBond: 10,
  maxLifetimeSeconds: 7 * 24 * 3600,
  minFraudWindowSeconds: 60,
  maxFraudWindowSeconds: 7 * 24 * 3600,
  maxInvalidFraudAttempts: 3,
  slashBuyerBps: 8000,
};

export interface RelayOfferBody {
  version: 1;
  category: 'uep.service.relay.v1';
  networkId: string;
  buyerId: string;
  providerId: string;
  recipientId: string;
  asset: string;
  price: number;
  minBond: number;
  keyDeadline: number;
  fraudWindowSeconds: number;
  nonce: number;
}

export interface BlobCommitment {
  chunkRoot: string;
  wrapRoot: string;
  kCommit: string;
  contentLen: number;
  leafCount: number;
}

export interface RelayCommitBody extends BlobCommitment {
  orderId: string;
  bond: number;
}

export type RelayState =
  | 'FUNDED'
  | 'KEY_RELEASED'
  | 'SETTLED'
  | 'FRAUD_PROVEN'
  | 'KEY_RELEASE_FAULT'
  | 'EXPIRED_REFUNDED'
  | 'DISPUTE_RESOLVED';

export interface RelayOrder {
  orderId: string;
  offer: RelayOfferBody;
  commit: RelayCommitBody;
  state: RelayState;
  openedAt: number;
  publishedKey?: string;
  fraudWindowEndsAt?: number;
  settledAt?: number;
  invalidFraudAttempts: Record<string, number>;
  frozenBy?: string;
}

export interface ProviderCounters {
  settledCount: number;
  expiredNoFinalCount: number;
  fraudProvenCount: number;
  distinctRecipients: string[];
}

export function completionBps(c: ProviderCounters): number | undefined {
  const den = c.settledCount + c.expiredNoFinalCount;
  if (den === 0) return undefined;
  return Math.floor((c.settledCount * 10_000) / den);
}

export function relayOrderId(offer: RelayOfferBody): string {
  return `rly_${sha256Hex(canonicalJson(['UEP-RELAY-ORDERID-v1', offer])).slice(0, 32)}`;
}

// ---------------------------------------------------------------------------
// Provider-side blob preparation and chunk fraud proofs (pure, no ledger).
// ---------------------------------------------------------------------------

export interface PreparedBlob {
  wrapped: Buffer;
  /** Plaintext leaf hashes; the provider publishes these with the wrapped blob. */
  leaves: Buffer[];
  commitment: BlobCommitment;
}

/** `tamper` exists for adversarial tests: it corrupts the wrapped bytes before they are committed. */
export function prepareBlob(
  content: Buffer,
  k: Buffer,
  networkId: string,
  orderId: string,
  tamper?: (wrapped: Buffer) => void,
): PreparedBlob {
  if (content.length === 0) throw new Error('RELAY_EMPTY_CONTENT');
  const key = wrapKey(k, networkId, orderId);
  const n = Math.ceil(content.length / CHUNK);
  if (n > MAX_LEAVES) throw new Error('RELAY_TOO_LARGE');
  const padded = Buffer.alloc(n * CHUNK);
  content.copy(padded);
  const wrapped = chacha20(key, 0, Buffer.alloc(12), padded);
  tamper?.(wrapped);
  const leaves: Buffer[] = [];
  const wrapLeaves: Buffer[] = [];
  for (let i = 0; i < n; i++) {
    const slice = content.subarray(i * CHUNK, Math.min(content.length, (i + 1) * CHUNK));
    leaves.push(leafHash(i, slice.length, slice));
    wrapLeaves.push(leafHash(i, CHUNK, wrapped.subarray(i * CHUNK, (i + 1) * CHUNK)));
  }
  return {
    wrapped,
    leaves,
    commitment: {
      chunkRoot: merkleRoot(leaves).toString('hex'),
      wrapRoot: merkleRoot(wrapLeaves).toString('hex'),
      kCommit: keyCommit(orderId, k),
      contentLen: content.length,
      leafCount: n,
    },
  };
}

export function unwrapChunk(wrappedChunk: Buffer, k: Buffer, index: number, networkId: string, orderId: string): Buffer {
  return chacha20(wrapKey(k, networkId, orderId), 16 * index, Buffer.alloc(12), wrappedChunk);
}

export interface FraudProof {
  chunkIndex: number;
  wrappedChunk: Buffer;
  wrapPath: Buffer[];
  /** The plaintext leaf the provider committed to at this index. */
  leafHash: Buffer;
  chunkPath: Buffer[];
}

/** What a challenger builds from the delivered package (wrapped blob + published plaintext leaves). */
export function buildFraudProof(wrapped: Buffer, plainLeaves: Buffer[], chunkIndex: number): FraudProof {
  const n = plainLeaves.length;
  const wrapLeaves: Buffer[] = [];
  for (let i = 0; i < n; i++) wrapLeaves.push(leafHash(i, CHUNK, wrapped.subarray(i * CHUNK, (i + 1) * CHUNK)));
  return {
    chunkIndex,
    wrappedChunk: Buffer.from(wrapped.subarray(chunkIndex * CHUNK, (chunkIndex + 1) * CHUNK)),
    wrapPath: merklePath(wrapLeaves, chunkIndex),
    leafHash: plainLeaves[chunkIndex],
    chunkPath: merklePath(plainLeaves, chunkIndex),
  };
}

export function proofDigest(p: FraudProof): string {
  return sha256Hex(
    canonicalJson([
      'UEP-RELAY-FRAUDPROOF-v1',
      p.chunkIndex,
      p.wrappedChunk.toString('hex'),
      p.wrapPath.map((b) => b.toString('hex')),
      p.leafHash.toString('hex'),
      p.chunkPath.map((b) => b.toString('hex')),
    ]),
  );
}

export type FraudResult = 'FRAUD_PROVEN' | 'RELAY_FRAUD_INVALID' | 'RELAY_FRAUD_SIZE';

/**
 * Pure check from public data only: commitments, the published key, and the proof.
 * Fraud means: the wrapped chunk is in the committed wrap tree, the claimed plaintext leaf is
 * in the committed content tree, and decrypting the wrapped chunk under the published key does
 * NOT reproduce that plaintext leaf.
 */
export function verifyChunkFraud(
  ctx: BlobCommitment & { networkId: string; orderId: string },
  publishedKey: Buffer,
  proof: FraudProof,
): FraudResult {
  if (
    !Number.isSafeInteger(proof.chunkIndex) ||
    !Buffer.isBuffer(proof.wrappedChunk) ||
    !Buffer.isBuffer(proof.leafHash) ||
    !Array.isArray(proof.wrapPath) ||
    !Array.isArray(proof.chunkPath)
  ) {
    return 'RELAY_FRAUD_INVALID';
  }
  if (
    proof.wrappedChunk.length !== CHUNK ||
    proof.leafHash.length !== 32 ||
    proof.wrapPath.length > MAX_PATH ||
    proof.chunkPath.length > MAX_PATH ||
    proof.wrapPath.some((b) => !Buffer.isBuffer(b) || b.length !== 32) ||
    proof.chunkPath.some((b) => !Buffer.isBuffer(b) || b.length !== 32)
  ) {
    return 'RELAY_FRAUD_SIZE';
  }
  if (proof.chunkIndex < 0 || proof.chunkIndex >= ctx.leafCount) return 'RELAY_FRAUD_INVALID';
  const wrapLeaf = leafHash(proof.chunkIndex, CHUNK, proof.wrappedChunk);
  if (!verifyMerklePath(wrapLeaf, proof.chunkIndex, ctx.leafCount, proof.wrapPath, Buffer.from(ctx.wrapRoot, 'hex'))) {
    return 'RELAY_FRAUD_INVALID';
  }
  if (!verifyMerklePath(proof.leafHash, proof.chunkIndex, ctx.leafCount, proof.chunkPath, Buffer.from(ctx.chunkRoot, 'hex'))) {
    return 'RELAY_FRAUD_INVALID';
  }
  const expectedLen = Math.min(CHUNK, ctx.contentLen - proof.chunkIndex * CHUNK);
  const plain = unwrapChunk(proof.wrappedChunk, publishedKey, proof.chunkIndex, ctx.networkId, ctx.orderId);
  const actual = leafHash(proof.chunkIndex, expectedLen, plain.subarray(0, expectedLen));
  return actual.equals(proof.leafHash) ? 'RELAY_FRAUD_INVALID' : 'FRAUD_PROVEN';
}

export function newProviderKey(): Buffer {
  return randomBytes(32);
}

// ---------------------------------------------------------------------------
// Category
// ---------------------------------------------------------------------------

export class RelayCategory implements Disputable {
  readonly category = 'relay' as const;
  private orders = new Map<string, RelayOrder>();
  private counters = new Map<string, { settled: number; expired: number; fraud: number; recipients: Set<string> }>();
  private readonly ledger: LedgerPort;
  private readonly replay = new ReplayGuard();
  private readonly clock = new MonotonicClock();
  private readonly caps = newDisputeCapRegistry();
  private readonly writeIndex: IndexWriter;

  constructor(
    book: BalanceBook,
    private readonly treasury: Treasury,
    private readonly registry: KeyRegistry,
    index: SettlementIndex,
    private readonly networkId = 'uep-testnet',
    private readonly cfg: RelayConfig = DEFAULT_RELAY_CONFIG,
  ) {
    this.ledger = book.port('relay');
    this.writeIndex = index.issueWriter('relay');
  }

  open(offerMsg: Signed<RelayOfferBody>, commitMsg: Signed<RelayCommitBody>, now: number): RelayOrder {
    this.clock.check(now);
    const offer = verifyMessage(this.registry, offerMsg, RELAY_OFFER_DOMAIN);
    this.validateOffer(offer, now);
    if (offerMsg.signer !== offer.buyerId) throw new Error('RELAY_BAD_SIGNATURE');

    const orderId = relayOrderId(offer);
    const commit = verifyMessage(this.registry, commitMsg, RELAY_COMMIT_DOMAIN);
    if (commitMsg.signer !== offer.providerId) throw new Error('RELAY_BAD_SIGNATURE');
    if (commit.orderId !== orderId) throw new Error('RELAY_ORDER_MISMATCH');
    this.validateCommit(commit, offer);

    if (this.orders.has(orderId)) throw new Error('RELAY_NONCE_REPLAY');
    this.replay.check('relay-nonce', offer.buyerId, offer.nonce);

    this.ledger.atomic(() => {
      this.ledger.openHold(`${orderId}:price`, offer.buyerId, offer.asset, offer.price);
      this.ledger.openHold(`${orderId}:bond`, offer.providerId, offer.asset, commit.bond);
    });
    this.replay.consume('relay-nonce', offer.buyerId, offer.nonce);
    const order: RelayOrder = {
      orderId,
      offer,
      commit,
      state: 'FUNDED',
      openedAt: now,
      invalidFraudAttempts: {},
    };
    this.orders.set(orderId, order);
    return structuredClone(order);
  }

  /**
   * The provider publishes the wrap key. A key that does not match the commitment is a
   * service fault: price and bond go back, nobody is slashed (the fault is counted).
   */
  publishKey(msg: Signed<{ orderId: string; k: string }>, now: number): 'KEY_RELEASED' | 'KEY_RELEASE_FAULT' {
    this.clock.check(now);
    const body = verifyMessage(this.registry, msg, RELAY_KEY_DOMAIN);
    const o = this.require(body.orderId);
    if (msg.signer !== o.offer.providerId) throw new Error('RELAY_NOT_PROVIDER');
    if (o.state !== 'FUNDED') throw new Error('RELAY_ORDER_STATE');
    if (o.frozenBy) throw new Error('RELAY_FROZEN');
    if (now > o.offer.keyDeadline) throw new Error('RELAY_DEADLINE');
    assertHex32(body.k, 'key');
    if (keyCommit(o.orderId, Buffer.from(body.k, 'hex')) !== o.commit.kCommit) {
      this.ledger.atomic(() => {
        this.ledger.refundHold(`${o.orderId}:price`);
        this.ledger.refundHold(`${o.orderId}:bond`);
      });
      o.state = 'KEY_RELEASE_FAULT';
      this.counter(o.offer.providerId).expired += 1;
      return 'KEY_RELEASE_FAULT';
    }
    o.publishedKey = body.k;
    o.state = 'KEY_RELEASED';
    o.fraudWindowEndsAt = now + o.offer.fraudWindowSeconds;
    return 'KEY_RELEASED';
  }

  /** Early confirmation: only the named recipient can close the fraud window and settle. */
  confirm(msg: Signed<{ orderId: string; chunkRoot: string }>, now: number): RelayOrder {
    this.clock.check(now);
    const body = verifyMessage(this.registry, msg, RELAY_CONFIRM_DOMAIN);
    const o = this.require(body.orderId);
    if (msg.signer !== o.offer.recipientId) throw new Error('RELAY_NOT_RECIPIENT');
    if (o.state !== 'KEY_RELEASED') throw new Error('RELAY_ORDER_STATE');
    if (o.frozenBy) throw new Error('RELAY_FROZEN');
    if (body.chunkRoot !== o.commit.chunkRoot) throw new Error('RELAY_CONFIRM_ROOT');
    this.settle(o, now);
    return structuredClone(o);
  }

  /** Permissionless settlement once the fraud window has passed without a proof. */
  finalize(orderId: string, now: number): RelayOrder {
    this.clock.check(now);
    const o = this.require(orderId);
    if (o.state !== 'KEY_RELEASED') throw new Error('RELAY_ORDER_STATE');
    if (o.frozenBy) throw new Error('RELAY_FROZEN');
    if (now <= (o.fraudWindowEndsAt ?? Number.POSITIVE_INFINITY)) throw new Error('RELAY_FRAUD_WINDOW_OPEN');
    this.settle(o, now);
    return structuredClone(o);
  }

  /** No key before the deadline: refund the buyer and return the bond. Counted as not completed. */
  expire(orderId: string, now: number): RelayOrder {
    this.clock.check(now);
    const o = this.require(orderId);
    if (o.state !== 'FUNDED') throw new Error('RELAY_ORDER_STATE');
    if (o.frozenBy) throw new Error('RELAY_FROZEN');
    if (now <= o.offer.keyDeadline) throw new Error('RELAY_NOT_EXPIRED');
    this.ledger.atomic(() => {
      this.ledger.refundHold(`${o.orderId}:price`);
      this.ledger.refundHold(`${o.orderId}:bond`);
    });
    o.state = 'EXPIRED_REFUNDED';
    this.counter(o.offer.providerId).expired += 1;
    return structuredClone(o);
  }

  /**
   * Submitted by the buyer or the recipient. Invalid proofs are counted per submitter and
   * stop being accepted after `maxInvalidFraudAttempts`. A proven fraud refunds the buyer
   * and slashes the provider bond.
   */
  submitFraudProof(
    msg: Signed<{ orderId: string; proofDigest: string }>,
    proof: FraudProof,
    now: number,
  ): FraudResult {
    this.clock.check(now);
    const body = verifyMessage(this.registry, msg, RELAY_FRAUD_DOMAIN);
    const o = this.require(body.orderId);
    if (msg.signer !== o.offer.buyerId && msg.signer !== o.offer.recipientId) throw new Error('RELAY_NOT_PARTY');
    if (o.state !== 'KEY_RELEASED' || o.publishedKey === undefined) throw new Error('RELAY_ORDER_STATE');
    if (o.frozenBy) throw new Error('RELAY_FROZEN');
    if (now > (o.fraudWindowEndsAt ?? 0)) throw new Error('RELAY_FRAUD_WINDOW_CLOSED');
    if ((o.invalidFraudAttempts[msg.signer] ?? 0) >= this.cfg.maxInvalidFraudAttempts) {
      throw new Error('RELAY_FRAUD_ATTEMPTS');
    }
    if (proofDigest(proof) !== body.proofDigest) throw new Error('RELAY_PROOF_DIGEST');

    const result = verifyChunkFraud(
      { ...o.commit, networkId: this.networkId, orderId: o.orderId },
      Buffer.from(o.publishedKey, 'hex'),
      proof,
    );
    if (result !== 'FRAUD_PROVEN') {
      o.invalidFraudAttempts[msg.signer] = (o.invalidFraudAttempts[msg.signer] ?? 0) + 1;
      return result;
    }

    const bond = o.commit.bond;
    const toBuyer = mulDivFloor(bond, this.cfg.slashBuyerBps, 10_000);
    const toTreasury = bond - toBuyer;
    this.ledger.atomic(() => {
      this.ledger.refundHold(`${o.orderId}:price`);
      const payouts: Payout[] = [
        { to: o.offer.buyerId, amount: toBuyer },
        { to: MARKETPLACE_TREASURY, amount: toTreasury },
      ].filter((p) => p.amount > 0);
      this.ledger.releaseHold(`${o.orderId}:bond`, payouts);
      if (toTreasury > 0) this.treasury.collectTransfer(o.offer.asset, toTreasury);
    });
    o.state = 'FRAUD_PROVEN';
    o.settledAt = now;
    this.counter(o.offer.providerId).fraud += 1;
    return 'FRAUD_PROVEN';
  }

  get(orderId: string): RelayOrder | undefined {
    const o = this.orders.get(orderId);
    return o ? structuredClone(o) : undefined;
  }

  providerCounters(providerId: string): ProviderCounters {
    const c = this.counters.get(providerId);
    return {
      settledCount: c?.settled ?? 0,
      expiredNoFinalCount: c?.expired ?? 0,
      fraudProvenCount: c?.fraud ?? 0,
      distinctRecipients: c ? [...c.recipients].sort() : [],
    };
  }

  // ----- Disputable --------------------------------------------------------------

  issueDisputeCap(): DisputeCap {
    return this.caps.issue();
  }

  escrowView(orderId: string): EscrowView | undefined {
    const o = this.orders.get(orderId);
    if (!o) return undefined;
    const buyerSide = [...new Set([o.offer.buyerId, o.offer.recipientId])];
    return {
      orderId,
      category: 'relay',
      buyerId: o.offer.buyerId,
      sellerId: o.offer.providerId,
      buyerSide,
      sellerSide: [o.offer.providerId],
      escrows: [{ asset: o.offer.asset, amount: o.offer.price }],
      open: o.state === 'FUNDED' || o.state === 'KEY_RELEASED',
      frozen: o.frozenBy !== undefined,
    };
  }

  freeze(cap: DisputeCap, orderId: string, caseId: string): void {
    this.caps.check(cap);
    const o = this.require(orderId);
    if (o.state !== 'FUNDED' && o.state !== 'KEY_RELEASED') throw new Error('RELAY_ORDER_STATE');
    if (o.frozenBy) throw new Error('RELAY_FROZEN');
    o.frozenBy = caseId;
  }

  unfreeze(cap: DisputeCap, orderId: string, caseId: string): void {
    this.caps.check(cap);
    const o = this.require(orderId);
    if (o.frozenBy !== caseId) throw new Error('RELAY_FREEZE_OWNER');
    o.frozenBy = undefined;
  }

  apply(cap: DisputeCap, orderId: string, caseId: string, releaseBps: number, now: number): void {
    this.caps.check(cap);
    const o = this.require(orderId);
    if ((o.state !== 'FUNDED' && o.state !== 'KEY_RELEASED') || o.frozenBy !== caseId) {
      throw new Error('RELAY_ORDER_STATE');
    }
    if (!Number.isSafeInteger(releaseBps) || releaseBps < 0 || releaseBps > 10_000) throw new Error('RELAY_BPS');
    this.ledger.atomic(() => {
      this.payPrice(o, releaseBps, now);
      this.ledger.refundHold(`${o.orderId}:bond`);
    });
    o.state = 'DISPUTE_RESOLVED';
    o.frozenBy = undefined;
    o.settledAt = now;
  }

  // ----- internals -----------------------------------------------------------------

  private require(orderId: string): RelayOrder {
    const o = this.orders.get(orderId);
    if (!o) throw new Error('RELAY_ORDER_STATE');
    return o;
  }

  private counter(providerId: string) {
    let c = this.counters.get(providerId);
    if (!c) {
      c = { settled: 0, expired: 0, fraud: 0, recipients: new Set() };
      this.counters.set(providerId, c);
    }
    return c;
  }

  private settle(o: RelayOrder, now: number): void {
    this.ledger.atomic(() => {
      this.payPrice(o, 10_000, now);
      this.ledger.refundHold(`${o.orderId}:bond`);
    });
    o.state = 'SETTLED';
    o.settledAt = now;
    const c = this.counter(o.offer.providerId);
    c.settled += 1;
    c.recipients.add(o.offer.recipientId);
  }

  /** Pays `releaseBps` of the price to the provider (fee on that part only), the rest back to the buyer. */
  private payPrice(o: RelayOrder, releaseBps: number, now: number): void {
    const price = o.offer.price;
    let released = mulDivFloor(price, releaseBps, 10_000);
    let fee = released > 0 ? marketplaceFee(released) : 0;
    if (released > 0 && fee >= released) {
      released = 0;
      fee = 0;
    }
    const payouts: Payout[] = [
      { to: o.offer.providerId, amount: released - fee },
      { to: MARKETPLACE_TREASURY, amount: fee },
      { to: o.offer.buyerId, amount: price - released },
    ].filter((p) => p.amount > 0);
    this.ledger.releaseHold(`${o.orderId}:price`, payouts);
    if (fee > 0) {
      this.treasury.collectMarketplaceFee(o.offer.asset, fee);
      this.writeIndex({
        orderId: o.orderId,
        category: 'relay',
        providerId: o.offer.providerId,
        asset: o.offer.asset,
        feeCollected: fee,
        receiptHash: sha256Hex(canonicalJson(['UEP-RELAY-RECEIPT-v1', o.orderId, o.commit.chunkRoot, now, released, fee])),
        settledAt: now,
      });
    }
  }

  private validateOffer(b: RelayOfferBody, now: number): void {
    if (b.version !== 1) throw new Error('RELAY_VERSION');
    if (b.category !== 'uep.service.relay.v1') throw new Error('RELAY_CATEGORY');
    if (b.networkId !== this.networkId) throw new Error('RELAY_NETWORK');
    assertAccountId(b.buyerId, 'buyer');
    assertAccountId(b.providerId, 'provider');
    assertAccountId(b.recipientId, 'recipient');
    if (b.buyerId === b.providerId || b.recipientId === b.providerId) throw new Error('RELAY_PARTY');
    assertAssetId(b.asset);
    assertPositiveInt(b.price, 'price');
    if (b.price < this.cfg.minPrice) throw new Error('RELAY_PRICE_TOO_LOW');
    assertPositiveInt(b.minBond, 'minBond');
    if (b.minBond < this.cfg.minBond) throw new Error('RELAY_BOND_TOO_LOW');
    assertNonNegInt(b.nonce, 'nonce');
    assertNonNegInt(b.keyDeadline, 'keyDeadline');
    if (b.keyDeadline <= now || b.keyDeadline - now > this.cfg.maxLifetimeSeconds) throw new Error('RELAY_DEADLINE');
    assertPositiveInt(b.fraudWindowSeconds, 'fraudWindowSeconds');
    if (
      b.fraudWindowSeconds < this.cfg.minFraudWindowSeconds ||
      b.fraudWindowSeconds > this.cfg.maxFraudWindowSeconds
    ) {
      throw new Error('RELAY_FRAUD_WINDOW');
    }
  }

  private validateCommit(c: RelayCommitBody, offer: RelayOfferBody): void {
    assertHex32(c.chunkRoot, 'chunkRoot');
    assertHex32(c.wrapRoot, 'wrapRoot');
    assertHex32(c.kCommit, 'kCommit');
    assertPositiveInt(c.contentLen, 'contentLen');
    assertPositiveInt(c.leafCount, 'leafCount');
    if (c.leafCount > MAX_LEAVES || c.leafCount !== Math.ceil(c.contentLen / CHUNK)) throw new Error('RELAY_COMMIT_SHAPE');
    assertPositiveInt(c.bond, 'bond');
    if (c.bond < offer.minBond) throw new Error('RELAY_BOND_TOO_LOW');
  }
}
