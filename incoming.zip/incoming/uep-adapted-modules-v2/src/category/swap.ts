/**
 * uep.service.swap.v1 — category adapter over business-layer HOLDs.
 * Bilateral cross-asset settlement. No AMM, no pool state, no custody beyond the two holds.
 * Hashlock is domain-separated SHA-256 (not Poseidon).
 *
 * Authentication: the buyer signs the intent, the market maker signs an acceptance of that
 * exact intent. The module receives signatures, never private keys, and verifies both
 * against the key registry.
 *
 * Money safety: opening both holds is atomic; settlement and refunds pay out exactly the
 * held amount; amounts too small to survive the fees are refused at open, so a settlement
 * can never fail half-way. Expired locks refund 100% and charge no fee.
 */

import { canonicalJson } from '../uep/canonical.js';
import { sha256Hex, swapHashlock } from '../uep/crypto.js';
import { MIN_LEG_AMOUNT, marketplaceFee, mulDivFloor, protocolFee } from '../uep/fees.js';
import {
  assertAccountId,
  assertAssetId,
  assertHex32,
  assertNonNegInt,
  assertPositiveInt,
  MARKETPLACE_TREASURY,
  PROTOCOL_TREASURY,
} from '../uep/ids.js';
import type { BalanceBook, LedgerPort, Payout } from '../uep/ledger.js';
import { MonotonicClock, ReplayGuard, verifyMessage, type KeyRegistry, type Signed } from '../uep/registry.js';
import type { IndexWriter, SettlementIndex } from '../uep/settlement-index.js';
import type { Treasury } from '../uep/treasury.js';
import { newDisputeCapRegistry, type DisputeCap, type Disputable, type EscrowView } from './disputable.js';

export type SwapState = 'DUAL_HOLD_LOCKED' | 'ATOMICALLY_SETTLED' | 'EXPIRED_REFUNDED' | 'DISPUTE_RESOLVED';

export const SWAP_INTENT_DOMAIN = 'UEP-SWAP-INTENT-v1';
export const SWAP_ACCEPT_DOMAIN = 'UEP-SWAP-ACCEPT-v1';
export const MAX_SWAP_LIFETIME_SECONDS = 7 * 24 * 3600;

export interface SwapIntentBody {
  version: 1;
  category: 'uep.service.swap.v1';
  networkId: string;
  buyerId: string;
  marketMakerId: string;
  fromAsset: string;
  fromAmount: number;
  toAsset: string;
  toAmount: number;
  hashlock: string;
  deadline: number;
  orderNonce: number;
}

export interface SwapAcceptBody {
  intentId: string;
}

export interface OpenSwap {
  intentId: string;
  intent: SwapIntentBody;
  state: SwapState;
  openedAt: number;
  settledAt?: number;
  revealedPreimage?: string;
  frozenBy?: string;
}

/** Deterministic id: nobody can squat or pre-empt an id with free text. */
export function swapIntentId(intent: SwapIntentBody): string {
  return `swp_${sha256Hex(canonicalJson(['UEP-SWAP-INTENTID-v1', intent])).slice(0, 32)}`;
}

export class SwapCategory implements Disputable {
  readonly category = 'swap' as const;
  private orders = new Map<string, OpenSwap>();
  private readonly ledger: LedgerPort;
  private readonly replay = new ReplayGuard();
  private readonly clock = new MonotonicClock();
  private readonly caps = newDisputeCapRegistry();
  private readonly writeIndex: IndexWriter;

  constructor(
    book: BalanceBook,
    private readonly treasury: Treasury,
    private readonly registry: KeyRegistry,
    index: SettlementIndex,
    private readonly networkId = 'uep-testnet',
  ) {
    this.ledger = book.port('swap');
    this.writeIndex = index.issueWriter('swap');
  }

  open(offer: Signed<SwapIntentBody>, accept: Signed<SwapAcceptBody>, now: number): OpenSwap {
    this.clock.check(now);
    const intent = verifyMessage(this.registry, offer, SWAP_INTENT_DOMAIN);
    this.validateIntent(intent, now);
    if (offer.signer !== intent.buyerId) throw new Error('SWAP_BAD_SIGNATURE');

    const intentId = swapIntentId(intent);
    const acc = verifyMessage(this.registry, accept, SWAP_ACCEPT_DOMAIN);
    if (accept.signer !== intent.marketMakerId) throw new Error('SWAP_BAD_SIGNATURE');
    if (acc.intentId !== intentId) throw new Error('SWAP_INTENT_MISMATCH');

    if (this.orders.has(intentId)) throw new Error('SWAP_NONCE_REPLAY');
    this.replay.check('swap-nonce', intent.buyerId, intent.orderNonce);

    // Both holds or neither: a failure on the second leg rolls back the first.
    this.ledger.atomic(() => {
      this.ledger.openHold(`${intentId}:buyer`, intent.buyerId, intent.fromAsset, intent.fromAmount);
      this.ledger.openHold(`${intentId}:maker`, intent.marketMakerId, intent.toAsset, intent.toAmount);
    });
    this.replay.consume('swap-nonce', intent.buyerId, intent.orderNonce);
    const order: OpenSwap = { intentId, intent, state: 'DUAL_HOLD_LOCKED', openedAt: now };
    this.orders.set(intentId, order);
    return structuredClone(order);
  }

  /** Anyone holding the preimage may settle; it proves the secret was revealed. */
  settle(intentId: string, preimage: string, now: number): OpenSwap {
    this.clock.check(now);
    const order = this.require(intentId);
    if (order.state !== 'DUAL_HOLD_LOCKED') throw new Error('SWAP_ALREADY_SETTLED');
    if (order.frozenBy) throw new Error('SWAP_FROZEN');
    if (now > order.intent.deadline) throw new Error('SWAP_INTENT_EXPIRED');
    const computed = swapHashlock(preimage, order.intent.orderNonce, order.intent.networkId);
    if (computed !== order.intent.hashlock) throw new Error('SWAP_HASHLOCK_MISMATCH');

    this.ledger.atomic(() => this.distribute(order, 10_000, now));
    order.state = 'ATOMICALLY_SETTLED';
    order.settledAt = now;
    order.revealedPreimage = preimage;
    return structuredClone(order);
  }

  expire(intentId: string, now: number): OpenSwap {
    this.clock.check(now);
    const order = this.require(intentId);
    if (order.state !== 'DUAL_HOLD_LOCKED') throw new Error('SWAP_ALREADY_SETTLED');
    if (order.frozenBy) throw new Error('SWAP_FROZEN');
    if (now <= order.intent.deadline) throw new Error('SWAP_NOT_EXPIRED');
    this.ledger.atomic(() => {
      this.ledger.refundHold(`${intentId}:buyer`);
      this.ledger.refundHold(`${intentId}:maker`);
    });
    order.state = 'EXPIRED_REFUNDED';
    return structuredClone(order);
  }

  get(intentId: string): OpenSwap | undefined {
    const o = this.orders.get(intentId);
    return o ? structuredClone(o) : undefined;
  }

  // ----- Disputable --------------------------------------------------------------

  issueDisputeCap(): DisputeCap {
    return this.caps.issue();
  }

  escrowView(orderId: string): EscrowView | undefined {
    const o = this.orders.get(orderId);
    if (!o) return undefined;
    const i = o.intent;
    return {
      orderId,
      category: 'swap',
      buyerId: i.buyerId,
      sellerId: i.marketMakerId,
      buyerSide: [i.buyerId],
      sellerSide: [i.marketMakerId],
      escrows: [
        { asset: i.fromAsset, amount: i.fromAmount },
        { asset: i.toAsset, amount: i.toAmount },
      ],
      open: o.state === 'DUAL_HOLD_LOCKED',
      frozen: o.frozenBy !== undefined,
    };
  }

  freeze(cap: DisputeCap, orderId: string, caseId: string): void {
    this.caps.check(cap);
    const o = this.require(orderId);
    if (o.state !== 'DUAL_HOLD_LOCKED') throw new Error('SWAP_ORDER_STATE');
    if (o.frozenBy) throw new Error('SWAP_FROZEN');
    o.frozenBy = caseId;
  }

  unfreeze(cap: DisputeCap, orderId: string, caseId: string): void {
    this.caps.check(cap);
    const o = this.require(orderId);
    if (o.frozenBy !== caseId) throw new Error('SWAP_FREEZE_OWNER');
    o.frozenBy = undefined;
  }

  apply(cap: DisputeCap, orderId: string, caseId: string, releaseBps: number, now: number): void {
    this.caps.check(cap);
    const o = this.require(orderId);
    if (o.state !== 'DUAL_HOLD_LOCKED' || o.frozenBy !== caseId) throw new Error('SWAP_ORDER_STATE');
    if (!Number.isSafeInteger(releaseBps) || releaseBps < 0 || releaseBps > 10_000) throw new Error('SWAP_BPS');
    this.ledger.atomic(() => this.distribute(o, releaseBps, now));
    o.state = 'DISPUTE_RESOLVED';
    o.frozenBy = undefined;
    o.settledAt = now;
  }

  // ----- internals -----------------------------------------------------------------

  private require(intentId: string): OpenSwap {
    const order = this.orders.get(intentId);
    if (!order) throw new Error('SWAP_ORDER_STATE');
    return order;
  }

  private validateIntent(i: SwapIntentBody, now: number): void {
    if (i.version !== 1) throw new Error('SWAP_VERSION');
    if (i.networkId !== this.networkId) throw new Error('SWAP_NETWORK');
    if (i.category !== 'uep.service.swap.v1') throw new Error('SWAP_CATEGORY');
    assertAccountId(i.buyerId, 'buyer');
    assertAccountId(i.marketMakerId, 'market maker');
    if (i.buyerId === i.marketMakerId) throw new Error('SWAP_PARTY');
    assertAssetId(i.fromAsset, 'fromAsset');
    assertAssetId(i.toAsset, 'toAsset');
    if (i.fromAsset === i.toAsset) throw new Error('SWAP_ASSET_MISMATCH');
    assertPositiveInt(i.fromAmount, 'fromAmount');
    assertPositiveInt(i.toAmount, 'toAmount');
    assertHex32(i.hashlock, 'hashlock');
    assertNonNegInt(i.orderNonce, 'orderNonce');
    assertNonNegInt(i.deadline, 'deadline');
    if (now > i.deadline) throw new Error('SWAP_INTENT_EXPIRED');
    if (i.deadline - now > MAX_SWAP_LIFETIME_SECONDS) throw new Error('SWAP_DEADLINE_TOO_FAR');
    // Refuse amounts that cannot cover their fees: settlement must never fail mid-way.
    if (i.fromAmount < MIN_LEG_AMOUNT || i.fromAmount - protocolFee(i.fromAmount) < 1) {
      throw new Error('SWAP_AMOUNT_TOO_SMALL');
    }
    if (i.toAmount - protocolFee(i.toAmount) - marketplaceFee(i.toAmount) < 1) {
      throw new Error('SWAP_AMOUNT_TOO_SMALL');
    }
  }

  /**
   * Pays `releaseBps` of each leg to its intended recipient (fees only on the released part)
   * and returns the rest to the locker. Dust that cannot cover its fees is returned instead.
   * Must run inside `ledger.atomic`.
   */
  private distribute(order: OpenSwap, releaseBps: number, now: number): void {
    const i = order.intent;
    const id = order.intentId;

    let r1 = mulDivFloor(i.fromAmount, releaseBps, 10_000);
    let fee1 = r1 > 0 ? protocolFee(r1) : 0;
    if (r1 > 0 && fee1 >= r1) {
      r1 = 0;
      fee1 = 0;
    }

    let r2 = mulDivFloor(i.toAmount, releaseBps, 10_000);
    let protoFee2 = r2 > 0 ? protocolFee(r2) : 0;
    let marketFee = r2 > 0 ? marketplaceFee(r2) : 0;
    if (r2 > 0 && protoFee2 + marketFee >= r2) {
      r2 = 0;
      protoFee2 = 0;
      marketFee = 0;
    }

    const leg1: Payout[] = [
      { to: i.marketMakerId, amount: r1 - fee1 },
      { to: PROTOCOL_TREASURY, amount: fee1 },
      { to: i.buyerId, amount: i.fromAmount - r1 },
    ].filter((p) => p.amount > 0);
    const leg2: Payout[] = [
      { to: i.buyerId, amount: r2 - protoFee2 - marketFee },
      { to: PROTOCOL_TREASURY, amount: protoFee2 },
      { to: MARKETPLACE_TREASURY, amount: marketFee },
      { to: i.marketMakerId, amount: i.toAmount - r2 },
    ].filter((p) => p.amount > 0);

    this.ledger.releaseHold(`${id}:buyer`, leg1);
    this.ledger.releaseHold(`${id}:maker`, leg2);

    if (marketFee > 0) {
      this.treasury.collectMarketplaceFee(i.toAsset, marketFee);
      this.writeIndex({
        orderId: id,
        category: 'swap',
        providerId: i.marketMakerId,
        asset: i.toAsset,
        feeCollected: marketFee,
        receiptHash: sha256Hex(canonicalJson(['UEP-SWAP-RECEIPT-v1', id, i.hashlock, now, r2, marketFee])),
        settledAt: now,
      });
    }
  }
}
